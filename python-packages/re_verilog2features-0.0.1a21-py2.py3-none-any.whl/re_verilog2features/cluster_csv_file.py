"""Module for a CSVfile wrapper post feature-generation.
"""
import glob
import logging
import os
import re
from enum import Enum, auto
from functools import partial

import pandas as pd

glogger = logging.getLogger(__name__)


class CSVType(Enum):
    design_graph = auto()
    partition_graph = auto()
    cluster_graph = auto()
    small = auto()


class CSVFile(object):

    __slots__ = [
        "specimen_name",
        "module_hierarchy",
        "module_name",
        "cluster_id",
        "jaccard_index",
        "base_design",
        "tj_no",
        "tj_status",
        "top_module",
        "frame",
        "type",
        "basename",
        "id",
    ]

    ID_SEPARATOR = "$"

    partition_csv_re = re.compile(
        r"^(?P<specimen_name>.*)_partitionReal_(?P<module_hierarchy>.*)_moduleName_(?P<module_name>.*)$"
    )
    cluster_csv_re = re.compile(
        r"^(?P<specimen_name>.*)_partitionCluster_(?P<cluster_id>.*)_moduleNames_(?P<module_name>.*)_(?P<jaccard_index>[01]\.[0-9]{4})$"
    )

    design_name_re = re.compile(
        r"^(?P<base_design>.*)-T(?P<tj_no>[\d]{3,4})_(?P<tj_status>TjFree|TjIn)_(?P<top_module>.*)$"
    )

    @classmethod
    def from_file(cls, file_name, t):
        """Initialize the CSVFile

        Args:
            file_name (str): 
            t ([type], optional): Defaults to None. [description]
        """

        csvfile = cls()

        csvfile.frame = pd.read_csv(file_name, index_col=0).T
        csvfile.type = t
        csvfile.build_info(file_name)
        return csvfile

    @classmethod
    def from_iterrows(cls, name, row, t=None):

        csvfile = cls()
        csvfile.frame = row
        csvfile.type = t
        csvfile.build_info(name + ".csv")
        return csvfile

    def build_info(self, file_name):
        if self.type == CSVType.design_graph:
            self.basename = os.path.basename(file_name).rsplit(".", 1)[0]
            self.specimen_name = self.basename
            basename_match = self.design_name_re.match(self.basename)
            if basename_match is None:
                raise ValueError(
                    "design_name_re did not match at {} file {}".format(
                        self.type, file_name
                    )
                )
            self._update(basename_match.groupdict())
            self.id = "d{sep}{s.base_design}{sep}{s.tj_no}{sep}{s.tj_status}{sep}{s.top_module}".format(
                s=self, sep=self.ID_SEPARATOR
            )
        elif self.type == CSVType.partition_graph:
            self.basename = os.path.basename(file_name).rsplit(".", 1)[0]
            basename_match = self.partition_csv_re.match(self.basename)
            if basename_match is None:
                raise ValueError(
                    "partition_csv_re did not match at {} file {}".format(
                        self.type, file_name
                    )
                )
            self._update(basename_match.groupdict())
            specimen_name_match = self.design_name_re.match(self.specimen_name)
            if basename_match is None:
                raise ValueError(
                    "design_name_re did not match at {} file {}".format(
                        self.type, file_name
                    )
                )
            self._update(specimen_name_match.groupdict())
            self.id = "p{sep}{s.base_design}{sep}{s.tj_no}{sep}{s.tj_status}{sep}{s.top_module}{sep}{s.module_hierarchy}{sep}{s.module_name}".format(
                s=self, sep=self.ID_SEPARATOR
            )
        elif self.type == CSVType.cluster_graph:
            self.basename = os.path.basename(file_name).rsplit(".", 1)[0]
            basename_match = self.cluster_csv_re.match(self.basename)
            if basename_match is None:
                raise ValueError(
                    "cluster_csv_re did not match at {} file {}".format(
                        self.type, file_name
                    )
                )
            self._update(basename_match.groupdict())
            specimen_name_match = self.design_name_re.match(self.specimen_name)
            if specimen_name_match is None:
                raise ValueError(
                    "design_name_re did not match at {} file {}".format(
                        self.type, file_name
                    )
                )
            self._update(specimen_name_match.groupdict())
            self.id = "c{sep}{s.base_design}{sep}{s.tj_no}{sep}{s.tj_status}{sep}{s.top_module}{sep}{s.cluster_id}{sep}{s.module_name}{sep}{s.jaccard_index}".format(
                s=self, sep=self.ID_SEPARATOR
            )
        elif self.type == CSVType.small:
            self.basename = os.path.basename(file_name).rsplit(".", 1)[0]
            self.specimen_name = self.basename
            self.id = "s{sep}{s.specimen_name}".format(s=self, sep=self.ID_SEPARATOR)
        else:
            raise ValueError("Sorry, csv type {} is unknown".format(self.type))

    def _update(self, update_dict):
        for key, value in update_dict.items():
            setattr(self, key, value)

    @classmethod
    def read_csvs_to_list(cls, file_names, t=None):
        files = []
        folder_name = os.path.basename(os.path.dirname(file_names[0]))
        logging.info("reading in all {} csv files".format(folder_name))
        for file_name in file_names:
            files.append(cls.from_file(file_name, t))
        return files

    def __str__(self):
        return self.id


class CSVFileContainer(object):
    def __init__(self, **kwargs):
        for key, path in kwargs.items():
            # check if key is a valid enum value
            if not key.lower() in CSVType.__members__:
                raise TypeError("Sorry, {} is not a known CSVType".format(key))
            else:
                # key is valid, set type for this iteration
                csv_type = CSVType.__members__[key.lower()]
            # crate container property name
            csv_list_property = "all_" + key.lower() + "_files"
            # set internal property to None
            setattr(self, "_" + csv_list_property, None)
            # get the csv files from path via glob
            csv_files = glob.glob(os.path.join(path, "*.csv"))
            if not csv_files:
                raise ValueError("Sorry, there are no csvs at {}".format(path))
            # define the property name
            csv_filenames_property = key.lower() + "csv_file_names"
            # set the property name
            setattr(self, csv_filenames_property, csv_files)

            # define the getter for the csv list
            def get_csv(self, csv_list_property, csv_files, csv_type):
                # if csv not loaded yet, do so now
                if getattr(self, "_" + csv_list_property) is None:
                    setattr(
                        self,
                        "_" + csv_list_property,
                        CSVFile.read_csvs_to_list(csv_files, t=csv_type),
                    )
                # and finally return the CSVFile list
                return getattr(self, "_" + csv_list_property)

            # set class attribute (the property) to a property-decorated getter
            setattr(
                self.__class__,
                csv_list_property,
                property(
                    partial(
                        get_csv,
                        csv_list_property=csv_list_property,
                        csv_files=csv_files,
                        csv_type=csv_type,
                    )
                ),
            )
