"""get lists"""
import networkx as nx


def get_input_output_rest_list(graph):
    """Get the three different list"""
    nodes = list(graph.nodes)

    input_list = list()
    output_list = list()
    gate_list = list()
    for node in nodes:
        if node.startswith("INPUT_"):
            input_list.append(node)
        elif node.startswith("OUTPUT"):
            output_list.append(node)
        else:
            fas = nx.get_node_attributes(graph, "nodeType")
            node_name = fas[node]
            if node_name.startswith("DFF"):
                input_list.append(node)
                gate_list.append(node)
            else:
                gate_list.append(node)

    circuitdescription_inputfile = [input_list, gate_list, output_list]

    return (input_list, output_list, circuitdescription_inputfile)
