"""Function for calculating CC0 and CC1 for every gate"""
import sys
from copy import deepcopy

import enlighten
import networkx as nx


def calculation_controllability(levels, graph, data, outputlist):
    """input: the levelized gates in a list, position of gate in list stands for level
       output: CC0 for gate
       output: CC0 for gate"""

    for gate in levels[0]:
        if gate.startswith("INPUT"):
            data[gate]["CC0"] = 1
            data[gate]["CC1"] = 1

    data_stabilized = hash(frozenset())

    man = enlighten.get_manager()
    ticks = man.counter(total=None, desc="CCIter:", unit="iterations", position=1)
    while (
        hash(frozenset((key, frozenset(value.items())) for key, value in data.items()))
        != data_stabilized
    ):
        ticks.update()
        data_stabilized = hash(
            frozenset((key, frozenset(value.items())) for key, value in data.items())
        )
        tacks = man.counter(
            total=len(levels), desc="Iterating levels:", unit="levels", leave=False
        )

        # drop first level
        levelsiter = iter(levels)
        next(levelsiter)
        for level in levelsiter:
            tacks.update()
            for gate in level:
                if gate.startswith("OUTPUT"):
                    continue
                else:
                    name_list = nx.get_node_attributes(graph, "nodeType")
                    name = name_list[gate]
                    if name.startswith("NOT") or name.startswith("INVX"):
                        not_function(gate, graph, data)
                    elif name.startswith("AND2"):
                        and_function(gate, graph, data)
                    elif name.startswith("OR2"):
                        or_function(gate, graph, data)
                    elif name.startswith("XOR2"):
                        xor_function(gate, graph, data)
                    elif name.startswith("NAND2"):
                        nand2_function(gate, graph, data)
                    elif name.startswith("NAND3"):
                        nand3_function(gate, graph, data)
                    elif name.startswith("NOR2"):
                        nor2_function(gate, graph, data)
                    elif name.startswith("NOR3"):
                        nor3_function(gate, graph, data)
                    elif name.startswith("XNOR2"):
                        xnor_function(gate, graph, data)
                    elif name.startswith("DFFSR"):
                        dffrs_function(gate, graph, data)
                    elif name.startswith("DFF"):
                        dff_function(gate, graph, data)
                    elif name.startswith("AOI21"):
                        aoi21_function(gate, graph, data)
                    elif name.startswith("AOI22"):
                        aoi22_function(gate, graph, data)
                    elif name.startswith("OAI21"):
                        oai21_function(gate, graph, data)
                    elif name.startswith("OAI22"):
                        oai22_function(gate, graph, data)
                    elif name.startswith("MUX2X1"):
                        mux2x1_function(gate, graph, data)
                    else:
                        sys.exit(
                            "In calculation_controllability.py unrecognised gate with NAME: {}".format(
                                gate
                            )
                        )
        tacks.close()
        # update data
        for gate in outputlist:
            cc0_out, cc1_out = input_nodes_values(gate, graph, data)
            data[gate]["CC1"] = cc1_out
            data[gate]["CC0"] = cc0_out

    man.stop()
    return data


def and_function(gate, graph, data):
    """and_function for calculation"""
    # print(len(graph.in_edges(gate)))
    cc0_a, cc0_b, cc1_a, cc1_b = input_nodes_values(gate, graph, data)

    cc1_and = cc1_a + cc1_b + 1
    data[gate]["CC1"] = cc1_and

    cc0_and = min(cc0_a, cc0_b) + 1
    data[gate]["CC0"] = cc0_and


def or_function(gate, graph, data):
    """or_function"""
    # print(len(graph.in_edges(gate)))
    cc0_a, cc0_b, cc1_a, cc1_b = input_nodes_values(gate, graph, data)

    cc1_or = min(cc1_a, cc1_b) + 1
    data[gate]["CC1"] = cc1_or

    cc0_or = cc0_a + cc0_b + 1
    data[gate]["CC0"] = cc0_or


def xor_function(gate, graph, data):
    """xor_function for calculation xor gate"""
    # print(len(graph.in_edges(gate)))
    cc0_a, cc0_b, cc1_a, cc1_b = input_nodes_values(gate, graph, data)

    cc1_xor = min(cc0_a + cc0_b, cc1_a + cc1_b) + 1
    data[gate]["CC1"] = cc1_xor

    cc0_xor = min(cc1_a + cc0_b, cc0_a + cc1_b) + 1
    data[gate]["CC0"] = cc0_xor


def nand2_function(gate, graph, data):
    """nand function"""
    # print(len(graph.in_edges(gate)))

    cc0_a, cc0_b, cc1_a, cc1_b = input_nodes_values(gate, graph, data)
    cc1_nand = min(cc0_a, cc0_b) + 1
    data[gate]["CC1"] = cc1_nand

    cc0_nand = cc1_a + cc1_b + 1
    data[gate]["CC0"] = cc0_nand


def nand3_function(gate, graph, data):

    cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c = input_nodes_values_3(gate, graph, data)

    cc1_nand = min(cc0_a, cc0_b, cc0_c) + 1
    data[gate]["CC1"] = cc1_nand

    cc0_nand = cc1_a + cc1_b + cc1_c + 1
    data[gate]["CC0"] = cc0_nand


def nor2_function(gate, graph, data):
    """nor_function for calculation nor gate"""
    # print(len(graph.in_edges(gate)))
    cc0_a, cc0_b, cc1_a, cc1_b = input_nodes_values(gate, graph, data)

    cc1_nor = cc0_a + cc0_b + 1
    data[gate]["CC1"] = cc1_nor

    cc0_nor = min(cc1_a, cc1_b) + 1
    data[gate]["CC0"] = cc0_nor


def nor3_function(gate, graph, data):
    cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c = input_nodes_values_3(gate, graph, data)

    cc1_nor = cc0_a + cc0_b + cc0_c + 1
    data[gate]["CC1"] = cc1_nor

    cc0_nor = min(cc1_a, cc1_b, cc1_c) + 1
    data[gate]["CC0"] = cc0_nor


def xnor_function(gate, graph, data):
    """xnor_function for calculation xnor gate"""
    # print(len(graph.in_edges(gate)))
    cc0_a, cc0_b, cc1_a, cc1_b = input_nodes_values(gate, graph, data)

    cc1_xnor = min(cc0_a + cc0_b, cc1_a + cc1_b) + 1
    data[gate]["CC1"] = cc1_xnor

    cc0_xnor = min(cc1_a + cc0_b, cc0_a + cc1_b) + 1
    data[gate]["CC0"] = cc0_xnor


def not_function(gate, graph, data):
    """not_function for calculation nor gate"""
    # print(len(graph.in_edges(gate)))
    cc0_a, cc1_a = input_nodes_values(gate, graph, data)

    cc1_not = cc0_a + 1
    data[gate]["CC1"] = cc1_not

    cc0_not = cc1_a + 1
    data[gate]["CC0"] = cc0_not


def dff_function(gate, graph, data):
    """dff_function for calculation d flip-flop"""
    # print(len(graph.in_edges(gate)))
    # synchronously
    cc0_clk, cc0_d, cc1_clk, cc1_d = input_nodes_values_dff(gate, graph, data)

    cc1_q = cc1_d + cc1_clk + cc0_clk
    data[gate]["CC1"] = cc1_q

    cc0_q = cc0_d + cc1_clk + cc0_clk
    data[gate]["CC0"] = cc0_q


def dffrs_function(gate, graph, data):
    """dffrs_function calculation"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # print(output_pin_list)
    # print(gate)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "R":
            tmp_r = edge[(0)]
        elif output_pin == "S":
            tmp_s = edge[(0)]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "S":
                    tmp_s = edge[(0)]
                elif i == "R":
                    tmp_r = edge[(0)]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "S":
                    tmp_s = edge[(0)]
                elif i == "R":
                    tmp_r = edge[(0)]
        elif len(output_pin) == 4:
            for i in output_pin:
                if i == "S":
                    tmp_s = edge[(0)]
                elif i == "R":
                    tmp_r = edge[(0)]

        # print(gate)
    if tmp_s.startswith("INPUT_CONSTANT_1") and tmp_r.startswith("INPUT_CONSTANT_1"):
        dff_function(gate, graph, data)
    elif tmp_s.startswith("INPUT_CONSTANT_1"):
        s_r_status = "s_deactivated"
        cc0_clk, cc0_d, cc0_r, cc1_clk, cc1_d, cc1_r = input_nodes_values_dffrs(
            gate, graph, data, s_r_status
        )

        cc0_q = min(
            cc0_r + cc1_clk + cc0_clk, cc0_d + cc1_clk + cc0_clk
        )  # cc0_r reset active (!R)
        cc1_q = cc1_d + cc1_clk + cc0_clk + cc1_r  # cc1_r deactivated (!R)

    elif tmp_r.startswith("INPUT_CONSTANT_1"):
        s_r_status = "r_deactivated"
        cc0_clk, cc0_d, cc0_s, cc1_clk, cc1_d, cc1_s = input_nodes_values_dffrs(
            gate, graph, data, s_r_status
        )

        cc0_q = cc0_d + cc1_clk + cc0_clk + cc1_s  # set deactivated (!S)
        cc1_q = min(
            cc0_s + cc1_clk + cc0_clk, cc1_d + cc1_clk + cc0_clk
        )  # cc0_s set activated (!S)
    else:
        s_r_status = "s_r_not_deactivated"
        (
            cc0_clk,
            cc0_d,
            cc0_r,
            cc0_s,
            cc1_clk,
            cc1_d,
            cc1_r,
            cc1_s,
        ) = input_nodes_values_dffrs(gate, graph, data, s_r_status)

        # actual
        cc0_q = min(
            cc0_r + cc1_clk + cc0_clk + cc1_s, cc0_d + cc1_clk + cc0_clk + cc1_s
        )  # cc1_s (!S) deactivated
        cc1_q = min(
            cc0_s + cc1_clk + cc0_clk + cc1_r, cc1_d + cc1_clk + cc0_clk + cc1_r
        )  # cc1_r (!R) deactivated

    data[gate]["CC1"] = cc1_q
    data[gate]["CC0"] = cc0_q


def aoi21_function(gate, graph, data):
    """and-or_inverter-function"""
    # print(len(graph.in_edges(gate)))
    # print(graph.in_edges(gate))
    cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c = input_nodes_values_aoi_oai(
        gate, graph, data
    )

    # calculate cc0 and cc1 of the and-gate
    cc1_and = cc1_a + cc1_b
    cc0_and = min(cc0_a, cc0_b)

    # calculate cc0 and cc1 of the aoi21-gate with increment + 1
    # or-gate and not-gate in one gate 'nor'
    cc1_nor_aoi21 = cc0_and + cc0_c + 1
    data[gate]["CC1"] = cc1_nor_aoi21

    cc0_nor_aoi21 = min(cc1_and, cc1_c) + 1
    data[gate]["CC0"] = cc0_nor_aoi21


def oai21_function(gate, graph, data):
    """or-and_inverter_function"""
    cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c = input_nodes_values_aoi_oai(
        gate, graph, data
    )

    # calculate cc0 and cc1 of the or-gate
    cc1_or = min(cc1_a, cc1_b)
    cc0_or = cc0_a + cc0_b

    # calculate cc0 and cc1 of the oai21-gate with increment + 1
    # and-gate and not-gate in one gate 'nand'
    cc1_nand_oai21 = min(cc0_or, cc0_c) + 1
    data[gate]["CC1"] = cc1_nand_oai21

    cc0_nand_oai21 = cc1_or + cc1_c + 1
    data[gate]["CC0"] = cc0_nand_oai21


def aoi22_function(gate, graph, data):
    """and-or-inverter 4 inputs A, B, C, D and one output Y,
    node_function: [('Y', '(!((A&B)+(C&D)))')]"""
    cc0_a, cc0_b, cc0_c, cc0_d, cc1_a, cc1_b, cc1_c, cc1_d = input_nodes_values_aoi_oai(
        gate, graph, data
    )

    # (A&B)
    cc1_and_ab = cc1_a + cc1_b
    cc0_and_ab = min(cc0_a, cc0_b)
    # (C&D)
    cc1_and_cd = cc1_c + cc1_d
    cc0_and_cd = min(cc0_c, cc0_d)

    # !((A&B)+(C&D)) nor-gate
    cc1_nor_aoi22 = cc0_and_ab + cc0_and_cd + 1
    data[gate]["CC1"] = cc1_nor_aoi22

    cc0_nor_aoi22 = min(cc1_and_ab, cc1_and_cd) + 1
    data[gate]["CC0"] = cc0_nor_aoi22


def oai22_function(gate, graph, data):
    """or-and-inverter 4 inputs A, B, C, D and one output Y,
    node_function: [('Y', '(!((A+B)&(C+D)))')]"""
    cc0_a, cc0_b, cc0_c, cc0_d, cc1_a, cc1_b, cc1_c, cc1_d = input_nodes_values_aoi_oai(
        gate, graph, data
    )

    # (A+B)
    cc1_or_ab = min(cc1_a, cc1_b)
    cc0_or_ab = cc0_a + cc0_b

    # (C+D)
    cc1_or_cd = min(cc1_c, cc1_d)
    cc0_or_cd = cc0_c + cc0_d

    # (A+B)&(C+D)
    cc1_oai22 = cc1_or_ab + cc1_or_cd + 1
    data[gate]["CC1"] = cc1_oai22

    cc0_oai22 = min(cc0_or_ab, cc0_or_cd) + 1
    data[gate]["CC0"] = cc0_oai22


def mux2x1_function(gate, graph, data):
    """mux calculation function for controllability"""
    cc0_a, cc0_b, cc0_s, cc1_a, cc1_b, cc1_s = input_nodes_values_mux(gate, graph, data)

    # (S&A)
    cc1_and_sa = cc1_a + cc1_s
    cc0_and_sa = min(cc0_a, cc0_s)

    # (!S&B)
    cc1_and_sb = cc1_b + cc1_s
    cc0_and_sb = min(cc0_b, cc0_s)

    # (S&A)+(!S&B)
    cc1_mux = min(cc1_and_sa, cc1_and_sb) + 1
    data[gate]["CC1"] = cc1_mux

    cc0_mux = cc0_and_sa + cc0_and_sb + 1
    data[gate]["CC0"] = cc0_mux


# def not_out_values


def input_nodes_values(gate, graph, data):
    """get values from input for calculation"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if len(output_pin) == 1:
            if output_pin == "A":
                tmp = edge[(0)]
                cc0_a = data[tmp]["CC0"]
                cc1_a = data[tmp]["CC1"]
            elif output_pin == "B":
                tmp = edge[(0)]
                cc0_b = data[tmp]["CC0"]
                cc1_b = data[tmp]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]

    if gate.startswith("OUTPUT_") or gate.startswith("NOT") or gate.startswith("INVX"):
        return cc0_a, cc1_a
    else:
        name_list = nx.get_node_attributes(graph, "nodeType")
        name = name_list[gate]
        if name.startswith("NOT") or name.startswith("INVX"):
            return cc0_a, cc1_a
        else:
            return cc0_a, cc0_b, cc1_a, cc1_b


def input_nodes_values_3(gate, graph, data):
    """get values from input for calculation"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if len(output_pin) == 1:
            if output_pin == "A":
                tmp = edge[(0)]
                cc0_a = data[tmp]["CC0"]
                cc1_a = data[tmp]["CC1"]
            elif output_pin == "B":
                tmp = edge[(0)]
                cc0_b = data[tmp]["CC0"]
                cc1_b = data[tmp]["CC1"]
            elif output_pin == "C":
                tmp = edge[(0)]
                cc0_c = data[tmp]["CC0"]
                cc1_c = data[tmp]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif output_pin == "C":
                    tmp = edge[(0)]
                    cc0_c = data[tmp]["CC0"]
                    cc1_c = data[tmp]["CC1"]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif i == "C":
                    tmp = edge[(0)]
                    cc0_c = data[tmp]["CC0"]
                    cc1_c = data[tmp]["CC1"]
    return cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c


def input_nodes_values_dff(gate, graph, data):
    """difference between d and clk line for right parsing"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # print(output_pin_list)
    # print(gate)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "CLK":
            tmp = edge[(0)]
            cc0_clk = data[tmp]["CC0"]
            cc1_clk = data[tmp]["CC1"]
        elif output_pin == "D":
            tmp = edge[(0)]
            cc0_d = data[tmp]["CC0"]
            cc1_d = data[tmp]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "CLK":
                    tmp = edge[(0)]
                    cc0_clk = data[tmp]["CC0"]
                    cc1_clk = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]

    return cc0_clk, cc0_d, cc1_clk, cc1_d


def input_nodes_values_dffrs(gate, graph, data, s_r_status):
    """difference between d and clk line for right parsing"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # print(output_pin_list)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "CLK":
            tmp = edge[(0)]
            cc0_clk = data[tmp]["CC0"]
            cc1_clk = data[tmp]["CC1"]
        elif output_pin == "D":
            tmp = edge[(0)]
            cc0_d = data[tmp]["CC0"]
            cc1_d = data[tmp]["CC1"]
        elif output_pin == "R":
            tmp = edge[(0)]
            cc0_r = data[tmp]["CC0"]
            cc1_r = data[tmp]["CC1"]
        elif output_pin == "S":
            tmp = edge[(0)]
            cc0_s = data[tmp]["CC0"]
            cc1_s = data[tmp]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "CLK":
                    tmp = edge[(0)]
                    cc0_clk = data[tmp]["CC0"]
                    cc1_clk = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]
                elif i == "R":
                    tmp = edge[(0)]
                    cc0_r = data[tmp]["CC0"]
                    cc1_r = data[tmp]["CC1"]
                elif i == "S":
                    tmp = edge[(0)]
                    cc0_s = data[tmp]["CC0"]
                    cc1_s = data[tmp]["CC1"]
                else:
                    sys.exit(
                        "In input_nodes_values_dffrs() new input, no D, CLK, R or S output_pin NAME: {}".format(
                            output_pin
                        )
                    )
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "CLK":
                    tmp = edge[(0)]
                    cc0_clk = data[tmp]["CC0"]
                    cc1_clk = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]
                elif i == "R":
                    tmp = edge[(0)]
                    cc0_r = data[tmp]["CC0"]
                    cc1_r = data[tmp]["CC1"]
                elif i == "S":
                    tmp = edge[(0)]
                    cc0_s = data[tmp]["CC0"]
                    cc1_s = data[tmp]["CC1"]
                else:
                    sys.exit(
                        "In input_nodes_values_dffrs() new input, no D, CLK, R or S output_pin NAME: {}".format(
                            output_pin
                        )
                    )
        elif len(output_pin) == 4:
            for i in output_pin:
                if i == "CLK":
                    tmp = edge[(0)]
                    cc0_clk = data[tmp]["CC0"]
                    cc1_clk = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]
                elif i == "R":
                    tmp = edge[(0)]
                    cc0_r = data[tmp]["CC0"]
                    cc1_r = data[tmp]["CC1"]
                elif i == "S":
                    tmp = edge[(0)]
                    cc0_s = data[tmp]["CC0"]
                    cc1_s = data[tmp]["CC1"]
                else:
                    sys.exit(
                        "In input_nodes_values_dffrs() new input, no D, CLK, R or S output_pin NAME: {}".format(
                            output_pin
                        )
                    )

    if s_r_status == "s_deactivated":
        return cc0_clk, cc0_d, cc0_r, cc1_clk, cc1_d, cc1_r
    elif s_r_status == "r_deactivated":
        return cc0_clk, cc0_d, cc0_s, cc1_clk, cc1_d, cc1_s
    elif s_r_status == "s_r_not_deactivated":
        return cc0_clk, cc0_d, cc0_r, cc0_s, cc1_clk, cc1_d, cc1_r, cc1_s
    else:
        sys.exit(
            "in input_nodes_values_dffrs() s_r_status unknown: {}".format(s_r_status)
        )


def input_nodes_values_aoi_oai(gate, graph, data):
    """aoi und oai input parsing"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "A":
            tmp = edge[(0)]
            cc0_a = data[tmp]["CC0"]
            cc1_a = data[tmp]["CC1"]
        elif output_pin == "B":
            tmp = edge[(0)]
            cc0_b = data[tmp]["CC0"]
            cc1_b = data[tmp]["CC1"]
        elif output_pin == "C":
            tmp = edge[(0)]
            cc0_c = data[tmp]["CC0"]
            cc1_c = data[tmp]["CC1"]
        elif output_pin == "D":
            tmp = edge[(0)]
            cc0_d = data[tmp]["CC0"]
            cc1_d = data[tmp]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif i == "C":
                    tmp = edge[(0)]
                    cc0_c = data[tmp]["CC0"]
                    cc1_c = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif i == "C":
                    tmp = edge[(0)]
                    cc0_c = data[tmp]["CC0"]
                    cc1_c = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]
        elif len(output_pin) == 4:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif i == "C":
                    tmp = edge[(0)]
                    cc0_c = data[tmp]["CC0"]
                    cc1_c = data[tmp]["CC1"]
                elif i == "D":
                    tmp = edge[(0)]
                    cc0_d = data[tmp]["CC0"]
                    cc1_d = data[tmp]["CC1"]

    name_list = nx.get_node_attributes(graph, "nodeType")
    name = name_list[gate]

    if name.startswith("AOI21") or name.startswith("OAI21"):
        return cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c
    elif name.startswith("AOI22") or name.startswith("OAI22"):
        return cc0_a, cc0_b, cc0_c, cc0_d, cc1_a, cc1_b, cc1_c, cc1_d
    else:
        sys.exit("No AOI21, AOI22, OAI21, OAI22, NAME_iSSUE: {}".format(gate))


def input_nodes_values_mux(gate, graph, data):
    """input values for mux with A, B, S"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "A":
            tmp = edge[(0)]
            cc0_a = data[tmp]["CC0"]
            cc1_a = data[tmp]["CC1"]
        elif output_pin == "B":
            tmp = edge[(0)]
            cc0_b = data[tmp]["CC0"]
            cc1_b = data[tmp]["CC1"]
        elif output_pin == "S":
            tmp = edge[(0)]
            cc0_s = data[tmp]["CC0"]
            cc1_s = data[tmp]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif i == "S":
                    tmp = edge[(0)]
                    cc0_s = data[tmp]["CC0"]
                    cc1_s = data[tmp]["CC1"]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    tmp = edge[(0)]
                    cc0_a = data[tmp]["CC0"]
                    cc1_a = data[tmp]["CC1"]
                elif i == "B":
                    tmp = edge[(0)]
                    cc0_b = data[tmp]["CC0"]
                    cc1_b = data[tmp]["CC1"]
                elif i == "S":
                    tmp = edge[(0)]
                    cc0_s = data[tmp]["CC0"]
                    cc1_s = data[tmp]["CC1"]

    return cc0_a, cc0_b, cc0_s, cc1_a, cc1_b, cc1_s
