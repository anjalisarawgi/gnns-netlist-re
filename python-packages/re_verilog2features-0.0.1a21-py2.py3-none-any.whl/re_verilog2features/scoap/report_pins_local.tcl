# verilog path is input via -env VPATH {path} commandline args
read_netlist [getenv LIBPATH] -library
read_netlist [getenv VPATH]

set_build -nodelete_unused_gates
set_build -merge notied_gates_with_pin_loss
set_build -merge nocascaded_gates_with_pin_loss
set_build -merge nobus_keepers
set_build -merge nofeedback_paths
set_build -merge nomux_from_gates
set_build -merge noxor_from_gates
set_build -merge noequivalent_dlat_dff
set_build -merge noflipflop_from_dlat
set_build -merge nowire_to_buffer
set_build -merge noglobal_tie_propagate



run_build_model [getenv TOPNAME]
set_pindata -full_seq_scoap_data

report_primitives -max 99999999999 -all
exit
