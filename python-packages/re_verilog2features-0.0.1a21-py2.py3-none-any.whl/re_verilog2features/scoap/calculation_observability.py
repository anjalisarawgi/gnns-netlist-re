"""Function for calculating CO for every gate"""
import sys
from copy import deepcopy

import enlighten
import networkx as nx


def calculation_observability(levels_co, graph, data, outputlist):
    """input: the levelized gates in a list, position of gate in list stands for level
       output: CC0 for gate
       output: CC0 for gate"""
    # from the highest level to the lowest

    levels = deepcopy(levels_co)
    # stem is correct because 0 is always minimum
    for gate in outputlist:
        data[gate]["CO"] = 0
        levels.remove(gate)
        for edge in graph.in_edges(gate):
            # print(edge[(0)])
            data[edge[(0)]]["CO"] = data[gate]["CO"]

    data_stabilized = hash(frozenset())

    man = enlighten.get_manager()
    ticks = man.counter(total=None, desc="COIter:", unit="iterations", position=1)
    while (
        hash(frozenset((key, frozenset(value.items())) for key, value in data.items()))
        != data_stabilized
    ):
        ticks.update()
        data_stabilized = hash(
            frozenset((key, frozenset(value.items())) for key, value in data.items())
        )
        tacks = man.counter(
            total=len(levels), desc="Iterating levels:", unit="levels", leave=False
        )

        for gate in levels:
            tacks.update()

            if gate.startswith("OUTPUT"):
                continue
            else:
                name_list = nx.get_node_attributes(graph, "nodeType")
                name = name_list[gate]
                if name.startswith("AND2") or name.startswith("NAND2"):
                    and2_nand2_function(gate, graph, data)
                elif name.startswith("AND3") or name.startswith("NAND3"):
                    and3_nand3_function(gate, graph, data)
                elif name.startswith("OR2") or name.startswith("NOR2"):
                    or2_nor2_function(gate, graph, data)
                elif name.startswith("OR3") or name.startswith("NOR3"):
                    or3_nor3_function(gate, graph, data)
                elif name.startswith("XOR2") or name.startswith("XNOR2"):
                    xor_xnor_function(gate, graph, data)
                elif name.startswith("DFFSR"):
                    dffrs_function(gate, graph, data)
                elif name.startswith("DFF"):
                    dff_function(gate, graph, data)
                elif name.startswith("NOT") or name.startswith("INVX"):
                    not_function(gate, graph, data)
                elif name.startswith("AOI21"):
                    aoi21_function(gate, graph, data)
                elif name.startswith("AOI22"):
                    aoi22_function(gate, graph, data)
                elif name.startswith("OAI21"):
                    oai21_function(gate, graph, data)
                elif name.startswith("OAI22"):
                    oai22_function(gate, graph, data)
                elif name.startswith("MUX2X1"):
                    mux2x1_function(gate, graph, data)
                else:
                    sys.exit(
                        "In calculation_observability.py unrecognised gate with NAME: {}".format(
                            gate
                        )
                    )

        tacks.close()

    man.stop()

    return data


def dffrs_function(gate, graph, data):
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # active-high asynchronous reset pin r and s
    # print(output_pin_list)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "R":
            tmp_r = edge[(0)]
        elif output_pin == "S":
            tmp_s = edge[(0)]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "S":
                    tmp_s = edge[(0)]
                elif i == "R":
                    tmp_r = edge[(0)]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "S":
                    tmp_s = edge[(0)]
                elif i == "R":
                    tmp_r = edge[(0)]
        elif len(output_pin) == 4:
            for i in output_pin:
                if i == "S":
                    tmp_s = edge[(0)]
                elif i == "R":
                    tmp_r = edge[(0)]

    if tmp_s.startswith("INPUT_CONSTANT_1") and tmp_r.startswith("INPUT_CONSTANT_1"):
        dff_function(gate, graph, data)
    elif tmp_s.startswith("INPUT_CONSTANT_1"):
        s_r_status = "s_deactivated"
        (
            cc0_clk,
            cc0_d,
            cc0_r,
            cc1_clk,
            cc1_d,
            cc1_r,
            edge_clk,
            edge_d,
            edge_r,
        ) = current_dffrs(gate, graph, data, s_r_status)
        # cc1_r deactivated: !R, !1=0

        co_d = data[gate]["CO"] + cc1_clk + cc0_clk + cc1_r  # (!R) reset deactivated
        co_r = (
            data[gate]["CO"] + data[gate]["CC1"] + cc0_r + cc1_clk + cc0_clk
        )  # (!R) reset activated
        co_clk = (
            data[gate]["CO"]
            + cc1_clk
            + cc0_clk
            + min(
                data[gate]["CC1"] + cc0_d,
                data[gate]["CC1"] + cc0_r,
                data[gate]["CC0"] + cc1_r + cc1_d,
            )
        )

        data[edge_clk]["CO"] = min(data[edge_clk]["CO"], co_clk)
        data[edge_d]["CO"] = min(data[edge_d]["CO"], co_d)
        data[edge_r]["CO"] = min(data[edge_r]["CO"], co_r)

    elif tmp_r.startswith("INPUT_CONSTANT_1"):
        s_r_status = "r_deactivated"
        (
            cc0_clk,
            cc0_d,
            cc0_s,
            cc1_clk,
            cc1_d,
            cc1_s,
            edge_clk,
            edge_d,
            edge_s,
        ) = current_dffrs(gate, graph, data, s_r_status)
        # cc1_s deactivated: !S, !1=0

        # synchron calculation:
        co_d = data[gate]["CO"] + cc0_clk + cc1_clk + cc1_s  # (!S) deactivated
        co_s = (
            data[gate]["CO"] + data[gate]["CC0"] + cc0_s + cc0_clk + cc1_clk
        )  # (!S) activated
        co_clk = (
            data[gate]["CO"]
            + cc0_clk
            + cc1_clk
            + min(
                data[gate]["CC1"] + cc0_d + cc1_s,
                data[gate]["CC0"] + cc0_s,
                data[gate]["CC0"] + cc1_d,
            )
        )

        data[edge_clk]["CO"] = min(data[edge_clk]["CO"], co_clk)
        data[edge_d]["CO"] = min(data[edge_d]["CO"], co_d)
        data[edge_s]["CO"] = min(data[edge_s]["CO"], co_s)

    else:
        s_r_status = "s_r_not_deactivated"
        (
            cc0_clk,
            cc0_d,
            cc0_r,
            cc0_s,
            cc1_clk,
            cc1_d,
            cc1_r,
            cc1_s,
            edge_clk,
            edge_d,
            edge_r,
            edge_s,
        ) = current_dffrs(gate, graph, data, s_r_status)
        # cc1_r deactivated: !R, !1=0
        # cc1_s deactivated: !S, !1=0

        # calculation synchron:
        co_d = data[gate]["CO"] + cc0_clk + cc1_clk + cc1_s + cc1_r
        co_r = (
            data[gate]["CO"] + data[gate]["CC1"] + cc0_r + cc1_clk + cc0_clk + cc1_s
        )  # set deactivated
        co_s = (
            data[gate]["CO"] + data[gate]["CC0"] + cc0_s + cc0_clk + cc1_clk + cc1_r
        )  # reset deactivated
        co_clk = (
            data[gate]["CO"]
            + cc0_clk
            + cc1_clk
            + min(
                data[gate]["CC1"] + cc0_d + cc1_s,
                data[gate]["CC0"] + cc0_s + cc1_r,
                data[gate]["CC1"] + cc0_r + cc1_s,
                data[gate]["CC0"] + cc1_r + cc1_d,
            )
        )

        data[edge_clk]["CO"] = min(data[edge_clk]["CO"], co_clk)
        data[edge_d]["CO"] = min(data[edge_d]["CO"], co_d)
        data[edge_s]["CO"] = min(data[edge_r]["CO"], co_s)
        data[edge_r]["CO"] = min(data[edge_r]["CO"], co_r)


def aoi21_function(gate, graph, data):
    """and-or-inverter 3 inputs A, B, C and 1 output Y,
    node_function: [('Y', '(!((A&B)+C))')]"""
    cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c, edge_a, edge_b, edge_c = current_oai_aoi(
        gate, graph, data
    )

    # controllability from and-gate
    cc0_and = min(cc0_a, cc0_b)

    # observability from nor-gate
    co_a_nor = data[gate]["CO"] + cc0_c
    co_c = data[gate]["CO"] + cc0_and + 1

    # observability from and-gate
    co_a = co_a_nor + cc1_b + 1
    co_b = co_a_nor + cc1_a + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b)

    data[edge_c]["CO"] = min(data[edge_c]["CO"], co_c)


def aoi22_function(gate, graph, data):
    """and-or-inverter 4 inputs A, B, C, D and one output Y,
    node_function: [('Y', '(!((A&B)+(C&D)))')]"""
    (
        cc1_a,
        cc1_b,
        cc1_c,
        cc1_d,
        cc0_a,
        cc0_b,
        cc0_c,
        cc0_d,
        edge_a,
        edge_b,
        edge_c,
        edge_d,
    ) = current_oai_aoi(gate, graph, data)

    # controllability from and-gate
    cc0_and_1 = min(cc0_a, cc0_b)
    cc0_and_2 = min(cc0_c, cc0_d)

    # observability from nor-gate
    co_a_nor = data[gate]["CO"] + cc0_and_2
    co_b_nor = data[gate]["CO"] + cc0_and_1

    # observability from and-gate
    co_a = co_a_nor + cc1_b + 1
    co_b = co_a_nor + cc1_a + 1

    co_c = co_b_nor + cc1_d + 1
    co_d = co_b_nor + cc1_c + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b)

    data[edge_c]["CO"] = min(data[edge_c]["CO"], co_c)

    data[edge_d]["CO"] = min(data[edge_d]["CO"], co_d)


def oai21_function(gate, graph, data):
    """or-and-inverter 3 inputs A, B, C and 1 output Y,
    node_function: [('Y', '(!((A+B)&C))')]"""

    cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c, edge_a, edge_b, edge_c = current_oai_aoi(
        gate, graph, data
    )

    # controllability cc1 from or-gate
    cc1_or = min(cc1_a, cc1_b)

    # nand-gate
    co_a_nand = data[gate]["CO"] + cc1_c

    co_c = data[gate]["CO"] + cc1_or + 1

    # or-gate
    co_a = co_a_nand + cc0_b + 1
    co_b = co_a_nand + cc0_a + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b)

    data[edge_c]["CO"] = min(data[edge_c]["CO"], co_c)


def oai22_function(gate, graph, data):
    """or-and-inverter 4 inputs A, B, C, D and one output Y,
    node_function: [('Y', '(!((A+B)&(C+D)))')]"""
    (
        cc1_a,
        cc1_b,
        cc1_c,
        cc1_d,
        cc0_a,
        cc0_b,
        cc0_c,
        cc0_d,
        edge_a,
        edge_b,
        edge_c,
        edge_d,
    ) = current_oai_aoi(gate, graph, data)

    # cc1 from or-gates
    cc1_or_1 = min(cc1_a, cc1_b)
    cc1_or_2 = min(cc1_c, cc1_d)

    co_or_ab = data[gate]["CO"] + cc1_or_2
    co_or_cd = data[gate]["CO"] + cc1_or_1

    co_a_or = co_or_ab + cc0_b + 1
    co_b_or = co_or_ab + cc0_a + 1

    co_c_or = co_or_cd + cc0_d + 1
    co_d_or = co_or_cd + cc0_c + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_or)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b_or)

    data[edge_c]["CO"] = min(data[edge_c]["CO"], co_c_or)

    data[edge_d]["CO"] = min(data[edge_d]["CO"], co_d_or)


def mux2x1_function(gate, graph, data):
    """multiplexer 3 inputs A, B, S and 1 output Y,
    node-function: [('Y', '(!((S&A) + (!S&B)))')]"""
    cc0_a, cc0_b, cc0_s, cc1_a, cc1_b, cc1_s, edge_a, edge_b, edge_s = current_mux(
        gate, graph, data
    )

    # controllability cc1 from nand-gate
    cc0_and_1 = min(cc0_s, cc0_a)
    cc0_and_2 = min(cc0_s, cc0_b)

    # observability from nor-gate
    co_a_nor = data[gate]["CO"] + cc0_and_2
    co_b_nor = data[gate]["CO"] + cc0_and_1

    # observability from and-gate
    co_a = co_a_nor + cc1_s + 1
    co_s = co_a_nor + cc1_a + 1

    co_b = co_b_nor + cc1_s + 1
    co_ns = co_b_nor + cc1_b + 1

    # updating new values in data
    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b)

    data[edge_s]["CO"] = min(data[edge_s]["CO"], co_s, co_ns)


def and2_nand2_function(gate, graph, data):
    """function for calculating the observability of a 'and' or 'nand' gate
    inputs:
    gate: specific nand gate with number
    graph: gate-netlist of the graph
    data: current CC0, CC1 und CO values of the gates """
    cc1_a, cc1_b, edge_a, edge_b = current_cc1(gate, graph, data)

    co_a_and = data[gate]["CO"] + cc1_b + 1
    co_b_and = data[gate]["CO"] + cc1_a + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_and)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b_and)


def and3_nand3_function(gate, graph, data):
    cc1_a, cc1_b, cc1_c, edge_a, edge_b, edge_c = current_cc1_3_input(gate, graph, data)

    co_a_and = data[gate]["CO"] + cc1_b + cc1_c + 1
    co_b_and = data[gate]["CO"] + cc1_a + cc1_c + 1
    co_c_and = data[gate]["CO"] + cc1_a + cc1_b + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_and)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b_and)

    data[edge_c]["CO"] = min(data[edge_c]["CO"], co_c_and)


def or2_nor2_function(gate, graph, data):
    """function for calculating the observability of a 'or' or 'nor' gate
    inputs:
    gate: specific nand gate with number
    graph: gate-netlist of the graph
    data: current CC0, CC1 und CO values of the gates """
    cc0_a, cc0_b, edge_a, edge_b = current_cc0(gate, graph, data)

    co_a_or = data[gate]["CO"] + cc0_b + 1
    co_b_or = data[gate]["CO"] + cc0_a + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_or)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b_or)


def or3_nor3_function(gate, graph, data):
    cc0_a, cc0_b, cc0_c, edge_a, edge_b, edge_c = current_cc0_3_input(gate, graph, data)

    co_a_or = data[gate]["CO"] + cc0_b + cc0_c + 1
    co_b_or = data[gate]["CO"] + cc0_a + cc0_c + 1
    co_c_or = data[gate]["CO"] + cc0_a + cc0_b + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_or)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b_or)

    data[edge_c]["CO"] = min(data[edge_c]["CO"], co_c_or)


def xor_xnor_function(gate, graph, data):
    """function for calculating the observability of a 'xor' or 'xnor' gate
    inputs:
    gate: specific nand gate with number
    graph: gate-netlist of the graph
    data: current CC0, CC1 und CO values of the gates """
    cc0_a, cc0_b, edge_a, edge_b = current_cc0(gate, graph, data)
    cc1_a, cc1_b, _, _ = current_cc1(gate, graph, data)

    co_a_xor = data[gate]["CO"] + min(cc0_b, cc1_b) + 1
    co_b_xor = data[gate]["CO"] + min(cc0_a, cc1_a) + 1

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_xor)

    data[edge_b]["CO"] = min(data[edge_b]["CO"], co_b_xor)


def not_function(gate, graph, data):
    """not_function"""
    co_a_not = data[gate]["CO"] + 1

    for edge in graph.in_edges(gate):
        edge_a = edge[(0)]

    data[edge_a]["CO"] = min(data[edge_a]["CO"], co_a_not)


def dff_function(gate, graph, data):
    """dff """
    cc0_clk, cc0_d, cc1_clk, cc1_d, edge_clk, edge_d = current_dff(gate, graph, data)

    cc0_q = data[gate]["CC0"]
    cc1_q = data[gate]["CC1"]
    # minimum self decision for clk cause cc0_q+cc1_d also a case in my opinion
    co_clk = data[gate]["CO"] + cc1_clk + cc0_clk + min(cc1_q + cc0_d, cc0_q + cc1_d)
    co_d = data[gate]["CO"] + cc1_clk + cc0_clk

    data[edge_clk]["CO"] = min(data[edge_clk]["CO"], co_clk)

    data[edge_d]["CO"] = min(data[edge_d]["CO"], co_d)


def current_cc0(gate, graph, data):
    """function for reading the controllability cc0 values from the storage 'data'
    inputs:
    gate: name of the current viewed gate
    graph: gate-netlist of the graph in readable python format
    data: current CC0, CC1 und CO values of the gates
    outputs:
    cc0_a: CC0 value of the input_a from the gate
    cc0_b: CC0 value of the input_b from the gate
    edge_a: name of the input_a from the gate
    edge_b: name of the input_b from the gate"""
    # print(graph.in_edges(gate))
    # print(graph.out_edges(gate))
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        if len(output_pin) == 1:
            if output_pin == "A":
                cc0_a = data[edge[(0)]]["CC0"]
                edge_a = edge[(0)]
            elif output_pin == "B":
                cc0_b = data[edge[(0)]]["CC0"]
                edge_b = edge[(0)]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    cc0_a = data[edge[(0)]]["CC0"]
                    edge_a = edge[(0)]
                elif i == "B":
                    cc0_b = data[edge[(0)]]["CC0"]
                    edge_b = edge[(0)]

    return cc0_a, cc0_b, edge_a, edge_b


def current_cc0_3_input(gate, graph, data):
    """calculation for cc0 for 3 inputs in a gate"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        if len(output_pin) == 1:
            if output_pin == "A":
                cc0_a = data[edge[(0)]]["CC0"]
                edge_a = edge[(0)]
            elif output_pin == "B":
                cc0_b = data[edge[(0)]]["CC0"]
                edge_b = edge[(0)]
            elif output_pin == "C":
                cc0_c = data[edge[(0)]]["CC0"]
                edge_c = edge[(0)]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    cc0_a = data[edge[(0)]]["CC0"]
                    edge_a = edge[(0)]
                elif i == "B":
                    cc0_b = data[edge[(0)]]["CC0"]
                    edge_b = edge[(0)]
                elif i == "C":
                    cc0_c = data[edge[(0)]]["CC0"]
                    edge_c = edge[(0)]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    cc0_a = data[edge[(0)]]["CC0"]
                    edge_a = edge[(0)]
                elif i == "B":
                    cc0_b = data[edge[(0)]]["CC0"]
                    edge_b = edge[(0)]
                elif i == "C":
                    cc0_c = data[edge[(0)]]["CC0"]
                    edge_c = edge[(0)]

    return cc0_a, cc0_b, cc0_c, edge_a, edge_b, edge_c


def current_cc1(gate, graph, data):
    """function for reading the controllability cc1 values from the storage 'data'
    inputs:
    gate: name of the current viewed gate
    graph: gate-netlist of the graph in readable python format
    data: current CC0, CC1 und CO values of the gates
    outputs:
    cc0_a: CC0 value of the input_a from the gate
    cc0_b: CC0 value of the input_b from the gate
    edge_a: name of the input_a from the gate
    edge_b: name of the input_b from the gate"""
    # print(graph.in_edges(gate))
    # print(graph.out_edges(gate))

    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        if len(output_pin) == 1:
            if output_pin == "A":
                cc1_a = data[edge[(0)]]["CC1"]
                edge_a = edge[(0)]
            elif output_pin == "B":
                cc1_b = data[edge[(0)]]["CC1"]
                edge_b = edge[(0)]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    cc1_a = data[edge[(0)]]["CC1"]
                    edge_a = edge[(0)]
                elif i == "B":
                    cc1_b = data[edge[(0)]]["CC1"]
                    edge_b = edge[(0)]

    return cc1_a, cc1_b, edge_a, edge_b


def current_cc1_3_input(gate, graph, data):
    """calculation for cc1 for 3 inputs in a gate"""
    counter = 0
    for edge in graph.in_edges(gate):
        if counter == 0:
            cc1_a = data[edge[(0)]]["CC1"]
            edge_a = edge[(0)]
            counter = 1
        elif counter == 1:
            cc1_b = data[edge[(0)]]["CC1"]
            edge_b = edge[(0)]
            counter = 2
        else:
            cc1_c = data[edge[(0)]]["CC1"]
            edge_c = edge[(0)]

    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        if len(output_pin) == 1:
            if output_pin == "A":
                cc1_a = data[edge[(0)]]["CC1"]
                edge_a = edge[(0)]
            elif output_pin == "B":
                cc1_b = data[edge[(0)]]["CC1"]
                edge_b = edge[(0)]
            elif output_pin == "C":
                cc1_c = data[edge[(0)]]["CC1"]
                edge_c = edge[(0)]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    cc1_a = data[edge[(0)]]["CC1"]
                    edge_a = edge[(0)]
                elif i == "B":
                    cc1_b = data[edge[(0)]]["CC1"]
                    edge_b = edge[(0)]
                elif i == "C":
                    cc1_c = data[edge[(0)]]["CC1"]
                    edge_c = edge[(0)]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    cc1_a = data[edge[(0)]]["CC1"]
                    edge_a = edge[(0)]
                elif i == "B":
                    cc1_b = data[edge[(0)]]["CC1"]
                    edge_b = edge[(0)]
                elif i == "C":
                    cc1_c = data[edge[(0)]]["CC1"]
                    edge_c = edge[(0)]

    return cc1_a, cc1_b, cc1_c, edge_a, edge_b, edge_c


def current_dff(gate, graph, data):
    """difference between d and clk line for right parsing"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # print(output_pin_list)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "CLK":
            edge_clk = edge[(0)]
            cc0_clk = data[edge_clk]["CC0"]
            cc1_clk = data[edge_clk]["CC1"]
        elif output_pin == "D":
            edge_d = edge[(0)]
            cc0_d = data[edge_d]["CC0"]
            cc1_d = data[edge_d]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "CLK":
                    edge_clk = edge[(0)]
                    cc0_clk = data[edge_clk]["CC0"]
                    cc1_clk = data[edge_clk]["CC1"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc0_d = data[edge_d]["CC0"]
                    cc1_d = data[edge_d]["CC1"]

    return cc0_clk, cc0_d, cc1_clk, cc1_d, edge_clk, edge_d


def current_dffrs(gate, graph, data, s_r_status):
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # print(output_pin_list)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "CLK":
            edge_clk = edge[(0)]
            cc0_clk = data[edge_clk]["CC0"]
            cc1_clk = data[edge_clk]["CC1"]
        elif output_pin == "D":
            edge_d = edge[(0)]
            cc0_d = data[edge_d]["CC0"]
            cc1_d = data[edge_d]["CC1"]
        elif output_pin == "R":
            edge_r = edge[(0)]
            cc0_r = data[edge_r]["CC0"]
            cc1_r = data[edge_r]["CC1"]
        elif output_pin == "S":
            edge_s = edge[(0)]
            cc0_s = data[edge_s]["CC0"]
            cc1_s = data[edge_s]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "CLK":
                    edge_clk = edge[(0)]
                    cc0_clk = data[edge_clk]["CC0"]
                    cc1_clk = data[edge_clk]["CC1"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc0_d = data[edge_d]["CC0"]
                    cc1_d = data[edge_d]["CC1"]
                elif i == "R":
                    edge_r = edge[(0)]
                    cc0_r = data[edge_r]["CC0"]
                    cc1_r = data[edge_r]["CC1"]
                elif i == "S":
                    edge_s = edge[(0)]
                    cc0_s = data[edge_s]["CC0"]
                    cc1_s = data[edge_s]["CC1"]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "CLK":
                    edge_clk = edge[(0)]
                    cc0_clk = data[edge_clk]["CC0"]
                    cc1_clk = data[edge_clk]["CC1"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc0_d = data[edge_d]["CC0"]
                    cc1_d = data[edge_d]["CC1"]
                elif i == "R":
                    edge_r = edge[(0)]
                    cc0_r = data[edge_r]["CC0"]
                    cc1_r = data[edge_r]["CC1"]
                elif i == "S":
                    edge_s = edge[(0)]
                    cc0_s = data[edge_s]["CC0"]
                    cc1_s = data[edge_s]["CC1"]
        elif len(output_pin) == 4:
            for i in output_pin:
                if i == "CLK":
                    edge_clk = edge[(0)]
                    cc0_clk = data[edge_clk]["CC0"]
                    cc1_clk = data[edge_clk]["CC1"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc0_d = data[edge_d]["CC0"]
                    cc1_d = data[edge_d]["CC1"]
                elif i == "R":
                    edge_r = edge[(0)]
                    cc0_r = data[edge_r]["CC0"]
                    cc1_r = data[edge_r]["CC1"]
                elif i == "S":
                    edge_s = edge[(0)]
                    cc0_s = data[edge_s]["CC0"]
                    cc1_s = data[edge_s]["CC1"]

    if s_r_status == "s_deactivated":
        return cc0_clk, cc0_d, cc0_r, cc1_clk, cc1_d, cc1_r, edge_clk, edge_d, edge_r
    elif s_r_status == "r_deactivated":
        return cc0_clk, cc0_d, cc0_s, cc1_clk, cc1_d, cc1_s, edge_clk, edge_d, edge_s
    elif s_r_status == "s_r_not_deactivated":
        return (
            cc0_clk,
            cc0_d,
            cc0_r,
            cc0_s,
            cc1_clk,
            cc1_d,
            cc1_r,
            cc1_s,
            edge_clk,
            edge_d,
            edge_r,
            edge_s,
        )
    else:
        sys.exit(
            "in input_nodes_values_dffrs() s_r_status unknown: {}".format(s_r_status)
        )


def current_oai_aoi(gate, graph, data):
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    # print(output_pin_list)
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "A":
            edge_a = edge[(0)]
            cc1_a = data[edge_a]["CC1"]
            cc0_a = data[edge_a]["CC0"]
        elif output_pin == "B":
            edge_b = edge[(0)]
            cc1_b = data[edge_b]["CC1"]
            cc0_b = data[edge_b]["CC0"]
        elif output_pin == "C":
            edge_c = edge[(0)]
            cc1_c = data[edge_c]["CC1"]
            cc0_c = data[edge_c]["CC0"]
        elif output_pin == "D":
            edge_d = edge[(0)]
            cc1_d = data[edge_d]["CC1"]
            cc0_d = data[edge_d]["CC0"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    edge_a = edge[(0)]
                    cc1_a = data[edge_a]["CC1"]
                    cc0_a = data[edge_a]["CC0"]
                elif i == "B":
                    edge_b = edge[(0)]
                    cc1_b = data[edge_b]["CC1"]
                    cc0_b = data[edge_b]["CC0"]
                elif i == "C":
                    edge_c = edge[(0)]
                    cc1_c = data[edge_c]["CC1"]
                    cc0_c = data[edge_c]["CC0"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc1_d = data[edge_d]["CC1"]
                    cc0_d = data[edge_d]["CC0"]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    edge_a = edge[(0)]
                    cc1_a = data[edge_a]["CC1"]
                    cc0_a = data[edge_a]["CC0"]
                elif i == "B":
                    edge_b = edge[(0)]
                    cc1_b = data[edge_b]["CC1"]
                    cc0_b = data[edge_b]["CC0"]
                elif i == "C":
                    edge_c = edge[(0)]
                    cc1_c = data[edge_c]["CC1"]
                    cc0_c = data[edge_c]["CC0"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc1_d = data[edge_d]["CC1"]
                    cc0_d = data[edge_d]["CC0"]
        elif len(output_pin) == 4:
            for i in output_pin:
                if i == "A":
                    edge_a = edge[(0)]
                    cc1_a = data[edge_a]["CC1"]
                    cc0_a = data[edge_a]["CC0"]
                elif i == "B":
                    edge_b = edge[(0)]
                    cc1_b = data[edge_b]["CC1"]
                    cc0_b = data[edge_b]["CC0"]
                elif i == "C":
                    edge_c = edge[(0)]
                    cc1_c = data[edge_c]["CC1"]
                    cc0_c = data[edge_c]["CC0"]
                elif i == "D":
                    edge_d = edge[(0)]
                    cc1_d = data[edge_d]["CC1"]
                    cc0_d = data[edge_d]["CC0"]

    name_list = nx.get_node_attributes(graph, "nodeType")
    name = name_list[gate]

    if name.startswith("AOI21") or name.startswith("OAI21"):
        return cc0_a, cc0_b, cc0_c, cc1_a, cc1_b, cc1_c, edge_a, edge_b, edge_c
    elif name.startswith("AOI22") or name.startswith("OAI22"):
        return (
            cc1_a,
            cc1_b,
            cc1_c,
            cc1_d,
            cc0_a,
            cc0_b,
            cc0_c,
            cc0_d,
            edge_a,
            edge_b,
            edge_c,
            edge_d,
        )
    else:
        sys.exit("No AOI21, AOI22, OAI21, OAI22, NAME_iSSUE: {}".format(gate))


def current_mux(gate, graph, data):
    """input values for mux with A, B, S"""
    output_pin_list = nx.get_edge_attributes(graph, "inpin")
    for edge in graph.in_edges(gate):
        output_pin = output_pin_list[edge]
        # print(output_pin)
        if output_pin == "A":
            edge_a = edge[(0)]
            cc0_a = data[edge_a]["CC0"]
            cc1_a = data[edge_a]["CC1"]
        elif output_pin == "B":
            edge_b = edge[(0)]
            cc0_b = data[edge_b]["CC0"]
            cc1_b = data[edge_b]["CC1"]
        elif output_pin == "S":
            edge_s = edge[(0)]
            cc0_s = data[edge_s]["CC0"]
            cc1_s = data[edge_s]["CC1"]
        elif len(output_pin) == 2:
            for i in output_pin:
                if i == "A":
                    edge_a = edge[(0)]
                    cc0_a = data[edge_a]["CC0"]
                    cc1_a = data[edge_a]["CC1"]
                elif i == "B":
                    edge_b = edge[(0)]
                    cc0_b = data[edge_b]["CC0"]
                    cc1_b = data[edge_b]["CC1"]
                elif i == "S":
                    edge_s = edge[(0)]
                    cc0_s = data[edge_s]["CC0"]
                    cc1_s = data[edge_s]["CC1"]
        elif len(output_pin) == 3:
            for i in output_pin:
                if i == "A":
                    edge_a = edge[(0)]
                    cc0_a = data[edge_a]["CC0"]
                    cc1_a = data[edge_a]["CC1"]
                elif i == "B":
                    edge_b = edge[(0)]
                    cc0_b = data[edge_b]["CC0"]
                    cc1_b = data[edge_b]["CC1"]
                elif i == "S":
                    edge_s = edge[(0)]
                    cc0_s = data[edge_s]["CC0"]
                    cc1_s = data[edge_s]["CC1"]
        else:
            sys.exit(
                "In aoi21_function new input, no A, B, S, output_pin NAME: {}".format(
                    output_pin
                )
            )
    return cc0_a, cc0_b, cc0_s, cc1_a, cc1_b, cc1_s, edge_a, edge_b, edge_s
