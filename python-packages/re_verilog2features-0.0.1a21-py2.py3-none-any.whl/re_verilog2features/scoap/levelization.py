"""own levelization function"""
from copy import deepcopy


def create_levelization(inputlist, circuitdescription, graph):
    """levelization of the gates based on number of inputs and outputs"""
    gates = deepcopy(circuitdescription[1])

    levels = deepcopy([circuitdescription[0]])
    visited_gates = deepcopy(inputlist)
    next_level = []
    while gates:
        for gate in gates[0:]:

            current_status = []

            for edge in graph.in_edges(gate):
                if edge[(0)] in visited_gates:
                    current_status.append("true")
                else:
                    current_status.append("false")
            if current_status.count("true") == len(graph.in_edges(gate)):
                next_level.append(gate)
            if gate == gates[-1]:
                levels.append(next_level)
                integer = len(next_level)

                for i in range(0, integer):
                    gates.remove(next_level[i])
                    visited_gates.append(next_level[i])
                next_level = []
                break

    return levels
