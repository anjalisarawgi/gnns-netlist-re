"""Global argument parsers"""
import argparse
import textwrap as _textwrap
from argparse import ArgumentParser
from warnings import warn

from os import access, R_OK, W_OK
from os.path import isfile
from os.path import isdir
import os.path


def folder_exists_w(folder):
    """Check if folder exists and is writeable.

    :param file: A folder path relative to the user's pwd
    :type file: str
    :return: The folder path as an absolute path, if file exists and is writeable.
    :rtype: str
    :raises AssertionError: If folder is not writeable or does not exist.
    """
    folder = os.path.abspath(folder)
    os.makedirs(folder, exist_ok=True)
    assert isdir(folder) and access(
        folder, W_OK
    ), "Folder {} doesn't exist or isn't writable.".format(folder)
    return folder


def file_exists(file):
    """Check if file exists and is readable.

    :param file: A filepath relative to the user's pwd
    :type file: str
    :return: The filepath as an absolute path, if file exists and is readable.
    :rtype: str
    :raises AssertionError: If file is not readable or does not exist.

    """
    file = os.path.abspath(file)
    assert isfile(file) and access(
        file, R_OK
    ), "File {} doesn't exist or isn't readable.".format(file)
    return file


# source : https://stackoverflow.com/a/32974697
class MultilineFormatter(argparse.HelpFormatter):
    def _fill_text(self, text, width, indent):
        text = self._whitespace_matcher.sub(" ", text).strip()
        paragraphs = text.split("|n ")
        multiline_text = ""
        for paragraph in paragraphs:
            formatted_paragraph = (
                _textwrap.fill(
                    paragraph, width, initial_indent=indent, subsequent_indent=indent
                )
                + "\n\n"
            )
            multiline_text = multiline_text + formatted_paragraph
        return multiline_text


class CustomParser(ArgumentParser):
    """Improve the arparse.Argumentparser"""

    @property
    def parsed_args(self):
        """Get parsed args from this argument parser.
        Will parse the sys.argv arguments if not yet done
        """
        if self._parsed_args is not None:
            return self._parsed_args
        else:
            warn(
                "Accessed parsed_args before parsing args, will parse right now!",
                RuntimeWarning,
            )
            return self.parse_args_main()

    @parsed_args.setter
    def parsed_args(self, args):
        """Set parsed args. Should not be used outside this class"""
        self._parsed_args = args
        return self._parsed_args

    def parse_args_main(self, args=None, namespace=None):
        """Parse the sys.argv to this class's namespace for easy global access"""
        if namespace is None:
            namespace = self
        self._parsed_args = super().parse_args(args=args, namespace=namespace)
        return self._parsed_args


GLOBAL_PARSER = None


def init_global_parser(*args, **kwargs):
    global GLOBAL_PARSER
    GLOBAL_PARSER = CustomParser(formatter_class=MultilineFormatter, *args, **kwargs)
