"""Main file for `make_scoap`
"""

import logging
import os

import numpy as np
import pandas as pd
import tueisec_myparsing.myparsing_ply as myparsing
from tueisec_myparsing.graph_output_file_formats import GraphOutputFormat

import re_verilog2features.scoap as scoap
import re_verilog2features.scoap.calculation_controllability
import re_verilog2features.scoap.calculation_observability
import re_verilog2features.scoap.graph_list
import re_verilog2features.scoap.levelization
import re_verilog2features.scoap.levelization_observability
import re_verilog2features.scoap.run_and_parse_tmax
from re_verilog2features.globalArgParse import GLOBAL_PARSER

glogger = logging.getLogger(__name__)

try:  # sphinx barrier, because GLOBAL_PARSER will fail to import
    GLOBAL_PARSER.add_argument(
        "design",
        help="Imput graph file. "
        "This application can read (txt, gml, graphml, gexf, pq, json). "
        "If you use `--use_tmax`, instead give a *.v file!",
    )

    GLOBAL_PARSER.add_argument(
        "-o",
        "--output_path",
        help="The filename where output df will be stored. "
        "Remember to set your wanted output format with `-t`.",
    )

    GLOBAL_PARSER.add_argument(
        "-t",
        "--output-type",
        help="The output filetype. "
        "Two formats are supported: "
        "Parquet (pq) is recommended, fast and compressed. "
        "CSV (csv) is old, slow and uncompressed. ",
        required=True,
        choices=["csv", "pq"],
    )

    # this tool so far only accepts osu035
    # GLOBAL_PARSER.add_argument(
    #     "-l",
    #     "--cell_library",
    #     help="The cell library name to use. Default: osu035",
    #     default="osu035",
    # )

    GLOBAL_PARSER.add_argument(
        "--use_tmax",
        help="Use tetramax for calculation. Make sure that you have tmax in "
        "your path (module load ...). The `design` ust be a *.v file!",
        action="store_true",
    )

except BaseException:
    glogger.error("GLOBAL_PARSER unitialized. Are you really sure that you init'ed it?")

LIB_PATH_DEFAULT = (
    "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/"
    "share/qflow/tech/osu035/osu035_stdcells.v"
)


def data_list(G):
    """Generate an empty data

    :param G: input graph. nodes will be used as keys for returned data
    :type G: networkx.Graph
    :return: empty CC/CO dict
    :rtype: dict
    """
    nodes = list(G.nodes)

    data = {}
    for node in nodes:
        data[node] = {
            "CC0": np.Inf,
            "CC1": np.Inf,
            "CO": np.Inf,
        }
    return data


def make_scoap():
    """Main method of this file. uses the data in GLOBAL_PARSER.

    :raises ValueError: if GLOBAL_PARSER.output_type is neither pd nor csv.
    """
    filepath = GLOBAL_PARSER.design
    if os.path.dirname(GLOBAL_PARSER.output_path):
        os.makedirs(os.path.dirname(GLOBAL_PARSER.output_path), exist_ok=True)
    outfilepath = GLOBAL_PARSER.output_path
    if os.path.exists(outfilepath):
        glogger.critical(
            "Found {}, can not continue. If you do not want "
            "that, delete the file.".format(outfilepath)
        )
        exit()

    if GLOBAL_PARSER.use_tmax:
        df = make_scoap_tmax(filepath, os.path.dirname(outfilepath))
    else:
        df = make_scoap_python(filepath)

    if GLOBAL_PARSER.output_type == "pq":
        df.to_parquet(outfilepath, engine="pyarrow", compression="snappy")
    elif GLOBAL_PARSER.output_type == "csv":
        df.to_csv(outfilepath)
    else:
        raise ValueError("Unknown output format {}!".format(GLOBAL_PARSER.output_type))
    glogger.warning("Storing for {} finished.".format(filepath))


def make_scoap_tmax(
    filepath, reportfolder, libPath=LIB_PATH_DEFAULT, parsing_logging=False
):
    """use tmax to generate scoap

    ..warning::
        for large designs, this results in a lot of "infinity" values (`M`).

    :param filepath: path of the verilog file to analyze
    :type filepath: str
    :param reportfolder: path of a folder where report.txt shall be written
    :type reportfolder: str
    :param libPath: verilog file that tmax reads as a cell library,
      defaults to LIB_PATH_DEFAULT
    :type libPath: str, optional
    :param parsing_logging: if False, deactivates logging from the parsing of
      the module name, defaults to False
    :type parsing_logging: bool, optional
    :return: scoap dataframe
    :rtype: pandas.DataFrame
    """

    filename = os.path.basename(filepath)

    glogger.info("Parsing file to get some info")
    if not parsing_logging:
        requests_logger = logging.getLogger("tueisec_myparsing")
        requests_logger.setLevel(logging.ERROR)
        requests_logger.propagate = False
    parsed_verilog = myparsing.parse_to_obj(filename, libPath)

    # find module name
    topname = parsed_verilog.module_name

    reportpath = os.path.join(reportfolder, "{}_report.txt".format(topname))
    re_verilog2features.scoap.run_and_parse_tmax.call_tmax(
        filepath, reportpath, topname, libPath
    )
    scoap_data = re_verilog2features.scoap.run_and_parse_tmax.analyse_report(reportpath)
    return scoap_data


def make_scoap_python(filepath):
    """Use python to generate scoap

    :param filepath: path of the graph file to analyze
    :type filepath: str
    :return: scoap dataframe
    :rtype: pandas.DataFrame
    """

    graph = GraphOutputFormat.read_graph_from_filepath(filepath)

    data = data_list(graph)

    (
        inputlist,
        outputlist,
        circuitdescription,
    ) = scoap.graph_list.get_input_output_rest_list(graph)
    glogger.info("Created iolist")
    levels = scoap.levelization.create_levelization(
        inputlist, circuitdescription, graph
    )
    glogger.info("Created levels")
    levels_co = scoap.levelization_observability.levelization_observability(
        outputlist, circuitdescription, graph
    )
    glogger.info("Created levels_co")
    data = scoap.calculation_controllability.calculation_controllability(
        levels, graph, data, outputlist
    )
    glogger.info("Created cc")
    data = scoap.calculation_observability.calculation_observability(
        levels_co, graph, data, outputlist
    )
    glogger.info("Created co")

    df = pd.DataFrame.from_records(data=list(data.values()), index=list(data.keys()))

    return df
