"""Warning: DEPRECATED!
"""

import glob
import importlib
import logging
import os

from re_verilog2features.globalArgParse import GLOBAL_PARSER
from re_verilog2features.globalArgParse import file_exists

import tueisec_myparsing.pool_wrapper as pool_wrapper

glogger = logging.getLogger(__name__)

output_path_default = "outputFiles/{}/csvs_{}/"

try:  # sphinx barrier, because sphinx does not initialize GLOBAL_PARSER and will fail at import
    GLOBAL_PARSER.add_argument(
        "designs",
        nargs="+",
        help="Paths or folders where adjacency lists are located (*.txt/*.graphml.gz). "
        "Note that the designs will be sorted by file size, "
        "as it is more efficient to handle large files first.",
    )

    GLOBAL_PARSER.add_argument("--cores", help="Cores to use for processing", type=int)

    GLOBAL_PARSER.add_argument(
        "--gt_cores",
        help="Cores to use for graphtool. Multiplies by --cores! Default = 1",
        default=1,
        type=int,
    )
    GLOBAL_PARSER.add_argument(
        "--ap_cores",
        help="Cores to use for ARPACK. Multiplies by --cores! Default = 1",
        default=1,
        type=int,
    )

    GLOBAL_PARSER.add_argument(
        "-o",
        "--output_path",
        help="The folder where output files will be stored in a subfolder depending on process name and adjlist folder. Default: "
        + output_path_default,
        default=output_path_default,
    )

    GLOBAL_PARSER.add_argument(
        "-l",
        "--cell_library",
        help="The cell library name to use. Default: osu035",
        default="osu035",
    )

    group = GLOBAL_PARSER.add_mutually_exclusive_group(required=True)

    group.add_argument(
        "--use_nx",
        help="Use networkx for graph calculations. slower, but less bugs",
        action="store_true",
    )

    group.add_argument(
        "--use_fastest",
        help="Use a melange of graph libraries for graph calculations. faster, but maybe some bugs",
        action="store_true",
    )

    GLOBAL_PARSER.add_argument(
        "--overwrite",
        help="Overwrite designs if already in %%output_path%% ",
        action="store_true",
    )

    GLOBAL_PARSER.add_argument(
        "--smallest_first",
        help="By default, the largest designs will be converted first. "
            "With this flag, convert the smallest first. More success, but large "
            "things may come late and badly",
        action="store_false",
    )

    GLOBAL_PARSER.add_argument(
        "--eigs_tolerance",
        help="By default, the eigenvector centrality uses machine precision "
        "as tolerance for eigenvector caluclation. This is precise, but takes time. "
        "Specify another tolerance with this flag.",
        default=0.0,
        type=float,
    )

    GLOBAL_PARSER.add_argument(
        "-f",
        "--additional_features",
        help="specify a Python file that contains a function "
        "`compute_additional_features(graph, result, design_file)` "
        "for the computation of additional features. "
        "This option can be used multiple times.",
        action="append",
        metavar="FILENAME",
        type=file_exists,
    )

    GLOBAL_PARSER.add_argument(
        "--use_node_types",
        help="Use node types as written by `run_write_adjlist --write_node_types`. "
        "Careful: This reads `*.graphml.gz` files, not `*.txt` files.",
        action="store_true",
    )

except:
    glogger.error("GLOBAL_PARSER unitialized. Are you really sure that you init'ed it?")


def multi_run_wrapper(args):
    return get_results(*args)


def get_results(des, output_path):

    # I admmit, this is ugly BUT: We have to set this env variable before
    # importing any thing like numpy, else the env variable has no effect on
    # arpack.
    os.environ["OPENBLAS_NUM_THREADS"] = str(GLOBAL_PARSER.ap_cores)

    from re_verilog2features import create_data
    import networkx as nx
    import pandas as pd

    if GLOBAL_PARSER.use_node_types:
        graph = nx.read_graphml(des)
    else:
        graph = nx.read_adjlist(des, create_using=nx.DiGraph())
    if not len(graph):
        glogger.warning("Design {} is empty. Ignoring".format(des))
        return
    result = {}
    if GLOBAL_PARSER.use_node_types:
        nodeTypes = nx.get_node_attributes(graph, "node_type")
    else:
        nodeTypes = {node: node.split("_")[0] for node in graph.nodes()}
    result = create_data.node_type_ratios(graph, result, nodeTypes, des)
    try:
        if GLOBAL_PARSER.use_nx:
            result = create_data.graph_tests_nx(graph, result, des)
        elif GLOBAL_PARSER.use_fastest:
            result = create_data.graph_tests(graph, result, des)
        else:
            raise NotImplementedError("This should not happen")
    except BaseException as e:
        glogger.exception("Failure in {} due to: ".format(des), exc_info=e)
        return
    result = create_data.input_output_analysis(graph, result, des)

    if GLOBAL_PARSER.additional_features:
        for i, filename in enumerate(GLOBAL_PARSER.additional_features):
            spec = importlib.util.spec_from_file_location(
                "additional_features_{}".format(i), filename
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            result = module.compute_additional_features(graph, result, des)

    # if graphml, we have to split graphml and gz, else csv
    design_name = os.path.splitext(os.path.splitext(os.path.basename(des))[0])[0]
    glogger.info("finished getting stats, now writing csv")

    df_design = pd.DataFrame(result, index=[design_name])
    df_design.to_csv(os.path.join(output_path, design_name + ".csv"))

    return


def make_csv():
    if GLOBAL_PARSER.use_node_types:
        file_postfix = "*.graphml.gz"
    else:
        file_postfix = "*.txt"

    if isinstance(GLOBAL_PARSER.designs, str):
        design_path = GLOBAL_PARSER.designs
        if design_path.endswith(file_postfix[1:]):
            designs = [design_path]
        else:
            designs = glob.glob(os.path.join(design_path, file_postfix))
            glogger.info("Found {} adjacency lists.".format(len(designs)))
    else:
        designs = []
        for design_path in GLOBAL_PARSER.designs:
            if design_path.endswith(file_postfix[1:]):
                designs.append(design_path)
                glogger.info("Found 1 adjacency lists in {}.".format(design_path))
            else:
                add_designs = glob.glob(os.path.join(design_path, file_postfix))
                glogger.info(
                    "Found {} adjacency lists in {}.".format(
                        len(add_designs), design_path
                    )
                )
                designs.extend(add_designs)

    # sort the designs by size, so that the largest or smallest designs are handled first.
    # This improves computation time. Thanks @thielepaul
    designs = sorted(designs, key=lambda x: os.path.getsize(x), reverse=GLOBAL_PARSER.smallest_first)

    mult = []
    for des in designs:
        used_lib = GLOBAL_PARSER.cell_library
        design_folder = os.path.basename(os.path.dirname(des))
        # if graphml, we have to split graphml and gz, else csv
        design_name = os.path.splitext(os.path.splitext(os.path.basename(des))[0])[0]
        output_path = os.path.join(
            GLOBAL_PARSER.output_path.format(used_lib, design_folder)
        )
        os.makedirs(output_path, exist_ok=True)
        if (
            not os.path.isfile(os.path.join(output_path, design_name + ".csv"))
            or GLOBAL_PARSER.overwrite
        ):
            mult.append((des, output_path))
        else:
            glogger.warning("Skipping {}, use --overwrite to overwrite".format(des))

    glogger.debug(str(sorted([m[0] for m in mult])))
    # input("ok?")
    # run in pool

    pool_wrapper.run_in_pool_with_progress(
        multi_run_wrapper, mult, "Processing:", "designs", processes=GLOBAL_PARSER.cores
    )
