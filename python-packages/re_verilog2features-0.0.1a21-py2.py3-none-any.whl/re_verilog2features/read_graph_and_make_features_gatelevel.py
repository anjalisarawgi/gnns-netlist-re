import glob
import importlib
import logging
import os
import multiprocessing
import signal

from re_verilog2features.globalArgParse import GLOBAL_PARSER
from re_verilog2features.globalArgParse import file_exists

from tueisec_myparsing.graph_output_file_formats import GraphOutputFormat
import enlighten

import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd

glogger = logging.getLogger(__name__)

try:  # sphinx barrier, because GLOBAL_PARSER will fail to import
    GLOBAL_PARSER.add_argument(
        "designs",
        nargs="+",
        help="(Nested) folders where graph files are located. "
        "This application can read (txt, gml, graphml, gexf, pq, json). "
        "Note that the designs will be sorted by file size, "
        "as it is more efficient to handle large files first.",
    )

    GLOBAL_PARSER.add_argument("--cores", help="Cores to use for processing", type=int)

    GLOBAL_PARSER.add_argument(
        "--gt_cores",
        help="Cores to use for graphtool. Multiplies by --cores! Default = 1",
        default=1,
        type=int,
    )
    GLOBAL_PARSER.add_argument(
        "--ap_cores",
        help="Cores to use for ARPACK. Multiplies by --cores! Default = 1",
        default=1,
        type=int,
    )

    GLOBAL_PARSER.add_argument(
        "-o",
        "--output_path",
        help="The filepath where output df will be stored. "
        "Filename will be defined by input path. "
        "Remember to set your wanted output format with `-t`.",
        required=True,
    )

    group = GLOBAL_PARSER.add_mutually_exclusive_group(required=True)

    group.add_argument(
        "--use_nx",
        help="Use networkx for graph calculations. slower, but less bugs",
        action="store_true",
    )

    group.add_argument(
        "--use_fastest",
        help="Use a melange of graph libraries for graph calculations. faster, "
        "but maybe some bugs",
        action="store_true",
    )

    group.add_argument(
        "--use_ig",
        help="Use igraph and networkx for graph calculations. Faster, than nx alone,"
         "a tad slower than use_fastest, but no graphtool requirement!",
         action="store_true",
    )

    GLOBAL_PARSER.add_argument(
        "--smallest_first",
        help="By default, the largest designs will be converted first. "
        "With this flag, convert the smallest first. More success, but large "
        "things may come late and badly",
        action="store_false",
    )

    GLOBAL_PARSER.add_argument(
        "--eigs_tolerance",
        help="By default, the eigenvector centrality uses machine precision "
        "as tolerance for eigenvector caluclation. This is precise, but takes time. "
        "Specify another tolerance with this flag.",
        default=0.0,
        type=float,
    )

    GLOBAL_PARSER.add_argument(
        "-f",
        "--additional_features",
        help="specify a Python file that contains a function "
        "`compute_additional_features(graph, result, design_file)` "
        "for the computation of additional features. "
        "This option can be used multiple times.",
        action="append",
        metavar="FILENAME",
        type=file_exists,
    )

    GLOBAL_PARSER.add_argument(
        "--use_node_types",
        help="Use node types if available in your input format. This will "
        "trigger a ValueError and abort if your format does not carry node "
        "type info.",
        action="store_true",
    )

    # TODO: Future possibility.
    # GLOBAL_PARSER.add_argument(
    #     "--append",
    #     help="Add new rows to an existing file. "
    #     "ATTENTION, this method is pretty dumb: It checks if the "
    #     "file exists, and if so, will read it, append data and write back. "
    #     "No check for existing rows is done! This is quite memory-consuming, "
    #     "because appending means concatenating new rows to the old file data."
    # )

except BaseException:
    glogger.error("GLOBAL_PARSER unitialized. Are you really sure that you init'ed it?")


def multi_run_wrapper(args):
    return get_results(*args)


def get_results(filepath):
    # I admmit, this is ugly BUT: We have to set this env variable before
    # importing any thing like numpy, else the env variable has no effect on
    # arpack. Thus THE IMPORTS MUST STAY HERE.
    os.environ["OPENBLAS_NUM_THREADS"] = str(GLOBAL_PARSER.ap_cores)
    os.environ["NUMEXPR_NUM_THREADS"] = "8"

    from re_verilog2features import create_data_gatelevel
    import networkx as nx
    import pandas as pd

    try:
        graph = GraphOutputFormat.read_graph_from_filepath(filepath)        # read all graph formats
    except KeyError as e:
        # This happens for parquet files which are no edgelists. Ignore these
        glogger.info("Could not parse {}. Ignoring".format(filepath))
        return None
    if not len(graph):
        glogger.warning("Design {} is empty. Ignoring".format(filepath))
        return None
    
        
    #remove clk and reset nodes
    clk_and_rst = [
        node
        for node in graph
        if node.lower().find("clk") >= 0
        or node.lower().find("rst") >= 0
    ]
    graph.remove_nodes_from(clk_and_rst)
    allcells = pd.DataFrame(index=pd.Index(graph.nodes(), name="cells"))

    if GLOBAL_PARSER.use_node_types:
        nodeTypes = nx.get_node_attributes(graph, "nodeType")
        if not nodeTypes:
            raise ValueError(
                "Graph data for {} does not contain `nodeType`s".format(filepath)
            )
    else:
        nodeTypes = {node: node.split("_")[0] for node in graph.nodes()}

    #allcells = create_data.node_type_ratios(graph, allcells, nodeTypes, filepath)

    try:
        if GLOBAL_PARSER.use_nx:
            allcells = create_data_gatelevel.graph_tests_nx(graph, allcells, filepath)             
        elif GLOBAL_PARSER.use_fastest:
            allcells = create_data_gatelevel.graph_tests(graph, allcells, filepath)
        elif GLOBAL_PARSER.use_ig:
            allcells = create_data_gatelevel.graph_tests_ig(graph, allcells, filepath)
        else:
            raise NotImplementedError("This should not happen")
    except BaseException as e:
        glogger.exception("Failure in {} due to: ".format(filepath), exc_info=e)
        return None                 
    #allcells = create_data.input_output_analysis(graph, allcells, filepath)        # siehe fragen.doc: Anpassung In/ouput gruppen

    # if GLOBAL_PARSER.additional_features:
    #     for i, filename in enumerate(GLOBAL_PARSER.additional_features):
    #         spec = importlib.util.spec_from_file_location(
    #             "additional_features_{}".format(i), filename
    #         )
    #         module = importlib.util.module_from_spec(spec)
    #         spec.loader.exec_module(module)
    #         result = module.compute_additional_features(graph, result, filepath)

    glogger.info("finished getting stats for {}".format(filepath))
    outfilename=os.path.splitext(os.path.basename(filepath))[0]
    outfilepath = os.path.join(             #hier wird .pq Datei benannt und erstellt in die später ergebnisse kommen
                    GLOBAL_PARSER.output_path,
                    f"features_{outfilename}.pq",
                )
    allcells.to_parquet(outfilepath, engine="pyarrow", compression="snappy")
    return None

def make_features():
    known_extensions_globs = list(GraphOutputFormat.known_extensions_globs())

    Pool = multiprocessing.Pool
    original_sigint_handler = signal.signal(signal.SIGINT, signal.SIG_IGN)
    process_pool = Pool(processes=GLOBAL_PARSER.cores,)
    signal.signal(signal.SIGINT, original_sigint_handler)
    glogger.info("Preparing {} runners.".format(GLOBAL_PARSER.cores))
    try:
        manager = enlighten.get_manager()

        progress_bar_d = manager.counter(
            total=len(GLOBAL_PARSER.designs),
            desc="Processing:",
            unit="graph paths",
            leave=False,
        )
        progress_bar_d.update(0, True)

        if isinstance(GLOBAL_PARSER.designs, str):
            GLOBAL_PARSER.designs = [GLOBAL_PARSER.designs]

        for design_path in GLOBAL_PARSER.designs:

            if os.path.isdir(design_path):
                glogger.warning(
                    "Now globbing {}. This may take a while".format(design_path)
                )
                add_designs = []            # hier alle graph einlesedateien
                for eg in known_extensions_globs:
                    glob_path = os.path.join(design_path, "**", eg)
                    add_designs.extend(glob.glob(glob_path, recursive=True))
                glogger.info(
                    "Found {} graphs in {}.".format(len(add_designs), design_path)
                )
            else:
                add_designs = [design_path]
            if not add_designs:
                glogger.error(
                    "Found no graphs in {}. I will not use this path.".format(
                        design_path
                    )
                )
                continue

            # sort the designs by size, so that the largest or smallest designs
            # are handled first.
            # This improves computation time. Thanks @thielepaul
            add_designs = sorted(
                add_designs,
                key=lambda x: os.path.getsize(x),
                reverse=GLOBAL_PARSER.smallest_first,
            )
            """i=0
             ofpath={}
            for design_nr in add_designs:
                design_nr=design_nr.rsplit('/',1)
                design_nr=design_nr[1].split('.')
                filename="features_"+design_nr[0]
                os.makedirs(GLOBAL_PARSER.output_path, exist_ok=True)
                ofpath[i] = os.path.join(             #hier wird .pq Datei benannt und erstellt in die später ergebnisse kommen
                    GLOBAL_PARSER.output_path,
                    "{}.{}".format(filename, GLOBAL_PARSER.output_type),
                )
                if os.path.exists(ofpath[i]):
                    glogger.error(
                        "Found {}, will ignore this filepath. If you do not want "
                        "that, delete the file.".format(ofpath[i])
                    )
                    continue
                i=i+1
            outfilepath=ofpath[0] """

            mult = ((des,) for des in add_designs)
            progress_bar_c = manager.counter(
                total=len(add_designs), desc="Processing:", unit="graphs", leave=False
            )
            progress_bar_c.update(0, True)

            # TODO: Maybe submit everything, and have a thread that saves
            # periodically (configurable interval)
            # for parquet good idea is to save after xyz rows (100/1000?)
            # = row grouping
            dfs = process_pool.imap_unordered(
                func=multi_run_wrapper, iterable=mult, chunksize=1
            )

            def pbarwrapper(dfs):
                """simple generator decorator that updates the progress bar c upon yield

                :param dfs: iterable
                :type dfs: Iterable
                :yield: item of iterable `dfs`
                :rtype: Any
                """
                for df in dfs:
                    progress_bar_c.update()
                    yield df
                glogger.warning(
                    "Now storing {}. This may take a while".format(design_path)
                )
            # ensure imap is performing
            for _ in pbarwrapper(dfs):
                pass

            # TODO: Implement append
            # if GLOBAL_PARSER.append:
            #     oldtable = pd.read_parquet(outpath)
            #     pd.concat(itertools.chain([oldtable], pbarwrapper(dfs)), axis=0).to_parquet(
            #         outpath, engine="pyarrow", compression="snappy"
            #     )
            # else:
            # if GLOBAL_PARSER.output_type == "pq":
            #     i=0                                     #Hier zurück auf Original
            #     for df_nr in pbarwrapper(dfs):
            #         outfilepath=ofpath[i]
            #         df_nr.to_parquet(outfilepath, engine="pyarrow", compression="snappy")
            #         i=i+1
            # elif GLOBAL_PARSER.output_type == "csv":
            #     for df_nr in pbarwrapper(dfs):
            #         outfilepath=ofpath[i]
            #         i=i+1
            #         df_nr.to_csv(outfilepath)
            # else:
            #     raise ValueError(
            #         "Unknown output format {}!".format(GLOBAL_PARSER.output_type)
            #     )
            glogger.warning("Storing for {} finished.".format(design_path))
            progress_bar_c.close()
            progress_bar_d.update()
    finally:
        process_pool.close()
        process_pool.join()
        progress_bar_d.close()
        manager.stop()


def append_to_parquet_table(dataframe, filepath, writer_dict):
    """Method writes/append dataframes in parquet format.

    This method is used to write pandas DataFrame as pyarrow Table in parquet format.
    If the methods is invoked with writer, it appends dataframe to the already
    written pyarrow table.

    :param dataframe: pd.DataFrame to be written in parquet format.
    :param filepath: target file location for parquet file.
    :param writer_dict: dict of ParquetWriter objects per filepath.
        Will be filled with created ParquetWriters per filepath
    """
    table = pa.Table.from_pandas(dataframe)
    if writer_dict.get(filepath, None) is None:
        if os.path.isfile(filepath):
            glogger.warning(
                "Warning. Found {}, will append. If you do not want that, "
                "delete the file by yourself".format(filepath)
            )
        writer = writer_dict[filepath] = pq.ParquetWriter(filepath, table.schema)
    else:
        writer = writer_dict[filepath]
    writer.write_table(table=table)
