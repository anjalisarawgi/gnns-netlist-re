import pandas as pd
import scipy as sp
import numpy as np
import networkx as nx
import math
import logging

glogger = logging.getLogger(__name__)

def calc_in_flipflop_4(node):
    pass

def calculate_hasegawa_features(graph, df, design_file, config=None):
    """Calculate HT features as given by Hasegawa et al

    That is:
    - fan_in_4
    - fan_in_5
    - in_flipflop_4
    - out_flipflop_3
    - out_flipflop_4
    - in_loop_4
    - out_loop_5
    - in_nearest_pin
    - out_nearest_pout
    - out_nearest_flipflop
    - out_nearest_multiplexer

    :param graph: graph to analyze
    :type graph: networkx.Graph
    :param design_file: name of the design file for debuggin purposes
    :type design_file: str
    :return: returns a result df with index node and columns features
    :rtype: dict
    """
    glogger.info("running hasegawa feature creation")

    # graph = graph.copy()
    # clk_and_rst = [
    #     node
    #     for node in graph
    #     if node.lower().find("clk") >= 0
    #     or node.lower().find("rst") >= 0
    # ]
    # graph.remove_nodes_from(clk_and_rst)

    nodes_index = df
    node_types_dict = nx.get_node_attributes(graph,'nodeType')
    # pd.DataFrame(index=graph.nodes())

    def is_node_type(s, type):
        if config is not None:
            try:
                t = node_types_dict[s]
            except KeyError:
                return False
            try:
                return t in config[type]
            except:
                raise ValueError(f"config does not contain cell list for {type}")
        elif node_types_dict:
            try:
                return node_types_dict[s].startswith(type)
            except KeyError:
                return s.startswith(type)
        else:
            return s.startswith(type)

    # fan_in_4: number of inputs after stepping 4 away from net
    # careful, this method does not work, if the graph has self-loops
    # generate graph with selfloops at PIs
    G = graph.copy()
    
    for node, deg in G.in_degree():
        if deg == 0:
            G.add_edge(node, node)
    adjm_r = nx.to_scipy_sparse_array(G.reverse(False))
    
    indegs = np.fromiter((deg for node,deg in graph.in_degree()), int, count=-1)
    fourth_pow = (adjm_r**4)
    nodes_index["fan_in_4"] = ((fourth_pow > 0) @ indegs)
    glogger.info("calculated fan_in_4")

    # fan_in_5: trivial
    nodes_index["fan_in_5"] = (((fourth_pow @ adjm_r) > 0) @ indegs)
    glogger.info("calculated fan_in_5")
    del adjm_r, indegs, fourth_pow

    

    # in_flipflop_4: perform bfs and count DFFs
    for node in graph.nodes():
        cells = nx.bfs_tree(graph, node, reverse=True, depth_limit=4).nodes()
        ffs = sum(is_node_type(c, "DFF") for i, c in enumerate(cells) if i != 0)
        nodes_index.loc[node, "in_flipflop_4"] = ffs
    del cells, ffs

    glogger.info("calculated in_flipflop_4")
    # out_flipflop_3: perform bfs and count DFFs
    # attention: skip first node in tree!!!
    for node in graph.nodes():
        cells = nx.bfs_tree(graph, node, depth_limit=3).nodes()
        ffs = sum(is_node_type(c, "DFF") for i, c in enumerate(cells) if i != 0)
        nodes_index.loc[node, "out_flipflop_3"] = ffs
        nextffs = sum(is_node_type(s, "DFF") for c in cells for s in graph.successors(c) if s not in cells)
        nodes_index.loc[node, "out_flipflop_4"] = ffs + nextffs
    del cells, ffs, nextffs

    glogger.info("calculated out_flipflop_3, out_flipflop_4")
    # in_loop_4: power matrix step by step and count diagonal 1s
    # careful, this method does not work, if the graph has self-loops
    adjm = nx.to_scipy_sparse_array(graph.reverse(False))
    cur = sp.sparse.identity(adjm.shape[0])
    num_loops = np.zeros((1, graph.number_of_nodes()))
    for i in range(2,5):
        cur = cur @ adjm
        diagonal = cur.diagonal()

        num_loops += diagonal
        zero_diagonal(cur, diagonal)
    nodes_index["in_loop_4"] = num_loops.T
    glogger.info("calculated in_loop_4")
    del adjm, cur, diagonal

    # out_loop_5: power matrix step by step and count diagonal 1s
    # careful, this method does not work, if the graph has self-loops
    adjm = nx.to_scipy_sparse_array(graph)
    cur = sp.sparse.identity(adjm.shape[0])
    num_loops = np.zeros((1, graph.number_of_nodes()))
    for i in range(2,6):
        cur = cur @ adjm
        diagonal = cur.diagonal()

        num_loops += diagonal
        zero_diagonal(cur, diagonal)
    nodes_index["out_loop_5"] = num_loops.T
    glogger.info("calculated out_loop_5")
    del adjm, cur, diagonal

    # in_nearest_pin: find shortest path 
    inputs = [
        node
        for node in graph
        if graph.in_degree(node) == 0
    ]
    nearest = shortest_path_from_source_list_to_all_nodes(graph, inputs)
    in_nearest_pin = np.array([nearest.get(node) for node in graph.nodes()])
    nodes_index["in_nearest_pin"] = in_nearest_pin
    glogger.info("calculated in_nearest_pin")
    del in_nearest_pin, nearest

    # out_nearest_pout: find shortest path 
    outputs = [
        node
        for node in graph
        if graph.out_degree(node) == 0
    ]
    nearest = shortest_path_from_source_list_to_all_nodes(graph.reverse(), outputs)
    out_nearest_pout = np.array([nearest.get(node) for node in graph.nodes()])
    nodes_index["out_nearest_pout"] = out_nearest_pout
    glogger.info("calculated out_nearest_pout")
    del nearest, out_nearest_pout

    # out_nearest_flipflop: find shortest path 
    ffs = [
        node
        for node in graph
        if is_node_type(node, "DFF")
    ]
    nearest = shortest_path_from_source_list_to_all_nodes(graph.reverse(), ffs)
    out_nearest_flipflop = np.array([nearest.get(node) for node in graph.nodes()])
    nodes_index["out_nearest_flipflop"] = out_nearest_flipflop
    glogger.info("calculated out_nearest_flipflop")
    del nearest, out_nearest_flipflop

    # out_nearest_multiplexer: find shortest path 
    muxes = [
        node
        for node in graph
        if is_node_type(node, "MUX")
    ]
    try:
        nearest = shortest_path_from_source_list_to_all_nodes(graph.reverse(), muxes)
        out_nearest_multiplexer = np.array([nearest.get(node) for node in graph.nodes()])
        nodes_index["out_nearest_multiplexer"] = out_nearest_multiplexer
    except ValueError:
        nodes_index["out_nearest_multiplexer"] = np.nan
    glogger.info("calculated out_nearest_multiplexer")
    del nearest, out_nearest_multiplexer

    return nodes_index

def check_node_type(cell, node_types_dict, type):
    if node_types_dict:
        try:
            return node_types_dict[cell].startswith(type)
        except KeyError:
            return cell.startswith(type)
    else:
        return cell.startswith(type)


def zero_diagonal(csrmatrix, diagonal):
    nonzero, = diagonal.nonzero()
    csrmatrix[nonzero, nonzero] = 0

def shortest_path_from_source_list_to_all_nodes(G, source_set):
    if len(source_set) < 1:
        raise ValueError("At least one source needed")
    adj = G.adj
    seen = {s: set() for s in source_set}                  # level (number of hops) when seen in BFS
    level = 0                  # the current level
    nextlevel = {s: {s: 1} for s in source_set}     # dict of nodes to check at next level
    allseen = {}

    while any(path for path in nextlevel.values()):
        thislevel = nextlevel  # advance to next level
        nextlevel = {}         # and start a new list (fringe)
        for s, path in thislevel.items():
            nextlevel[s] = {}
            for v in path:
                if v not in seen[s]:
                    seen[s].add(v)  # set the level of vertex v
                    nextlevel[s].update(adj[v])  # add neighbors of v
                    if v not in allseen:
                        allseen[v] = level
        level += 1
    del seen
    return allseen
