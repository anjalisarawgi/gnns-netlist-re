#!/usr/bin/env python3
"""Run feature generation.

.. code-block::
    :caption: Synopsys:

    usage: make_features [-h] [--cores CORES] [--gt_cores GT_CORES]
                         [--ap_cores AP_CORES] [-o OUTPUT_PATH] -t {csv,pq}
                         [-l CELL_LIBRARY] (--use_nx | --use_fastest)
                         [--smallest_first] [--eigs_tolerance EIGS_TOLERANCE]
                         [-f FILENAME] [--use_node_types] [--debug]
                         designs [designs ...]

    Run feature generation.

    positional arguments:
      designs               (Nested) folders where graph files are located. This
                            application can read (txt, gml, graphml, gexf, pq,
                            json). Note that the designs will be sorted by file
                            size, as it is more efficient to handle large files
                            first.

    optional arguments:
      -h, --help            show this help message and exit
      --cores CORES         Cores to use for processing
      --gt_cores GT_CORES   Cores to use for graphtool. Multiplies by --cores!
                            Default = 1
      --ap_cores AP_CORES   Cores to use for ARPACK. Multiplies by --cores!
                            Default = 1
      -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The filepath where output df will be stored. Filename
                            will be defined by input path. Remember to set your
                            wanted output format with `-t`.
      -t {csv,pq}, --output-type {csv,pq}
                            The output filetype. Two formats are supported:
                            Parquet (pq) is recommended, fast and compressed. CSV
                            (csv) is old, slow and uncompressed. All rows created
                            from one input filepath will be put into a single
                            output file.
      -l CELL_LIBRARY, --cell_library CELL_LIBRARY
                            The cell library name to use. Default: osu035
      --use_nx              Use networkx for graph calculations. slower, but less
                            bugs
      --use_fastest         Use a melange of graph libraries for graph
                            calculations. faster, but maybe some bugs
      --smallest_first      By default, the largest designs will be converted
                            first. With this flag, convert the smallest first.
                            More success, but large things may come late and badly
      --eigs_tolerance EIGS_TOLERANCE
                            By default, the eigenvector centrality uses machine
                            precision as tolerance for eigenvector caluclation.
                            This is precise, but takes time. Specify another
                            tolerance with this flag.
      -f FILENAME, --additional_features FILENAME
                            specify a Python file that contains a function
                            `compute_additional_features(graph, result,
                            design_file)` for the computation of additional
                            features. This option can be used multiple times.
      --use_node_types      Use node types if available in your input format. This
                            will trigger a ValueError and abort if your format
                            does not carry node type info.

    main:
      --debug               Enable debug output

    Please note that make_features accepts multiple paths and/or folders with its
    `designs` argument. Please do not start multiple instances of this executable,
    but start one instance and supply it with all the netlists you want to
    generate features for. This is most efficient.

    Recommended settings for gt_cores and ap_cores is more than 1! Please still
    make sure that you never exceed your alotted core limit with
    `gt_cores`*`cores` or `ap_cores`*`cores`!

.. note::

    an additional features file might look like this:

    .. code-block::
        :caption: count_keyinputs.py

        def compute_additional_features(graph, result, design_file):
            inputs = [x for x, y in dict(graph.in_degree()).items() if y == 0]
            key_inputs = [x for x in inputs if "keyinput" in x]
            normal_inputs = [x for x in inputs if x not in key_inputs]
            result["nr_key_inputs"] = len(key_inputs)
            result["nr_normal_inputs"] = len(normal_inputs)
            return result

"""

import re_verilog2features.globalArgParse

re_verilog2features.globalArgParse.init_global_parser(
    description="Run feature generation.",
    epilog="""
        Please note that make_features accepts multiple paths
        and/or folders with its `designs` argument.
        Please do not start multiple instances of this executable, but
        start one instance and supply it with all the netlists you want
        to generate features for. This is most efficient.
        |n
        Recommended settings for gt_cores and ap_cores is more than 1! Please
        still make sure that you never exceed your alotted core limit with
        `gt_cores`*`cores` or `ap_cores`*`cores`!
    """,
)

from re_verilog2features.read_graph_and_make_features_gatelevel import make_features  # noqa: E402
from tueisec_myparsing.cli.helpers import setup_cli  # noqa: E402


def main():
    group = re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument_group("main")
    group.add_argument("--debug", help="Enable debug output", action="store_true")

    args = re_verilog2features.globalArgParse.GLOBAL_PARSER.parse_args_main()
    if args.debug:
        setup_cli(
            log_level="debug",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    else:
        setup_cli(
            log_level="warning",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    make_features()
