#!/usr/bin/env python3
"""Run feature generation.

.. code-block::
    :caption: Synopsys:

    usage: make_hasegawa_features [-h] [--cores CORES] [--ap_cores AP_CORES]
      -o OUTPUT_PATH [-l CELL_LIBRARY] [--smallest_first] [--debug]

    Run feature generation.

    optional arguments:
      -h, --help            show this help message and exit
      --cores CORES         Cores to use for parallelization. Default = 1
      --ap_cores AP_CORES   Cores to use for ARPACK. Multiplies by --cores! Default = 1
      -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The filepath where output df will be stored. Filename will
                            be defined by input path. Remember to set your wanted output
                            format with `-t`.
      -l CELL_LIBRARY, --cell_library CELL_LIBRARY
                            The cell library name to use. Default: osu035
      --smallest_first      By default, the largest designs will be converted first.
                            With this flag, convert the smallest first. More success,
                            but large things may come late and badly.
      --debug               Enable debug output

    Please note that make_hasegawa_features accepts multiple paths and/or folders with
    its `designs` argument. Please do not start multiple instances of this executable,
    but start one instance and supply it with all the graphs you want to generate
    features for. This is most efficient.
"""

import os
import gc
import glob
import argparse
import logging
import importlib
from threading import Semaphore

from tueisec_myparsing.cli.helpers import setup_cli  # type: ignorei
import tueisec_myparsing.pool_wrapper as pool_wrapper  # type: ignore
from itertools import repeat


glogger = logging.getLogger(__name__)

RANDOM_STATE = 42


def load_cells(args):
    global GraphOutputFormat, pd, calculate_hasegawa_features

    designpath, outfilepath = args

    design = GraphOutputFormat.read_graph_from_filepath(designpath)

    clk_and_rst = [
        node
        for node in design
        if node.lower().find("clk") >= 0 or node.lower().find("rst") >= 0
    ]
    design.remove_nodes_from(clk_and_rst)

    design_df = pd.DataFrame(index=pd.Index(design.nodes(), name="cells"))
    design_df.attrs["outfilepath"] = outfilepath
    design_df.attrs["designpath"] = designpath
    design_df.attrs["nx_design"] = design

    return design_df


def calc_hasegawa_wrapper(args):
    design_df, config = args
    return calculate_hasegawa_features(
        design_df.attrs["nx_design"], design_df, design_df.attrs["designpath"], config
    )


def main():
    parser = argparse.ArgumentParser(
        description="Run feature generation.",
        epilog="""
        Please note that make_hasegawa_features accepts multiple paths
        and/or folders with its `designs` argument.
        Please do not start multiple instances of this executable, but
        start one instance and supply it with all the graphs you want
        to generate features for. This is most efficient.
        """,
    )
    parser.add_argument(
        "designs",
        nargs="+",
        help="(Nested) folders or filenames where graph files are located. "
        "This application can read (txt, gml, graphml, gexf, pq, json). "
        "Note that the designs will be sorted by file size, "
        "as it is more efficient to handle large files first.",
    )
    parser.add_argument(
        "--cores",
        help="Cores to use for parallelization. Default = 1",
        default=1,
        type=int,
    )
    parser.add_argument(
        "--ap_cores",
        help="Cores to use for ARPACK. Multiplies by --cores! Default = 1",
        default=1,
        type=int,
    )
    parser.add_argument(
        "-o",
        "--output_path",
        help="The filepath where output df will be stored. "
        "Filename will be defined by input path. "
        "Remember to set your wanted output format with `-t`.",
        required=True,
    )
    parser.add_argument(
        "--smallest_first",
        help="By default, the largest designs will be converted first. "
        "With this flag, convert the smallest first. More success, but large "
        "things may come late and badly",
        action="store_false",
    )
    parser.add_argument("--debug", help="Enable debug output", action="store_true")
    parser.add_argument(
        "--type-config", 
        help="Provide cell type helpers for the cell types DFF, MUX."
        "specify this flag multiple times and provide the type first "
        "then the cells that represent this type.",
        action="append",
        nargs="+"
    )

    args = parser.parse_args()

    if args.debug:
        setup_cli(
            log_level="debug",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    else:
        setup_cli(
            log_level="warning",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    # We have to set this env variable before
    # importing any thing like numpy, else the env variable has no effect on
    # arpack.
    os.environ["OPENBLAS_NUM_THREADS"] = str(args.ap_cores)
    os.environ["NUMEXPR_NUM_THREADS"] = "8"
    # now import programmatically. following is equivalent
    # import pandas as pd  # type: ignore
    # from re_verilog2features.hasegawa_et_al import (
    #   calculate_hasegawa_features
    # )
    # from tueisec_myparsing.graph_output_file_formats import GraphOutputFormat
    globals()["pd"] = importlib.import_module("pandas")
    hmod = importlib.import_module(
        "re_verilog2features.hasegawa_et_al"
    )
    globals()["calculate_hasegawa_features"] = hmod.calculate_hasegawa_features
    
    gmod = importlib.import_module(
        "tueisec_myparsing.graph_output_file_formats"
    )
    globals()["GraphOutputFormat"] = gmod.GraphOutputFormat

    os.makedirs(args.output_path, exist_ok=True)

    # create config from type-config arg
    config = {}
    for c in args.type_config:
        if c[0] not in ["DFF", "MUX"]:
            raise ValueError("type can only be DFF or MUX")
        if len(c) < 2:
            raise ValueError(f"provide cells for the type {c[0]}")
        config.setdefault(c[0], set()).update(c[1:])

    designs = glob_list_of_design_paths(args.designs)
    designs_with_outpaths = skip_existing_designs(designs, args.output_path)

    # sort the designs by size, so that the largest or smallest designs
    # are handled first.
    # This improves computation time. Thanks @thielepaul
    designs_sorted = sorted(
        designs_with_outpaths,
        key=lambda x: os.path.getsize(x[0]),
        reverse=args.smallest_first,
    )

    total = len(designs_sorted)

    semaphore = Semaphore(args.cores+1)

    design_dfs = pool_wrapper.run_in_pool_iter(
        load_cells,
        semaphored(designs_sorted, semaphore),
        processes=args.cores,
        no_signal_mod=False,
    )

    design_feature_dfs = pool_wrapper.run_in_pool_with_progress_iter(
        calc_hasegawa_wrapper,
        zip(design_dfs, repeat(config)),
        processes=args.cores,
        total=total,
        no_signal_mod=False,
    )

    for df in design_feature_dfs:
        outfilepath = df.attrs["outfilepath"]
        df.to_parquet(outfilepath, engine="pyarrow", compression="snappy")
        print(f"stored {outfilepath}")
        del(df)
        gc.collect()
        semaphore.release()

def semaphored(designs_sorted,semaphore):
    for d in designs_sorted:
        semaphore.acquire()
        yield d

def skip_existing_designs(designs_iter, output_path):
    # skip all designs where output exists
    for design_path in designs_iter:
        filename = os.path.basename(design_path)
        outfilepath = os.path.join(
            output_path,
            "{}.pq".format(filename),
        )
        if os.path.exists(outfilepath):
            glogger.error(
                "Found {}, will ignore this filepath. If you do not want "
                "that, delete the file.".format(outfilepath)
            )
        else:
            yield design_path, outfilepath


def glob_list_of_design_paths(design_path_list):
    known_extensions_globs = list(GraphOutputFormat.known_extensions_globs())

    if isinstance(design_path_list, str):
        design_path_list = [design_path_list]
    for design_path in design_path_list:
        glogger.warning("Now globbing {}. This may take a while".format(design_path))
        try:
            GraphOutputFormat.format_from_filename(design_path)
        except ValueError:
            # This means that the path is not a graph file itself
            for eg in known_extensions_globs:
                glob_path = os.path.join(design_path, "**", eg)
                glogger.info("Globbing graphs in {}.".format(design_path))
                yield from glob.glob(glob_path, recursive=True)
        else:
            glogger.info("Found 1 graph in {}.".format(design_path))
            yield design_path


if __name__ == "__main__":
    main()
