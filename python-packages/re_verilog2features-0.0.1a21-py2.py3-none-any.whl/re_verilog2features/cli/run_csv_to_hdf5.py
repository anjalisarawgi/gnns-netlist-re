#!/usr/bin/env python3
"""convert from csv to hdf5. DEPRECATED!

.. code-block::
    :caption: Synopsys:

    usage: run_csv_to_hdf5 [-h] [--debug] [-c CSV_ROOT_PATH] [-o OUTPUT_PATH]
                       [--overwrite] [-l CELL_LIBRARY]

    Convert csv-files to hdf5.

    optional arguments:
    -h, --help            show this help message and exit
    -c CSV_ROOT_PATH, --csv_root_path CSV_ROOT_PATH
                            The folder where csv files will be available in
                            subfolders. Default: outputFiles/{}/
    -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The folder where output files will be stored in a
                            subfolder depending on process. Default:
                            outputFiles/{}/hdf5_all_graph.hdf5
    --overwrite           Overwrite hdf5 files.
    -l CELL_LIBRARY, --cell_library CELL_LIBRARY
                            The cell library name to use. Default: osu035

    main:
    --debug               Enable debug output

"""

import re_verilog2features.globalArgParse
from re_verilog2features.globalArgParse import folder_exists_w
import logging
from re_verilog2features.cluster_csv_file import CSVFileContainer, CSVType
from tueisec_myparsing.cli.helpers import setup_cli
import os
import pandas as pd

re_verilog2features.globalArgParse.init_global_parser(
    description="Convert csv-files to hdf5."
)

csv_path_default = "outputFiles/{}/"
output_path_default = "outputFiles/{}/hdf5_all_graph.hdf5"

glogger = logging.getLogger(__name__)


def perform_conversion():
    """Main worker function. Too small to require a submodule.
    
    Reads all csvs, concats each csv in one category to one big pandas table and writes all pandas tables into one big hdf5 file.
    """
    GLOBAL_PARSER =  re_verilog2features.globalArgParse.GLOBAL_PARSER

    csv_path = GLOBAL_PARSER.csv_root_path.format(GLOBAL_PARSER.cell_library)
    if not GLOBAL_PARSER.no_design:
        design_csv_path = os.path.join(csv_path, "csvs_design_graph")
    partition_csv_path = os.path.join(csv_path, "csvs_partition_graph")
    clustered_csv_path = os.path.join(csv_path, "csvs_clustered_graph")
    small_csv_path = os.path.join(csv_path, "csvs_small_graph")

    if not GLOBAL_PARSER.no_design:
        csv_file_container = CSVFileContainer(
            design_graph=design_csv_path,
            partition_graph=partition_csv_path,
            cluster_graph=clustered_csv_path,
            small=small_csv_path,
        )
    else:
        csv_file_container = CSVFileContainer(
            partition_graph=partition_csv_path,
            cluster_graph=clustered_csv_path,
            small=small_csv_path,
        )

    with pd.HDFStore(
        path=GLOBAL_PARSER.output_path.format(GLOBAL_PARSER.cell_library), mode="w"
    ) as store:
        for t in CSVType.__members__:
            try:
                csvs = getattr(csv_file_container, "all_" + t + "_files")
            except AttributeError:
                data_frame = pd.DataFrame()
                data_frame.to_hdf(store, key=t, format="fixed")
                continue

            data_frame = pd.concat((f.frame for f in csvs), axis=1).T

            data_frame.to_hdf(store, key=t, format="fixed")


def main():
    group = re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument_group("main")
    group.add_argument("--debug", help="Enable debug output", action="store_true")

    re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument(
        "-c",
        "--csv_root_path",
        help="The folder where csv files will be available in subfolders. Default: "
        + csv_path_default,
        default=csv_path_default,
        type=folder_exists_w,
    )

    re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument(
        "-o",
        "--output_path",
        help="The folder where output files will be stored in a subfolder depending on process. Default: "
        + output_path_default,
        default=output_path_default,
    )

    re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument(
        "--overwrite", help="Overwrite hdf5 files.", action="store_true"
    )

    re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument(
        "--no_design", help="Do not read design_graph.", action="store_true"
    )

    re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument(
        "-l",
        "--cell_library",
        help="The cell library name to use. Default: osu035",
        default="osu035",
    )

    # must be imported here, becuase this influences the sorting of the required arguments

    GLOBAL_PARSER = re_verilog2features.globalArgParse.GLOBAL_PARSER.parse_args_main()
    if GLOBAL_PARSER.debug:
        setup_cli(
            log_level="debug",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    else:
        setup_cli(
            log_level="warning",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    perform_conversion()
