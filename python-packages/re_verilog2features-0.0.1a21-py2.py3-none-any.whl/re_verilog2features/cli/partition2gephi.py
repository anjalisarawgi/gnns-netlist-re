"""Run clustering.

.. code-block::
    :caption: Synopsys:

    usage: partition2gephi [-h] [--cores CORES] -o OUTPUT_PATH [-p PARTITION_GRAPH_PATH] [-c CLUSTERED_GRAPH_PATH] [-t {txt,gexf,gml,graphml,json,epq,pq,gpickle}]
                           [--smallest_first] [--do-not-zip] [--debug]
                           designs [designs ...]

    Create a single graph showing all partition results.

    positional arguments:
      designs               One or many graph files to generate the gephi view for. Please specify the original graph, as given to `run_clustering`. This application can
                            read (txt, gml, graphml, gexf, pq, json). Note that the designs will be sorted by file size, as it is more efficient to handle large files
                            first.

    optional arguments:
      -h, --help            show this help message and exit
      --cores CORES         Cores to use for processing
      -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The filepath where gephi graphs will be stored. Filename will be defined by input path. Remember to set your wanted output format with `-t`.
      -p PARTITION_GRAPH_PATH, --partition_graph_path PARTITION_GRAPH_PATH
                            The folder where partition_graph output files are found. The folder should contain one folder per design, containing partition folders.
      -c CLUSTERED_GRAPH_PATH, --clustered_graph_path CLUSTERED_GRAPH_PATH
                            The folder where clustered_graph output files are found. The folder should contain one folder per design, containing one folder per cluster
                            method, containing one folder per parameter set containing one folder per edentified cluster.
      -t {txt,gexf,gml,graphml,json,epq,pq,gpickle}, --output-format {txt,gexf,gml,graphml,json,epq,pq,gpickle}
                            Choose the output format as you like.
      --smallest_first      By default, the largest designs will be converted first. With this flag, convert the smallest first. Earlier results, but large designs may
                            be severely delayed and create errors late.
      --do-not-zip          No zipping of output file formats

    main:
      --debug               Enable debug output

    Please note that this tool accepts multiple paths with its `designs` argument. Please do not start multiple instances of this executable, but start one instance and
    supply it with all the netlists you want to generate for. This is most efficient.

    Recommended settings for --cores is more than 1! Please still make sure that you never exceed your alotted core limit!

"""

import re_verilog2features.globalArgParse

re_verilog2features.globalArgParse.init_global_parser(
    description="Create a single graph showing all partition results.",
    epilog="""
        Please note that this tool accepts multiple paths
        with its `designs` argument.
        Please do not start multiple instances of this executable, but
        start one instance and supply it with all the netlists you want
        to generate for. This is most efficient.
        |n
        Recommended settings for --cores is more than 1! Please
        still make sure that you never exceed your alotted core limit!
    """,
)

from tueisec_myparsing.pool_wrapper import run_in_pool_with_progress  # noqa: E402
from tueisec_myparsing.graph_output_file_formats import GraphOutputFormat  # noqa: E402
from tueisec_myparsing.cli.helpers import setup_cli  # noqa: E402
from pprint import pformat  # noqa: E402
import logging  # noqa: E402
import os  # noqa: E402
import glob  # noqa: E402
import toml  # noqa: E402
import networkx as nx  # noqa: E402
import pandas as pd  # noqa: E402
from re_verilog2features.globalArgParse import GLOBAL_PARSER  # noqa: E402

pg_path_default = "outputFiles/{}/partition_graph/"
cg_path_default = "outputFiles/{}/clustered_graph/"
try:  # sphinx barrier, because GLOBAL_PARSER will fail to import
    GLOBAL_PARSER.add_argument(
        "designs",
        nargs="+",
        help="One or many graph files to generate the gephi view for. "
        "Please specify the original graph, as given to `run_clustering`. "
        "This application can read (txt, gml, graphml, gexf, pq, json). "
        "Note that the designs will be sorted by file size, "
        "as it is more efficient to handle large files first.",
    )

    GLOBAL_PARSER.add_argument("--cores", help="Cores to use for processing", type=int)

    GLOBAL_PARSER.add_argument(
        "-o",
        "--output_path",
        help="The filepath where gephi graphs will be stored. "
        "Filename will be defined by input path. "
        "Remember to set your wanted output format with `-t`.",
        required=True,
    )

    GLOBAL_PARSER.add_argument(
        "-p",
        "--partition_graph_path",
        help=(
            "The folder where partition_graph output files are found. "
            "The folder should contain one folder per design, containing "
            "partition folders."
        ),
        default=pg_path_default,
    )

    GLOBAL_PARSER.add_argument(
        "-c",
        "--clustered_graph_path",
        help=(
            "The folder where clustered_graph output files are found. "
            "The folder should contain one folder per design, containing "
            "one folder per cluster method, containing one folder per "
            "parameter set containing one folder per edentified cluster."

        ),
        default=cg_path_default,
    )
                            
    GLOBAL_PARSER.add_argument(
        "-t",
        "--output-format",
        help="Choose the output format as you like.",
        default=GraphOutputFormat.adjlist,
        type=GraphOutputFormat,
        choices=list(GraphOutputFormat),
    )



    GLOBAL_PARSER.add_argument(
        "--smallest_first",
        help="By default, the largest designs will be converted first. "
        "With this flag, convert the smallest first. Earlier results, "
        "but large designs may be severely delayed and create errors late.",
        action="store_false",
    )

    GLOBAL_PARSER.add_argument(
        "--do-not-zip", help="No zipping of output file formats", action="store_true",
    )

except BaseException:
    logger.error("GLOBAL_PARSER unitialized. Are you really sure that you init'ed it?")

logger = logging.getLogger(__name__)


def main():
    group = re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument_group("main")
    group.add_argument("--debug", help="Enable debug output", action="store_true")

    args = re_verilog2features.globalArgParse.GLOBAL_PARSER.parse_args_main()
    if args.debug:
        setup_cli(
            log_level="debug",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    else:
        setup_cli(
            log_level="warning",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )

    designs = sorted(args.designs, key=lambda x: os.path.getsize(x), reverse=True)

    run_in_pool_with_progress(partition_to_gephi, designs, processes=args.cores)

def partition_to_gephi(designpath):
    G, architecture_name = read_original_graph(designpath)
    read_partition(G, architecture_name)
    read_clusters(G, architecture_name )
    write_graph(G, architecture_name)

def read_original_graph(d):

    architecture_name = os.path.splitext(os.path.basename(d))[0]
    logger.info(f"Processing {architecture_name}")

    return GraphOutputFormat.read_graph_from_filepath(d), architecture_name

def read_partition(G, architecture_name):
    # read ground_truth partitions
    partition_dict = {}
    partition_node_list = []

    # find all pq files for patition
    for f in glob.glob(
        os.path.join(GLOBAL_PARSER.partition_graph_path, architecture_name, "*.pq")
    ):
        # read in the pq files
        nodes_list = list(
            nx.from_pandas_edgelist(
                pd.read_parquet(f, engine="pyarrow"), create_using=nx.DiGraph()
            )
        )

        partition_node_list.extend(nodes_list)
        hierarchy_address = os.path.basename(f).split("partitionReal_")[1].split("_moduleName_")[0]
        hierarchy_levels = len(hierarchy_address.split("+"))
        matched_module = os.path.basename(f).split("_moduleName_")[1].split(".pq")[0]
        for node in nodes_list:
            partition_dict[node] = (hierarchy_address, hierarchy_levels) if hierarchy_levels > partition_dict.get(node, ("",-1))[1] else partition_dict[node]

    if logger.isEnabledFor(logging.DEBUG):
        logger.info("following partitioning was found")
        logger.info(pformat(set(partition_dict.values())))
    partition_dict = { node: partition for node, (partition, level) in partition_dict.items() }
    nx.set_node_attributes(G, partition_dict, "partition")

def read_clusters(G, architecture_name):

        for cluster_method_path in glob.glob(
            os.path.join(GLOBAL_PARSER.clustered_graph_path, architecture_name, "*")
        ):
            clustering_method = os.path.split(cluster_method_path)[1].split("_")[1]
            for cluster_method_paramset_path in glob.glob(
                os.path.join(cluster_method_path, "*")
            ):
                cluster_dict = {}
                cluster_node_list = []
                toml_dict = toml.load(os.path.join(cluster_method_paramset_path ,"param-values.toml"))
                parameter = str(
                    toml_dict[list(toml_dict.keys())[0]][
                        list(toml_dict[list(toml_dict.keys())[0]].keys())[0]
                    ]
                )
                for cluster_method_paramset_clusterid_path in glob.glob(
                    os.path.join(cluster_method_paramset_path, "cluster_*")
                ):
                    graph_path = os.path.join(cluster_method_paramset_clusterid_path, "adj.pq")

                    nodes_list = list(
                        GraphOutputFormat.read_graph_from_filepath(graph_path)
                        # nx.from_pandas_edgelist(
                        #     pd.read_parquet(graph_path, engine="pyarrow"), create_using=nx.DiGraph()
                        # )
                    )
                    cluster_node_list.extend(nodes_list)
                    clustering_id = graph_path.split("/")[-2].split("_")[1]
                    clustering_match = graph_path.split("/")[-2].split("_moduleNames_")[-1]

                    cluster_identifier = f"{clustering_id}_{clustering_match}"
                    
                    # Allgemeine Zuweisug einfügen, wenn die Anzahl der Cluster
                    # nicht übereinstimmt (alle kleineren zusammenfassen)

                    for node in nodes_list:
                        if node not in cluster_dict.keys():
                            cluster_dict[node] = cluster_identifier
                        else:
                            # node exists in another cluster already (overlapping clusters)
                            # warn and do nothing, i.e. first cluster wins
                            logger.warn(
                                f"method {clustering_method} with `{parameter}` "
                                "produces overlapping clusters. `{node}` is "
                                "both in `{cluster_dict[node]}` and in "
                                "`{cluster_identifier}`"
                            )

                    # each node in the graph is now assigned the cluster according to the cluster dict
                nx.set_node_attributes(G, cluster_dict, f"{clustering_method}_{parameter}".replace("-","__").replace(".","___"))

def write_graph(G, architecture_name):
    GLOBAL_PARSER.output_format.write_graph(
        G,
        GLOBAL_PARSER.output_path,
        f"{architecture_name}_gephi",
        GLOBAL_PARSER.do_not_zip
    )

