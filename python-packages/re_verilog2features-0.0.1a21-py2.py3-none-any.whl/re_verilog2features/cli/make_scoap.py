#!/usr/bin/env python3
"""Calculate scoap data unsing tmax or python.

.. code-block::
    :caption: Synopsys:

    usage: make_scoap [-h] [-o OUTPUT_PATH] -t {csv,pq} [--use_tmax] [--debug]
                  design

    Calculate SCOAP data.
    
    positional arguments:
      design                Imput graph file. This application can read (txt, gml,
                            graphml, gexf, pq, json). If you use `--use_tmax`,
                            instead give a *.v file!

    optional arguments:
      -h, --help            show this help message and exit
      -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The filename where output df will be stored. Remember
                            to set your wanted output format with `-t`.
      -t {csv,pq}, --output-type {csv,pq}
                            The output filetype. Two formats are supported:
                            Parquet (pq) is recommended, fast and compressed. CSV
                            (csv) is old, slow and uncompressed.
      --use_tmax            Use tetramax for calculation. Make sure that you have
                            tmax in your path (module load ...). The `design` ust
                            be a *.v file!

    main:
      --debug               Enable debug output

"""

import re_verilog2features.globalArgParse

re_verilog2features.globalArgParse.init_global_parser(
    description="Calculate SCOAP data.",
)

from re_verilog2features.read_graph_and_make_scoap import make_scoap  # noqa: E402
from tueisec_myparsing.cli.helpers import setup_cli  # noqa: E402


def main():
    """Main method of this cli interface.

    calls :py:func:`re_verilog2features.read_graph_and_make_scoap.make_scoap`.
    """
    group = re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument_group("main")
    group.add_argument("--debug", help="Enable debug output", action="store_true")

    args = re_verilog2features.globalArgParse.GLOBAL_PARSER.parse_args_main()
    if args.debug:
        setup_cli(
            log_level="debug",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    else:
        setup_cli(
            log_level="warning",
            additional_loggers=["re_verilog2features", "tueisec_myparsing"],
        )
    make_scoap()
