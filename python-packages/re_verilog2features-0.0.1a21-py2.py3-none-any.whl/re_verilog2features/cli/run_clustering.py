#!/usr/bin/env python3
"""Run clustering.

.. code-block::
    :caption: Synopsys:

    usage: run_clustering [-h] [--cores CORES] [--gt_cores GT_CORES]
                          [-i HIERARCHY_PATH] [-p PARTITION_GRAPH_PATH]
                          [-c CLUSTERED_GRAPH_PATH]
                          [--overwrite {all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} [{all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} ...]]
                          [--task {all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} [{all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} ...]]
                          [--min_comms MIN_COMMS] [--max_comms MAX_COMMS]
                          [--max_tries MAX_TRIES] [-T THRESHOLD] [-u USED_LIB]
                          [--config CONFIG]
                          [--logger {info,debug,warning,error,critical}]
                          designs [designs ...]
    
    Run clustering depending on process.
    
    positional arguments:
      designs               folder where adjacency lists are located (*.txt)
    
    optional arguments:
      -h, --help            show this help message and exit
      --cores CORES         Cores to use for processing
      --gt_cores GT_CORES   Cores to use for graphtool/other clustering.
                            Multiplies by --cores!
      -i HIERARCHY_PATH, --hierarchy_path HIERARCHY_PATH
                            The folder where hierarchy files are stored
      -p PARTITION_GRAPH_PATH, --partition_graph_path PARTITION_GRAPH_PATH
                            The folder where partition_graph output files will be
                            stored in a subfolder depending on process
      -c CLUSTERED_GRAPH_PATH, --clustered_graph_path CLUSTERED_GRAPH_PATH
                            The folder where clustered_graph output files will be
                            stored in a subfolder depending on process
      --overwrite {all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} [{all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} ...]
                            What to overwrite
      --task {all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} [{all,cluster,partition,mcl,louvain,louvain_dend,leiden-mod,leiden-cpm,walkscan,walkscan-py,io-bwn,io-bwn-rust,nsbm} ...]
                            Task to perform
      --min_comms MIN_COMMS
                            Minumim number of communities wanted for io-bwn
      --max_comms MAX_COMMS
                            Maximum number of communities wanted for io-bwn
      --max_tries MAX_TRIES
                            Maximum number of tries removing a edge while doing
                            girvan_newman
      -T THRESHOLD, --threshold THRESHOLD
                            Cluster quality threshold. clusters worse than this
                            threshold are dropped.
      -u USED_LIB, --used_lib USED_LIB
                            The library used for the designs. Specify this to
                            override autodetection, which may fuction only in a
                            few cases. The default is to recognize this from the
                            design file paths (base folder name).
      --config CONFIG       config file to override params for the clustering
                            algos.
    
    main:
      --logger {info,debug,warning,error,critical}
                            logger level. Default: info
"""

import re_verilog2features.globalArgParse

re_verilog2features.globalArgParse.init_global_parser(
    description="Run clustering depending on process."
)

from re_verilog2features.clustering.clustering_workflow import perform_clustering  # noqa: E402
from tueisec_myparsing.cli.helpers import setup_cli  # noqa: E402


def main():
    group = re_verilog2features.globalArgParse.GLOBAL_PARSER.add_argument_group("main")
    group.add_argument(
        "--logger",
        help="logger level. Default: info",
        choices=["info", "debug", "warning", "error", "critical"],
        default="info",
    )

    args = re_verilog2features.globalArgParse.GLOBAL_PARSER.parse_args_main()
    setup_cli(
        log_level=args.logger,
        additional_loggers=["re_verilog2features", "tueisec_myparsing"],
    )
    perform_clustering()
