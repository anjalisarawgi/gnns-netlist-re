"""
Feature extraction functions, to be used with read_adjlist_and_make_csv.py

CAREFUL: If you do not want OPENBLAS / ARPACK to use all cores of the host system, use
this line BEFORE importing this or any of nx, np, scipy, pandas etc.! ::

    os.environ["OPENBLAS_NUM_THREADS"] = str(<number_of_cores>)

Also be careful because this parameter is threads per python process, so if you
use multiprocessing, consider that #total_treads = #multiprocessing_pools *
OPENBLAS_NUM_THREADS

"""
# imports


import logging
import statistics
import sys
from collections import Counter
from statistics import StatisticsError

import igraph as ig
import networkx as nx
import numpy as np
import pandas as pd
import pyintergraph
import scipy as sp
import scipy.stats
import re

from re_verilog2features.globalArgParse import GLOBAL_PARSER
from re_verilog2features.graph_algo_func import (
    betweenness_centrality_pivot,
    nx2gt,
    nx2igraph,
    sparse_katz_centrality_numpy,
)

sys.setrecursionlimit(100000)

glogger = logging.getLogger(__name__)

def read_maliciousness_true(allcells, filepath):
    allcells["maliciousness_true"] = 0
    #allcells["maliciousness_pred"] = 0
    
    #hierarchy datei einlesen 
    filepath_hierarchy=filepath.rsplit('/',2)
    filepath_hierarchy[2]="hierarchy_"+filepath_hierarchy[2].replace("gml.gz","csv")
    filepath_hierarchy = filepath_hierarchy[0]+'/hierarchy/'+filepath_hierarchy[2]
    try:
        df_trojan = pd.read_csv(filepath_hierarchy,usecols=["top+trojan"])
    except ValueError:
        try:
            df_trojan = pd.read_csv(filepath_hierarchy,usecols=["top+Trojan"])
            df_trojan = df_trojan.rename(columns={"top+Trojan": "top+trojan"})
        except ValueError:
            glogger.info("No trojan colomn found in hierarchy.")
            return allcells
    except:
        glogger.info("Error while finding trojan colomn found in hierarchy.")
     
    df_trojan = df_trojan.dropna()
    df_trojan = df_trojan.reindex()
    if len(df_trojan):
        for trojan_cell in df_trojan["top+trojan"]:
            allcells.at[allcells.index==trojan_cell,"maliciousness_true"] = 1        

    try:
        df_trigger = pd.read_csv(filepath_hierarchy,usecols=["top+trigger"])
    except ValueError:
        try:
            df_trigger = pd.read_csv(filepath_hierarchy,usecols=["top+Trigger"])
            df_trigger = df_trigger.rename(columns={"top+Trigger": "top+trigger"})
        except ValueError:
            glogger.info("No trigger colomn found in hierarchy.")
            return allcells
    except:
        glogger.info("Error while finding trigger colomn found in hierarchy.")
 
    df_trigger = df_trigger.dropna()
    df_trigger = df_trigger.reindex()
    if len(df_trigger):
        for trigger_cell in df_trigger["top+trigger"]:
            allcells.at[allcells.index==trigger_cell,"maliciousness_true"] = 1
    return allcells

def node_type_ratios(graph, allcells, node_types, design_file):

    # initialise
    glogger.info("Doing node type rations for " + design_file)

    # count all cells into AND OR ETC first

    cell_types = [
        "AND",
        "OR",
        "NOR",
        "NAND",
        "XOR",
        "XNOR",
        "MUX",
        "INV",
        "DFF",
        "AOI",
        "OAI",
        "BUF",
    ]

    allcells["node_types"] = '' 
    allcells["Nr of node_type"] = 0
    allcells["Node_type Ratio"] = 0

    node_type_list = []
    for node in node_types.values():
        cell_found=0
        for cell in cell_types:
            if node.startswith(cell):
                node_type_list.append(cell)
                cell_found=1
                break
        if cell_found==0:
            node_type_list.append(node)

    allcells["node_types"] = node_type_list

    total_nodes = len(node_type_list)
    node_type_counter = Counter(node_type_list)
    for node_type, number in node_type_counter.items():
        allcells.at[allcells.node_types==node_type,"Nr of node_type"] = number
        allcells.at[allcells.node_types==node_type,"Node_type Ratio"] = number / total_nodes

    return allcells

def entropy(data):
    data = pd.Series(data)
    p_data = data.value_counts() / len(data)  # calculates the probabilities
    entropy = sp.stats.entropy(p_data)  # input probabilities to get the entropy
    return entropy

def graph_tests_nx(graph, allcells, design_file):
    """run the graph_tests algorithms solely with networkx

    :param graph: graph to analyze
    :type graph: networkx.Graph
    :param result: result dictionary where the calculation results should be added
    :type result: dict
    :param design_file: name of the design file for debuggin purposes
    :type design_file: str
    :return: returns the result dict again
    :rtype: dict
    """
    glogger.info("running graph tests with nx")

    # number of nodes for further calculations
    nnodes = graph.number_of_nodes()
    nedges = graph.number_of_edges()
    undirected = graph.to_undirected()

    # Functions of graph
    glogger.info("graph function tests for " + design_file)
    #allcells["number_of_nodes"] = nnodes
    #allcells["number_of_edges"] = nedges
    #allcells["density"] = nx.density(graph)
    allcells["degree"] =  list(dict(nx.degree(graph)).values())
    allcells["in_degree"] = list(dict(graph.in_degree()).values())
    
    try:
        allcells["eigenvector_centrality"] = list(
            dict(
                nx.eigenvector_centrality_numpy(
                    undirected, max_iter=None, tol=GLOBAL_PARSER.eigs_tolerance
                )
            ).values()
        )
    except BaseException as e:
        glogger.exception(
            "Could not calculate eigenvector centrality in "
            "%s with %s nodes and %s edges due to: ",
            design_file,
            nnodes,
            nedges,
            exc_info=e,
        )
        allcells["eigenvector_centrality"] = 0

    # pivots generation. THIS HEAVILY BIASES THE betweenness CALUCALTION!

    # We calculate the pivots as all graph inputs, where graph is the DIRECTED
    # version of the netlist. The betweenness calculation then only considers
    # shortest paths starting at the input nodes of the graph, to every node in
    # the graph. This causes a significant speedup, but heavily biases the
    # calculation as not nearly all shortest paths are considered. In the realm
    # of netlists, actually this should not be problematic, as data can not flow
    # between arbitrary nodes, but rather only from inputs to the nodes.
    pivots = [x for x, y in graph.in_degree() if y == 0]

    allcells["betweenness_centrality"] = list(dict(betweenness_centrality_pivot(undirected, pivots)).values())

    glogger.info("############graph algorithm tests for " + design_file)
    """ try:
        allcells[
            "degree_assortativity_coefficient"
        ] = nx.degree_assortativity_coefficient(
            graph
        )  # Assortativity measures the similarity of connections in the graph with
        # respect to the node degree.
    except ValueError as e:
        glogger.exception(
            "Could not calculate degree_assortativity_coefficient in %s due to: ",
            design_file,
            exc_info=e,
        )
        allcells["degree_assortativity_coefficient"] = 0.0 """

    allcells["degree_centrality"] = list(nx.degree_centrality(graph).values())
    allcells["degree_in_centrality"] = list(nx.in_degree_centrality(graph).values())
    allcells["degree_out_centrality"] = list(nx.out_degree_centrality(graph).values())
    allcells["closeness_centrality"] = list(nx.closeness_centrality(graph).values())
    allcells["pagerank"] = list(nx.pagerank(graph).values())
    allcells["in_edge_katz_centrality"] = list(nx.katz_centrality_numpy(graph).values())

    reverse = graph.copy()
    reverse.reverse()

    allcells["out_edge_katz_centrality"] = list(nx.katz_centrality_numpy(reverse).values())

    # allcells["condenstation-factor"] = (
    #     len(nx.condensation(graph).nodes()) / nnodes
    # )  # condensation removes all strongly connected components, replacing them with a single node
    # allcells["len_dominating_set"] = len(
    #     nx.dominating_set(graph)
    # )  # fixme: different values sometimes?
    # try:
    #     allcells["flow_hierarchy"] = nx.flow_hierarchy(graph)
    # except ValueError as e:
    #     glogger.exception(
    #         "Could not calculate flow_hierarchy in %s due to: ", design_file, exc_info=e
    #     )
    #     allcells["flow_hierarchy"] = 0.0

    return allcells

def graph_tests(graph, allcells, design_file):
    """run the graph_tests algorithms partially using igraph, graph_tool and networkx

    This is a hand-tested function using the fastest implementation
    of graph algorithms from the three libraries. Use this by default.

    .. note::

        This imports graph_tool, which is not in the requirements of the
        re_verilog2features package and must be installed manually.

        If you can not install it, use the slower :py:func:`graph_tests_nx`, for
        example with `--use_nx`

    :param graph: graph to analyze
    :type graph: networkx.Graph
    :param result: result dictionary where the calculation results should be added
    :type result: dict
    :param design_file: name of the design file for debuggin purposes
    :type design_file: str
    :return: returns the result dict again
    :rtype: dict
    """

    # Import graph tool just here, only if the user actually wants the
    # graph_tool based flow
    try:
        import graph_tool.centrality
        import graph_tool.topology
        import graph_tool.util

        graph_tool.openmp_set_num_threads(GLOBAL_PARSER.gt_cores)
        graph_tool.openmp_set_schedule("guided", chunk=1)
    except BaseException as e:
        raise ImportError(
            "Late import of graph-tool failed. You probably do not have it "
            "installed. Please use the networkx-only calculation "
            "`graph_tests_nx`, eg. with `--use_nx`."
        ) from e

    glogger.info("running graph tests (fastest)")

    # number of nodes for further calculations
    nnodes = graph.number_of_nodes()
    nedges = graph.number_of_edges()
    undirected = graph.to_undirected()

    ig_graph = nx2igraph(graph)
    # ig_graph_u = pyintergraph.nx2igraph(undirected)

    # Functions of graph
    glogger.info("graph function tests for " + design_file)
    #allcells["number_of_nodes"] = nnodes
    #allcells["number_of_edges"] = nedges
    allcells["density"] = ig_graph.density(loops=True)
    allcells["degree"] = ig_graph.degree(ig_graph.vs)
    allcells["in_degree"] = ig_graph.degree(ig_graph.vs, mode=ig.IN)
    try:
        eig_centr = dict(
            nx.eigenvector_centrality_numpy(
                undirected, max_iter=None, tol=GLOBAL_PARSER.eigs_tolerance
            )
        ).values()
    except BaseException as e:
        glogger.exception(
            "Could not calculate eigenvector centrality in %s with %d "
            "nodes and %d edges due to: ",
            design_file,
            nnodes,
            nedges,
            exc_info=e,
        )
        allcells["eigenvector_centrality"] = 0
    else:
        try:
            allcells["eigenvector_centrality"] = list(eig_centr)
        except BaseException as e:
            glogger.exception(
                "Could not calculate eigenvector centrality statistics "
                "in %s with %d nodes and %d edges due to: ",
                design_file,
                nnodes,
                nedges,
                exc_info=e,
            )
            allcells["eigenvector_centrality"] = 0

    # pivots generation. THIS HEAVILY BIASES THE betweenness CALUCALTION!

    # We calculate the pivots as all graph inputs, where graph is the DIRECTED
    # version of the netlist. The betweenness calculation then only considers
    # shortest paths starting at the input nodes of the graph, to every node in
    # the graph. This causes a significant speedup, but heavily biases the
    # calculation as not nearly all shortest paths are considered. In the realm
    # of netlists, actually this should not be problematic, as data can not flow
    # between arbitrary nodes, but rather only from inputs to the nodes.
    gt_graph_d = nx2gt(graph, labelname="node_name")
    gt_graph = nx2gt(undirected, labelname="node_name")
    pivots_number = graph_tool.util.find_vertex(gt_graph_d, "in", 0)
    pivots_names = [gt_graph_d.vp.node_name[x] for x in pivots_number]
    pivots = np.array(
        [
            graph_tool.util.find_vertex(gt_graph, gt_graph.vp.node_name, name)
            for name in pivots_names
        ]
    ).ravel()

    vp, _ = graph_tool.centrality.betweenness(gt_graph, pivots=pivots)
    allcells["betweenness_centrality"] = vp.a
    
    del gt_graph
    del gt_graph_d

    # THIS WOULD USE nx and is a bit slower. commented out.
    # # pivots generation. THIS HEAVILY BIASES THE betweenness CALUCALTION!

    # # We calculate the pivots as all graph inputs, where graph is the DIRECTED
    # # version of the netlist. The betweenness calculation then only considers
    # # shortest paths starting at the input nodes of the graph, to every node in
    # # the graph. This causes a significant speedup, but heavily biases the
    # # calculation as not nearly all shortest paths are considered. In the realm
    # # of netlists, actually this should not be problematic, as data can not flow
    # # between arbitrary nodes, but rather only from inputs to the nodes.
    # pivots = [x for x, y in graph.in_degree() if y == 0]

    # result = statistics_of_list(
    #     "betweenness_centrality",
    #     list(dict(betweenness_centrality_pivot(undirected, pivots)).values()),
    #     nnodes,
    #     result,
    #     design_file,
    # )

    glogger.info("############graph algorithm tests for " + design_file)
    try:
            allcells["degree_assortativity_coefficient"] = ig_graph.assortativity_degree()
        # Assortativity measures the similarity of connections in the graph with
        # respect to the node degree.
    except ValueError as e:
        glogger.exception(
            "Could not calculate degree_assortativity_coefficient in {} due to: ",
            design_file,
            exc_info=e,
        )
        allcells["degree_assortativity_coefficient"] = 0.0

    if len(graph) <= 1:
        deg_centr = [1] * ig_graph.vcount()

    s = 1.0 / (ig_graph.vcount() - 1.0)
    deg_centr = [d * s for d in ig_graph.degree()]

    allcells["degree_centrality"]= deg_centr

    if len(graph) <= 1:
        in_deg_centr = [1] * ig_graph.vcount()

    s = 1.0 / (ig_graph.vcount() - 1.0)
    in_deg_centr = [d * s for d in ig_graph.degree(mode=ig.IN)]

    allcells["degree_in_centrality"]= in_deg_centr

    if len(graph) <= 1:
        out_deg_centr = [1] * ig_graph.vcount()

    s = 1.0 / (ig_graph.vcount() - 1.0)
    out_deg_centr = [d * s for d in ig_graph.degree(mode=ig.IN)]

    allcells["degree_out_centrality"]= out_deg_centr

    closeness = ig_graph.closeness(mode=ig.IN)

    allcells["closeness_centrality"] = list(closeness)

    pagerank = ig_graph.personalized_pagerank()

    allcells["pagerank"] = list(pagerank)

    # TODO: katz in igraph
    allcells["in_edge_katz_centrality"] = list(sparse_katz_centrality_numpy(graph).values())

    reverse = graph.copy()
    reverse.reverse()

    allcells["out_edge_katz_centrality"] = list(sparse_katz_centrality_numpy(reverse).values())

    allcells["condenstation-factor"] = (
        len(ig_graph.components(ig.STRONG)) / nnodes
    )  # condensation removes all strongly connected components, replacing them with a single node

    # TODO igraph

    allcells["len_dominating_set"] = len(
        nx.dominating_set(graph)
    )  # fixme: different values sometimes?
    try:
        allcells["flow_hierarchy"] = 1.0 - sum(
            g.ecount() for g in ig_graph.components(ig.STRONG).subgraphs()
        ) / float(ig_graph.ecount())
    except ValueError as e:
        glogger.exception(
            "Could not calculate flow_hierarchy in {} due to: ", design_file, exc_info=e
        )
        allcells["flow_hierarchy"] = 0.0

    return allcells

def graph_tests_ig(graph, allcells, design_file):
    """run the graph_tests algorithms partially using igraph, graph_tool and networkx

    This is a hand-tested function using the fastest implementation
    of graph algorithms from the three libraries. Use this by default.

    .. note::

        This imports graph_tool, which is not in the requirements of the
        re_verilog2features package and must be installed manually.

        If you can not install it, use the slower :py:func:`graph_tests_nx`, for
        example with `--use_nx`

    :param graph: graph to analyze
    :type graph: networkx.Graph
    :param result: result dictionary where the calculation results should be added
    :type result: dict
    :param design_file: name of the design file for debuggin purposes
    :type design_file: str
    :return: returns the result dict again
    :rtype: dict
    """

    glogger.info("running graph tests (fastest-igraph)")

    # number of nodes for further calculations
    nnodes = graph.number_of_nodes()
    nedges = graph.number_of_edges()
    undirected = graph.to_undirected()

    ig_graph = nx2igraph(graph)
    # ig_graph_u = pyintergraph.nx2igraph(undirected)

    # Functions of graph
    glogger.info("graph function tests for " + design_file)
    allcells["density"] = ig_graph.density(loops=True)
    allcells["degree"] = ig_graph.degree(ig_graph.vs)
    allcells["in_degree"] = ig_graph.degree(ig_graph.vs, mode=ig.IN)
    try:
        eig_centr = dict(
            nx.eigenvector_centrality_numpy(
                undirected, max_iter=None, tol=GLOBAL_PARSER.eigs_tolerance
            )
        ).values()
    except BaseException as e:
        glogger.exception(
            "Could not calculate eigenvector centrality in %s with %d "
            "nodes and %d edges due to: ",
            design_file,
            nnodes,
            nedges,
            exc_info=e,
        )
        allcells["eigenvector_centrality"] = 0
    else:
        try:
            allcells["eigenvector_centrality"] = list(eig_centr)
        except BaseException as e:
            glogger.exception(
                "Could not calculate eigenvector centrality statistics "
                "in %s with %d nodes and %d edges due to: ",
                design_file,
                nnodes,
                nedges,
                exc_info=e,
            )
            allcells["eigenvector_centrality"] = 0

    # pivots generation. THIS HEAVILY BIASES THE betweenness CALUCALTION!

    # We calculate the pivots as all graph inputs, where graph is the DIRECTED
    # version of the netlist. The betweenness calculation then only considers
    # shortest paths starting at the input nodes of the graph, to every node in
    # the graph. This causes a significant speedup, but heavily biases the
    # calculation as not nearly all shortest paths are considered. In the realm
    # of netlists, actually this should not be problematic, as data can not flow
    # between arbitrary nodes, but rather only from inputs to the nodes.
    pivots = [x for x, y in graph.in_degree() if y == 0]

    allcells["betweenness_centrality"] = list(dict(betweenness_centrality_pivot(undirected, pivots)).values())

    glogger.info("############graph algorithm tests for " + design_file)
    try:
            allcells["degree_assortativity_coefficient"] = ig_graph.assortativity_degree()
        # Assortativity measures the similarity of connections in the graph with
        # respect to the node degree.
    except ValueError as e:
        glogger.exception(
            "Could not calculate degree_assortativity_coefficient in {} due to: ",
            design_file,
            exc_info=e,
        )
        allcells["degree_assortativity_coefficient"] = 0.0

    if len(graph) <= 1:
        deg_centr = [1] * ig_graph.vcount()

    s = 1.0 / (ig_graph.vcount() - 1.0)
    deg_centr = [d * s for d in ig_graph.degree()]

    allcells["degree_centrality"]= deg_centr

    if len(graph) <= 1:
        in_deg_centr = [1] * ig_graph.vcount()

    s = 1.0 / (ig_graph.vcount() - 1.0)
    in_deg_centr = [d * s for d in ig_graph.degree(mode=ig.IN)]

    allcells["degree_in_centrality"]= in_deg_centr

    if len(graph) <= 1:
        out_deg_centr = [1] * ig_graph.vcount()

    s = 1.0 / (ig_graph.vcount() - 1.0)
    out_deg_centr = [d * s for d in ig_graph.degree(mode=ig.IN)]

    allcells["degree_out_centrality"]= out_deg_centr

    closeness = ig_graph.closeness(mode=ig.IN)

    allcells["closeness_centrality"] = list(closeness)

    pagerank = ig_graph.personalized_pagerank()

    allcells["pagerank"] = list(pagerank)

    # TODO: katz in igraph
    allcells["in_edge_katz_centrality"] = list(sparse_katz_centrality_numpy(graph).values())

    reverse = graph.copy()
    reverse.reverse()

    allcells["out_edge_katz_centrality"] = list(sparse_katz_centrality_numpy(reverse).values())

    allcells["condenstation-factor"] = (
        len(ig_graph.components(ig.STRONG)) / nnodes
    )  # condensation removes all strongly connected components, replacing them with a single node

    # TODO igraph

    allcells["len_dominating_set"] = len(
        nx.dominating_set(graph)
    )  # fixme: different values sometimes?
    try:
        allcells["flow_hierarchy"] = 1.0 - sum(
            g.ecount() for g in ig_graph.components(ig.STRONG).subgraphs()
        ) / float(ig_graph.ecount())
    except ValueError as e:
        glogger.exception(
            "Could not calculate flow_hierarchy in {} due to: ", design_file, exc_info=e
        )
        allcells["flow_hierarchy"] = 0.0

    return allcells


IS_SPLIT_RE = re.compile(r"^.+\[\d+\]$")
NORMAL_PORT_RE = re.compile(
    r"(:?INPUT|OUTPUT)_(?P<portname>(:?(:?[a-zA-Z_])(:?[a-zA-Z_0-9$])*))\[(?P<portindex>\d+)\]$"
)
SPLIT_PORT_RE = re.compile(
    r"(:?INPUT|OUTPUT)_(?P<portname>(:?(:?\\\S)(:?\S)*))\[(?P<portindex>\d+)\]$"
)

""" 
def input_output_analysis(graph, allcells, design_file):
    #get number and type of inputs and outputs
    

    glogger.info("testing input and output number and type for " + design_file)
    # find inputs and outputs to graph
    outputs = {x for x, y in dict(graph.out_degree()).items() if y == 0}
    inputs = {x for x, y in dict(graph.in_degree()).items() if y == 0}

    # find inputs and outputs which were not split
    grouped_inputs = {x for x in inputs if IS_SPLIT_RE.match(x)}
    grouped_outputs = {x for x in outputs if IS_SPLIT_RE.match(x)}

    single_inputs = inputs - grouped_inputs
    single_outputs = outputs - grouped_outputs

    input_groups = {}
    output_groups = {}

    for inp in grouped_inputs:
        match = NORMAL_PORT_RE.match(inp)
        if match is None:
            match = SPLIT_PORT_RE.match(inp)
            if match is None:
                glogger.critical(
                    "Input analysis not performable. There is a split port I can not identify: {}".format(
                        inp
                    )
                )
                return allcells
        input_name = match.group('portname')
        input_index = match.group('portindex')

        # ~ highest_index = 0
        if input_name not in input_groups:
            input_groups[input_name] = input_index
        else:
            if input_groups[input_name] < input_index:
                input_groups[input_name] = input_index

    for outp in grouped_outputs:
        match = NORMAL_PORT_RE.match(outp)
        if match is None:
            match = SPLIT_PORT_RE.match(outp)
            if match is None:
                glogger.critical(
                    "Output analysis not performable. There is a split port I can not identify: {}".format(
                        outp
                    )
                )
                return allcells
        output_name = match.group('portname')
        output_index = match.group('portindex')

        # ~ highest_index = 0
        if output_name not in output_groups:
            output_groups[output_name] = output_index
        else:
            if output_groups[output_name] < output_index:
                output_groups[output_name] = output_index
    allcells["inputs"] = 0
    allcells.at[allcells.node_types=="INPUT","inputs"] = 1

    allcells["outputs"] = 0
    allcells.at[allcells.node_types=="OUTPUT","outputs"] = 1

    return allcells """
