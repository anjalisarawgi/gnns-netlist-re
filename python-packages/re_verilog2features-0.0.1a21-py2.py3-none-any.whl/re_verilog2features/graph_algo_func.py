"""
Graph algorithm overrides
=========================

The functions in this file are graph algorithms and functions on graphs
copied from the respective graph packages and adapted to special needs.
"""

import networkx as nx
import scipy as sp
from networkx.utils import py_random_state
import pyintergraph


def sparse_katz_centrality_numpy(G, alpha=0.1, beta=1.0, normalized=True, weight=None):
    r"""Compute the Katz centrality for the graph G *with sparse matrices*.

    See networkx's documentation for
    :py:func:`katz_centrality_numpy<networkx:networkx.algorithms.centrality.katz_centrality_numpy>`
    for the params.
    """

    try:
        import numpy as np
    except ImportError:
        raise ImportError("Requires NumPy: http://scipy.org/")
    if len(G) == 0:
        return {}
    try:
        nodelist = beta.keys()
        if set(nodelist) != set(G):
            raise nx.NetworkXError(
                "beta dictionary " "must have a value for every node"
            )
        b = np.array(list(beta.values()), dtype=float)
    except AttributeError:
        nodelist = list(G)
        try:
            b = np.ones((len(nodelist), 1)) * float(beta)
        except (TypeError, ValueError, AttributeError):
            raise nx.NetworkXError("beta must be a number")
    A = nx.adjacency_matrix(G, nodelist=nodelist, weight=weight).transpose().tocsr()
    n = A.shape[0]
    tosolve = sp.sparse.eye(n, n, format="csr") - (alpha * A)
    centrality = sp.sparse.linalg.spsolve(tosolve, b)
    if normalized:
        try:
            norm = sp.sparse.linalg.norm(centrality)
        except TypeError:  # result of spsolve is not sparse.
            norm = np.linalg.norm(centrality)
        norm *= sp.sign(centrality.sum())
    else:
        norm = 1.0
    centrality = dict(zip(nodelist, map(float, centrality / norm)))
    return centrality


@py_random_state(5)
def betweenness_centrality_pivot(
    G, pivots=None, normalized=True, weight=None, endpoints=False, seed=None
):
    """This is a copy of networkx's betweenness centrality where pivots can be 
    specified by name

    See networkx's documentation for
    :py:func:`betweenness_centrality<networkx:networkx.algorithms.bipartite.centrality.betweenness_centrality>`
    for further details.

    :param G: Graph to operate on
    :type G: networkx.Graph
    :param pivots: List of pivot nodes or int of nodes for randomly chosen pivots, defaults to None
    :type pivots: list(str) or int, optional
    :param normalized: Normalize the betweenness?, defaults to True
    :type normalized: bool, optional
    :param weight: If None, all edge weights are considered equal.
      Otherwise holds the name of the edge attribute used as weight, defaults to None
    :type weight: str, optional
    :param endpoints: If True include the endpoints in the shortest path counts, defaults to False
    :type endpoints: bool, optional
    :param seed: Indicator of random number generation state.
        See :ref:`Randomness<networkx:randomness>`.
        Note that this is only used if k is not None and a int, defaults to None
    :type seed: random_state, optional
    :return: Dictionary of nodes with betweenness centrality as the value.
    :rtype: dict
    """
    from networkx.algorithms.centrality.betweenness import (
        _single_source_shortest_path_basic,
        _single_source_dijkstra_path_basic,
        _accumulate_endpoints,
        _accumulate_basic,
        _rescale,
    )

    betweenness = dict.fromkeys(G, 0.0)  # b[v]=0 for v in G
    if pivots is None:
        nodes = G
        k = None
    elif isinstance(pivots, int):
        nodes = seed.sample(G.nodes(), pivots)
        k = pivots
    elif isinstance(pivots, list) and pivots:
        nodes = pivots
        k = len(pivots)
    else:
        nodes = G
        k = None
    for s in nodes:
        # single source shortest paths
        if weight is None:  # use BFS
            S, P, sigma, _ = _single_source_shortest_path_basic(G, s)
        else:  # use Dijkstra's algorithm
            S, P, sigma, _ = _single_source_dijkstra_path_basic(G, s, weight)
        # accumulation
        if endpoints:
            betweenness, _ = _accumulate_endpoints(betweenness, S, P, sigma, s)
        else:
            betweenness, _ = _accumulate_basic(betweenness, S, P, sigma, s)
    # rescaling
    betweenness = _rescale(
        betweenness,
        len(G),
        normalized=normalized,
        directed=G.is_directed(),
        k=k,
        endpoints=endpoints,
    )
    return betweenness


def nx2igraph(nxG):
    """Convert a networkx graph to a igraph graph

    This function is a thin wrapper for igraphs functionality,
    with lazy-import

    .. note::
        This method imports igraph
    
    :param nxG: networkx Graph to convert to a igraph graph
    :type nxG: networkx.Graph
    :return: ``nxG`` converted to a igraph graph
    :rtype: igraph.Graph
    """

    import igraph as ig

    igG = ig.Graph.from_networkx(nxG)
    # vertex names shall be kept.
    igG.vs["name"] = igG.vs["_nx_name"]
    return igG

def nx2gt(
    nxG,
    labelname="node_name",
    openmp_threads=1,
    openmp_schedule="guided",
    openmp_chunks=1,
):
    """Convert a networkx graph to a graph_tool graph

    This method is pretty stupid and does not convert
    anything else than graph structure and node names.

    In particular, this does not convert node attributes, edge weights etc.

    .. note::
        This method imports graph_tool.
        For further documentation of the ``openmp_schedule`` and ``openmp_chunk``
        parameters, please see http://jakascorner.com/blog/2016/06/omp-for-scheduling.html
    
    :param nxG: networkx Graph to convert to a graph_tool graph
    :type nxG: networkx.Graph
    :param labelname: graph_tool id's nodes with integers. The node name must therefore 
        be saved as a vertex property. Specify the vertex property name here and access
        the name later by ``gtG.vp[<labelname>]``. defaults to "node_name"
    :type labelname: str, optional
    :param openmp_threads: This function imports graph_tool, maybe for the first time.
        As a safeguard, we should set the openmp threads (*multiplies by any 
        multiprocessing!*) here. defaults to 1
    :type openmp_threads: int, optional
    :param openmp_schedule: This function imports graph_tool, maybe for the first time.
        As a safeguard, we should set the openmp schedule here, defaults to "guided"
    :type openmp_schedule: str, optional
    :param openmp_chunks: This function imports graph_tool, maybe for the first time.
        As a safeguard, we should set the openmp chunks here, defaults to 1
    :type openmp_chunks: int, optional
    :return: ``nxG`` converted to a graph_tool graph
    :rtype: graph_tool.Graph
    """

    import graph_tool

    graph_tool.openmp_set_num_threads(openmp_threads)
    graph_tool.openmp_set_schedule(openmp_schedule, chunk=openmp_chunks)

    gtG = graph_tool.Graph(directed=nxG.is_directed())

    node_type = pyintergraph.infer.infer_type(nxG.nodes())

    if labelname:
        name_property = gtG.new_vertex_property(node_type)

    nodes = {}
    empty_vertices = gtG.add_vertex(len(nxG))

    for name, v in zip(nxG.nodes(), empty_vertices):

        if labelname:
            name_property[v] = name
        nodes[name] = v

    for u, v in nxG.edges():
        gtG.add_edge(nodes[u], nodes[v])

    gtG.vp[labelname] = name_property

    return gtG
