#!usr/bin/ipython3

# read in graph

# find best clustering

# replace clusters with single nodes, with info on size compared to total

import glob
import logging
import os

os.environ["NUMEXPR_NUM_THREADS"] = "8"
os.environ["BLOSC_NOLOCK"] = "1"

import sys  # noqa: E402
from os.path import isfile  # noqa: E402
import shutil

import networkx as nx  # noqa: E402
import pandas as pd  # noqa: E402
import toml  # noqa: E402
import collections.abc  # noqa: E402
from itertools import product  # noqa: E402
from re_verilog2features.globalArgParse import GLOBAL_PARSER  # noqa: E402

from re_verilog2features.clustering import clustering_algorithms  # noqa: E402
from re_verilog2features.clustering.clustering_params_default import (  # noqa: E402
    CLUSTERING_PARAMS_DEFAULT,
)
from re_verilog2features.clustering.clustering_helpers import (  # noqa: E402
    store_clusters,
    ModuleDictProxy,
    export_partitions,
    get_match2,
    export_single_run,
)
from re_verilog2features.clustering.clustering_workflow_legacy import (  # noqa: E402
    get_results as get_results_legacy,
)

import tueisec_myparsing.pool_wrapper as pool_wrapper  # noqa: E402

glogger = logging.getLogger(__name__)

# ~ from networkx.algorithms.community import greedy_modularity_communities
COMPLEVEL = 9
COMPLIB = "blosc:snappy"

hierarchy_path_default = "outputFiles/{}/hierarchy/"
pg_path_default = "outputFiles/{}/partition_graph/"
cg_path_default = "outputFiles/{}/clustered_graph/"
cluster_choices = [
    "mcl",
    "louvain",
    "louvain_dend",
    "leiden-mod",
    "leiden-cpm",
    "walkscan",
    "walkscan-py",
    "io-bwn",
    "io-bwn-rust",
    "nsbm",
]
task_choices = ["partition"] + cluster_choices
task_options = ["all", "cluster"] + task_choices

try:  # sphinx barrier, because sphinx does not initialize GLOBAL_PARSER and will fail at import
    GLOBAL_PARSER.add_argument(
        "designs", help="folder where adjacency lists are located (*.txt)", nargs="+"
    )

    GLOBAL_PARSER.add_argument("--cores", help="Cores to use for processing", type=int)

    GLOBAL_PARSER.add_argument(
        "--gt_cores",
        help="Cores to use for graphtool/other clustering. Multiplies by --cores!",
        default=1,
        type=int,
    )

    GLOBAL_PARSER.add_argument(
        "-i",
        "--hierarchy_path",
        help="The folder where hierarchy files are stored",
        default=hierarchy_path_default,
    )

    GLOBAL_PARSER.add_argument(
        "--no-hierarchy",
        help="If specified, perform clustering without a hierarch file",
        action="store_true",
    )

    GLOBAL_PARSER.add_argument(
        "--legacy",
        help="If specified, use old output format with params in folder names",
        action="store_true",
    )

    GLOBAL_PARSER.add_argument(
        "-p",
        "--partition_graph_path",
        help=(
            "The folder where partition_graph output files will be "
            "stored in a subfolder depending on process"
        ),
        default=pg_path_default,
    )

    GLOBAL_PARSER.add_argument(
        "-c",
        "--clustered_graph_path",
        help=(
            "The folder where clustered_graph output files will be "
            "stored in a subfolder depending on process"
        ),
        default=cg_path_default,
    )

    GLOBAL_PARSER.add_argument(
        "--overwrite", help="What to overwrite", nargs="+", choices=task_options
    )

    GLOBAL_PARSER.add_argument(
        "--task", help="Task to perform", default="all", choices=task_options, nargs="+"
    )

    GLOBAL_PARSER.add_argument(
        "--min_comms", help="Minumim number of communities wanted for io-bwn", type=int
    )

    GLOBAL_PARSER.add_argument(
        "--max_comms", help="Maximum number of communities wanted for io-bwn", type=int
    )

    GLOBAL_PARSER.add_argument(
        "--max_tries",
        help="Maximum number of tries removing a edge while doing girvan_newman",
        type=int,
    )

    GLOBAL_PARSER.add_argument(
        "-T",
        "--threshold",
        help="Cluster quality threshold. clusters worse than this threshold are dropped.",
        type=float,
        default=0.3,
    )

    GLOBAL_PARSER.add_argument(
        "-u",
        "--used_lib",
        help="The library used for the designs. Specify this to override "
        "autodetection, which may fuction only in a few cases. The default is "
        "to recognize this from the design file paths (base folder name).",
    )

    GLOBAL_PARSER.add_argument(
        "--config",
        help="config file to override params for the clustering algos.",
        default=None,
    )
except BaseException:
    glogger.error("GLOBAL_PARSER unitialized. Are you really sure that you init'ed it?")

global_config = {}


def update_config(config, update):
    for k, v in update.items():
        if isinstance(v, collections.abc.Mapping):
            config[k] = update_config(config.get(k, {}), v)
        else:
            config[k] = v
    return config


def multi_run_wrapper(args):
    return get_results(*args)


def multi_run_wrapper_legacy(args):
    global global_config
    return get_results_legacy(*args, global_config=global_config)


def dictinvert(d):
    inv = {}
    for k, v in d.items():
        keys = inv.setdefault(v, [])
        keys.append(k)
    return inv


def get_results(
    design_file, hierarchy_file, partition_graph_path, clustered_graph_path
):
    # real hierarchy

    global global_config

    # convert to networkx DiGraph
    glogger.info("Runner begins with {}".format(design_file))
    design_name = os.path.basename(design_file)[:-4]

    glogger.debug("Read adjlist")
    graph = nx.read_adjlist(design_file, create_using=nx.DiGraph())
    no_clk_rst_graph = nx.subgraph_view(
        graph,
        filter_node=lambda node: not (
            node.startswith("INPUT")
            and (node.find("clk") >= 0 or node.find("rst") >= 0)
        ),
    )
    if not graph or not graph.number_of_edges():
        glogger.error("Graph has no edges or no nodes: %s", design_file)
        return
    glogger.debug("Read adjlist")

    if hierarchy_file is None:
        glogger.info(
            "Empty hierarchy for {}. Performing no golden and outputting all partitions.".format(
                design_name
            )
        )
        module_dict = ModuleDictProxy()
        modules_dict = ModuleDictProxy()
    else:
        module_dict = pd.read_csv(hierarchy_file, dtype=str, keep_default_na=True).drop(
            ["Unnamed: 0"], axis=1
        )
        module_dict = module_dict.to_dict("series")
        module_dict = {k: set(v.dropna()) for k, v in module_dict.items()}
        glogger.debug("Read module csv")

        hierarchy_modules_file = "hierarchy_modules".join(
            hierarchy_file.rsplit("hierarchy", 1)
        )
        modules_dict = pd.read_csv(hierarchy_modules_file, index_col=0, dtype=str)
        modules_dict = modules_dict.to_dict()
        glogger.debug("Read hierarchy")

        # write out csvs and partition adj list
        if not module_dict:
            glogger.info("Empty module_dict for {}. Skipping.".format(design_name))
            sys.stdout.flush()
            return
    # huge if-else discerning the tasks to be done.
    if "partition" in global_config["task"] and not hierarchy_file is None:
        if (
            os.path.exists(os.path.join(partition_graph_path, design_name))
            # existing_p
            and "partition" not in global_config["overwrite"]
        ):
            glogger.error(
                "Partitions for {} seem to be processed already. Skipping. Use "
                "`--overwrite partition` to overwrite.".format(design_name)
            )
        else:
            # due to partition renaming we have to be strict and delete the output folder
            # for partitions.
            if os.path.exists(os.path.join(partition_graph_path, design_name)):
                shutil.rmtree(os.path.join(partition_graph_path, design_name))
            dfs = export_partitions(
                modules_dict,
                design_name,
                graph,
                module_dict,
            )
            store_clusters(
                partition_graph_path, design_name, "_partitionReal.pq", dfs
            )

    if "mcl" in global_config["task"]:
        # for mcl
        I = global_config["params"]["mcl"]["I"]  # noqa: E741
        PreI = global_config["params"]["mcl"]["PreI"]
        params = product(PreI, I)
        t = str(GLOBAL_PARSER.gt_cores)
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_mcl/*"
                )
            )
            and "mcl" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_mcl/"
            )

        for param_id, (prei, i) in enumerate(params):
            param = {"prei": float(prei), "i": float(i)}
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path, design_name + "/partitionCluster_mcl/*"
                    )
                )
                and "mcl" not in global_config["overwrite"]
                and param in existing_params
            ):
                glogger.error(
                    "MCL cluster for params prei={}, I={} already done. Skipping. Use "
                    "`--overwrite mcl` to overwrite".format(prei, i)
                )
                continue
            cluster_modules = clustering_algorithms.clustering_mcl(
                no_clk_rst_graph, i, prei, design_name, t
            )

            glogger.info(
                "mcl prei={}, I={} found {} clusters. matching now...".format(
                    prei, i, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "mcl/paramset-{p:03}/cluster_{c}",
                param_id + id_offset,
            )

            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

            dictionary = generate_dictionary(param_id + id_offset, param)

            store_dictionary(
                dictionary,
                clustered_graph_path,
                design_name,
                "partitionCluster_mcl/paramset-{p:03}/",
                param_id + id_offset,
            )

    if "louvain_dend" in global_config["task"]:
        #####################################################
        # for louvain - this is different each time, maybe run several times?
        postprocessing = global_config["params"]["louvain_dend"]["postprocessing"]
        if len(postprocessing) > 2 or any(
            p not in ("flattened", "unflattened") for p in postprocessing
        ):
            raise ValueError(
                "Your config option postprocessing `{}` is not allowed".format(
                    postprocessing
                )
            )
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path,
                    design_name + "/partitionCluster_louvain_dend/*",
                )
            )
            and "louvain_dend" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_louvain_dend/"
            )

        for param_id, post in enumerate(postprocessing):
            if (
                (
                    glob.glob(
                        os.path.join(
                            clustered_graph_path,
                            design_name + "/partitionCluster_louvain_dend/*",
                        )
                    )
                )
                and "louvain_dend" not in global_config["overwrite"]
                and any(d["postprocessing"] == post for d in existing_params)
            ):
                glogger.error(
                    "louvain_dend cluster {} already done. Skipping. Use"
                    "`--overwrite louvain_dend` to overwrite".format(post)
                )
            else:
                if post == "flattened":
                    cluster_modules = clustering_algorithms.cluster_graph_louvain_dend(
                        no_clk_rst_graph,
                    )
                    glogger.info(
                        "louvain_dend found {} clusters. matching now...".format(
                            len(cluster_modules)
                        )
                    )

                    match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

                    dfs = export_single_run(
                        match,
                        graph,
                        cluster_modules,
                        modules_dict,
                        design_name,
                        "louvain_dend/paramset-{p:03}/cluster_{c}",
                        param_id + id_offset,
                    )
                    store_clusters(clustered_graph_path, design_name, ".pq", dfs)

                    param = {"postprocessing": post}
                    dictionary = generate_dictionary(param_id + id_offset, param)
                    store_dictionary(
                        dictionary,
                        clustered_graph_path,
                        design_name,
                        "partitionCluster_louvain_dend/paramset-{p:03}/",
                        param_id + id_offset,
                    )

                else:
                    cluster_modules_levels = (
                        clustering_algorithms.cluster_graph_louvain_dend_unflattened(
                            no_clk_rst_graph,
                        )
                    )
                    for i, level in enumerate(cluster_modules_levels):
                        glogger.info(
                            "louvain_dend found {} clusters. matching now...".format(
                                len(level)
                            )
                        )

                        match = get_match2(level, module_dict, GLOBAL_PARSER.threshold)

                        dfs = export_single_run(
                            match,
                            graph,
                            level,
                            modules_dict,
                            design_name,
                            "louvain_dend/paramset-{p:03}/cluster_{c}",
                            (param_id + id_offset + i),
                        )
                        store_clusters(clustered_graph_path, design_name, ".pq", dfs)

                        param = {"postprocessing": post, "level": i}
                        dictionary = generate_dictionary(
                            param_id + i + id_offset, param
                        )
                        store_dictionary(
                            dictionary,
                            clustered_graph_path,
                            design_name,
                            "partitionCluster_louvain_dend/paramset-{p:03}/",
                            param_id + i + id_offset,
                        )

    if "louvain" in global_config["task"]:
        #####################################################
        resolution = global_config["params"]["louvain"]["resolution"]  # noqa: E741
        random_state = global_config["params"]["louvain"]["random_state"]
        params = product(resolution, random_state)
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_louvain/*"
                )
            )
            and "louvain" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_louvain/"
            )

        for param_id, (resolution, random_state) in enumerate(params):
            try:
                random_state = int(random_state)
            except BaseException:
                random_state = None
            param = {"resolution": float(resolution), "random_state": random_state}
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path, design_name + "/partitionCluster_louvain/*"
                    )
                )
                and "louvain" not in global_config["overwrite"]
                and param in existing_params
            ):
                glogger.error(
                    "Louvain cluster for params resolution={}, random_state={} already done. Skipping. Use "
                    "`--overwrite louvain` to overwrite".format(resolution, random_state)
                )
                continue

            cluster_modules = clustering_algorithms.clustering_louvain_undirected(
                no_clk_rst_graph, resolution, random_state,
            )

            glogger.info(
                "louvain resolution={}, random_state={} found {} clusters. matching now...".format(
                    resolution, random_state, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "louvain/paramset-{p:03}/cluster_{c}",
                param_id + id_offset,
            )

            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

            dictionary = generate_dictionary(param_id + id_offset, param)

            store_dictionary(
                dictionary,
                clustered_graph_path,
                design_name,
                "partitionCluster_louvain/paramset-{p:03}/",
                param_id + id_offset,
            )


    if "leiden-mod" in global_config["task"]:
        #####################################################
        # for leiden
        n_iterations = global_config["params"]["leiden-mod"]["n_iterations"]  # noqa: E741
        params = product(n_iterations)
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_leiden-mod/*"
                )
            )
            and "leiden-mod" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_leiden-mod/"
            )

        for param_id, (n_iterations,) in enumerate(params):
            param = {"n_iterations": int(n_iterations)}
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path, design_name + "/partitionCluster_leiden-mod/*"
                    )
                )
                and "leiden-mod" not in global_config["overwrite"]
                and param in existing_params
            ):
                glogger.error(
                    "Leiden-mod cluster for params n_iterations={} already done. Skipping. Use "
                    "`--overwrite leiden-mod` to overwrite".format(n_iterations)
                )
                continue

            cluster_modules = clustering_algorithms.clustering_leiden_mod(
                no_clk_rst_graph, design_name, n_iterations=n_iterations,
            )

            glogger.info(
                "leiden-mod n_iterations={} found {} clusters. matching now...".format(
                    n_iterations, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "leiden-mod/paramset-{p:03}/cluster_{c}",
                param_id + id_offset,
            )

            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

            dictionary = generate_dictionary(param_id + id_offset, param)

            store_dictionary(
                dictionary,
                clustered_graph_path,
                design_name,
                "partitionCluster_leiden-mod/paramset-{p:03}/",
                param_id + id_offset,
            )


    if "leiden-cpm" in global_config["task"]:
        #####################################################
        # for leiden

        resolution_parameters = global_config["params"]["leiden-cpm"]["r"]

        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_leiden-cpm/*"
                )
            )
            and "leiden-cpm" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_leiden-cpm/"
            )

        for param_id, resolution_parameter in enumerate(resolution_parameters):
            resolution_parameter = float(resolution_parameter)
            param = {"r": resolution_parameter}
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name + "/partitionCluster_leiden-cpm/*",
                    )
                )
                and "leiden-cpm" not in global_config["overwrite"]
                and param in existing_params
            ):
                glogger.error(
                    "Leiden-cpm cluster for r={} already done. Skipping. Use "
                    "`--overwrite leiden-cpm` to overwrite".format(resolution_parameter)
                )
                continue

            cluster_modules = clustering_algorithms.clustering_leiden_CPM(
                no_clk_rst_graph, design_name, resolution_parameter
            )

            glogger.info(
                "leiden_cpm r={} found {} clusters. matching now...".format(
                    resolution_parameter, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "leiden-cpm/paramset-{p:03}/cluster_{c}",
                param_id + id_offset,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

            dictionary = generate_dictionary(param_id + id_offset, param)
            store_dictionary(
                dictionary,
                clustered_graph_path,
                design_name,
                "partitionCluster_leiden-cpm/paramset-{p:03}/",
                param_id + id_offset,
            )

    if "walkscan" in global_config["task"]:
        #####################################################
        # for walkscan
        nb_steps = global_config["params"]["walkscan"]["nb_steps"]
        epsilon = global_config["params"]["walkscan"]["epsilon"]
        min_pts = global_config["params"]["walkscan"]["min_pts"]
        params = product(nb_steps, epsilon, min_pts)
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_walkscan/*"
                )
            )
            and "walkscan" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_walkscan/"
            )

        for param_id, param in enumerate(params):
            param = {
                "nb_steps": int(param[0]),
                "epsilon": float(param[1]),
                "min_pts": float(param[2]),
            }
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name + "/partitionCluster_walkscan/*",
                    )
                )
                and "walkscan" not in global_config["overwrite"]
                and param in existing_params
            ):
                glogger.error(
                    "Walkscan cluster already done. Skipping. Use "
                    "`--overwrite walkscan` to overwrite"
                )
                continue
            param_org = param.copy()
            param["name"] = design_name
            cluster_modules = clustering_algorithms.clustering_walkscan_c(
                no_clk_rst_graph,
                param["nb_steps"],
                param["epsilon"],
                param["min_pts"],
                param["name"],
            )

            glogger.info(
                "walkscan param={} found {} clusters. matching now...".format(
                    str(param), len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "walkscan/paramset-{p:03}/cluster_{c}",
                param_id + id_offset,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

            dictionary = generate_dictionary(param_id + id_offset, param_org)
            store_dictionary(
                dictionary,
                clustered_graph_path,
                design_name,
                "partitionCluster_walkscan/paramset-{p:03}/",
                param_id + id_offset,
            )

    if "walkscan-py" in global_config["task"]:
        #####################################################
        # for walkscan
        nb_steps = global_config["params"]["walkscan"]["nb_steps"]
        epsilon = global_config["params"]["walkscan"]["epsilon"]
        min_pts = global_config["params"]["walkscan"]["min_pts"]
        params = product(nb_steps, epsilon, min_pts)
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_walkscan/*"
                )
            )
            and "walkscan" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_walkscan/"
            )

        for param_id, param in enumerate(params):
            param = {
                "nb_steps": int(param[0]),
                "epsilon": float(param[1]),
                "min_pts": float(param[2]),
            }
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name + "/partitionCluster_walkscan/*",
                    )
                )
                and "walkscan" not in global_config["overwrite"]
                and param in existing_params
            ):
                glogger.error(
                    "Walkscan cluster already done. Skipping. Use"
                    "`--overwrite walkscan` to overwrite"
                )
                continue
            param_org = param.copy()
            param["name"] = design_name
            cluster_modules = clustering_algorithms.clustering_walkscan_py(
                no_clk_rst_graph,
                param["nb_steps"],
                param["epsilon"],
                param["min_pts"],
                param["name"],
            )

            glogger.info(
                "walkscan_py param={} found {} clusters. matching now...".format(
                    param, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "walkscan/paramset-{p:03}/cluster_{c}",
                param_id + id_offset,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

            dictionary = generate_dictionary(param_id + id_offset, param_org)
            store_dictionary(
                dictionary,
                clustered_graph_path,
                design_name,
                "partitionCluster_walkscan/paramset-{p:03}/",
                param_id + id_offset,
            )

    if "nsbm" in global_config["task"]:
        #####################################################
        # for nsbm
        postprocessing = global_config["params"]["nsbm"]["postprocessing"]
        if len(postprocessing) > 2 or any(
            p not in ("flattened", "unflattened") for p in postprocessing
        ):
            raise ValueError(
                "Your config option postprocessing `{}` is not allowed".format(
                    postprocessing
                )
            )
        id_offset = 0
        existing_params = []
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_nsbm/*"
                )
            )
            and "nsbm" not in global_config["overwrite"]
        ):
            id_offset, existing_params = get_existing_param_data(
                clustered_graph_path, design_name, "partitionCluster_nsbm/"
            )

        for param_id, post in enumerate(postprocessing):
            if (
                (
                    glob.glob(
                        os.path.join(
                            clustered_graph_path,
                            design_name + "/partitionCluster_nsbm/*",
                        )
                    )
                )
                and "nsbm" not in global_config["overwrite"]
                and any(d["postprocessing"] == post for d in existing_params)
            ):
                glogger.error(
                    "nsbm cluster {} already done. Skipping. Use"
                    "`--overwrite nsbm` to overwrite".format(post)
                )
            else:
                if post == "flattened":
                    cluster_modules = clustering_algorithms.clustering_nsbm(
                        no_clk_rst_graph,
                        design_name,
                    )
                    glogger.info(
                        "nsbm found {} clusters. matching now...".format(
                            len(cluster_modules)
                        )
                    )

                    match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

                    dfs = export_single_run(
                        match,
                        graph,
                        cluster_modules,
                        modules_dict,
                        design_name,
                        "nsbm/paramset-{p:03}/cluster_{c}",
                        param_id + id_offset,
                    )
                    store_clusters(clustered_graph_path, design_name, ".pq", dfs)

                    param = {"postprocessing": post}
                    dictionary = generate_dictionary(param_id + id_offset, param)
                    store_dictionary(
                        dictionary,
                        clustered_graph_path,
                        design_name,
                        "partitionCluster_nsbm/paramset-{p:03}/",
                        param_id + id_offset,
                    )

                else:
                    cluster_modules_levels = (
                        clustering_algorithms.clustering_nsbm_unflattened(
                            no_clk_rst_graph,
                            design_name,
                        )
                    )
                    for i, level in enumerate(cluster_modules_levels):
                        glogger.info(
                            "nsbm found {} clusters. matching now...".format(len(level))
                        )

                        match = get_match2(level, module_dict, GLOBAL_PARSER.threshold)

                        dfs = export_single_run(
                            match,
                            graph,
                            level,
                            modules_dict,
                            design_name,
                            "nsbm/paramset-{p:03}/cluster_{c}",
                            param_id + i + id_offset,
                        )
                        store_clusters(clustered_graph_path, design_name, ".pq", dfs)

                        param = {"postprocessing": post, "level": i}
                        dictionary = generate_dictionary(
                            param_id + i + id_offset, param
                        )
                        store_dictionary(
                            dictionary,
                            clustered_graph_path,
                            design_name,
                            "partitionCluster_nsbm/paramset-{p:03}/",
                            param_id + i + id_offset,
                        )

    if "io-bwn-rust" in global_config["task"]:
        #####################################################
        # for walkscan
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_io_bwn/*"
                )
            )
            and "io-bwn-rust" not in global_config["overwrite"]
        ):
            glogger.error(
                "IO-betweenness cluster already done. Skipping. Use"
                "`--overwrite io-bwn-rust` to overwrite"
            )
        else:
            cluster_modules = clustering_algorithms.clustering_iobwn_rust(
                no_clk_rst_graph,
                GLOBAL_PARSER.min_comms,
                GLOBAL_PARSER.max_comms,
                GLOBAL_PARSER.max_tries,
                name=design_name,
            )

            glogger.info(
                "io_bwn_rust found {} clusters. matching now...".format(
                    len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "io_bwn/cluster_{c}",
                None,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "io-bwn" in global_config["task"]:
        #####################################################
        # for walkscan
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_io_bwn/*"
                )
            )
            and "io-bwn" not in global_config["overwrite"]
        ):
            glogger.error(
                "IO-betweenness cluster already done. Skipping. Use"
                "`--overwrite io-bwn` to overwrite"
            )
        else:
            cluster_modules = clustering_algorithms.clustering_iobwn_gt(
                no_clk_rst_graph,
                GLOBAL_PARSER.min_comms,
                GLOBAL_PARSER.max_comms,
                GLOBAL_PARSER.max_tries,
                name=design_name,
            )

            glogger.info(
                "io_bwn_rust found {} clusters. matching now...".format(
                    len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "io_bwn/cluster_{c}",
                None,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)
    sys.stdout.flush()


def exists_in_hdf5(existing_keys, search_string):
    return any(search_string in key for key in existing_keys)


def generate_dictionary(param_id, param):
    dict_id_param = {}
    dict_id_param["ID-{i:03}".format(i=param_id)] = param
    return dict_id_param


def store_dictionary(
    dictionary, clustered_graph_path, design_name, param_id_format, param_id
):
    dict_path = os.path.join(
        clustered_graph_path,
        design_name,
        param_id_format.format(p=param_id),
        "param-values.toml"
    )
    os.makedirs(os.path.dirname(dict_path), exist_ok=True)
    with open(dict_path, "w") as f:
        toml.dump(dictionary, f)


def get_existing_param_data(clustered_graph_path, design_name, method):
    dict_path = os.path.join(clustered_graph_path, design_name, method)
    paramsets = os.listdir(dict_path)
    id_offset = len(paramsets)
    existing_param = [None] * id_offset
    for i, file_name in enumerate(paramsets):
        if os.path.isfile(os.path.join(dict_path, file_name, "/param-values.toml")):
            existing_param[i] = list(
                toml.load(os.path.join(dict_path, file_name, "/param-values.toml")).values()
            )[0]
    return id_offset, existing_param


def get_match(cluster_modules, module_dict):

    match_dict = {}

    for y, clust in enumerate(cluster_modules):
        for key, real in module_dict.items():
            occuring = sum(el in real for el in clust)
            if not occuring == 0:

                if y not in match_dict:
                    match_dict[y] = {}
                    match_dict[y][key] = occuring
                else:
                    match_dict[y][key] = occuring

    T1 = 0.8
    new_match_dict = {}
    for cluster, occ_list in match_dict.items():
        new_match_dict[cluster] = {}
        # compare value to real size of
        # pick max and values with 20% of those
        max_value = max(occ_list.values())
        for k, v in match_dict[cluster].items():
            if (
                v >= T1 * max_value
            ):  # if it is the largest, or within the largest of the groups
                size = len(module_dict[k])
                # figure out which one is closest to the cluster size
                diff = (size - v) / size
                # figure out which one is closer to true size
                # write dict of real, fake with difference, then pick smallest?
                if abs(diff) < 0.2:
                    new_match_dict[cluster][k] = diff
    match = {}
    for k, v in new_match_dict.items():
        try:
            match[k] = min(v.keys(), key=v.get)
        except ValueError:
            pass
    return match


def perform_clustering():

    global global_config

    if isinstance(GLOBAL_PARSER.task, str):
        if GLOBAL_PARSER.task == "all":
            global_config["task"] = task_choices
        elif GLOBAL_PARSER.task == "cluster":
            global_config["task"] = cluster_choices
        else:
            global_config["task"] = [GLOBAL_PARSER.task]
    else:
        if "all" in GLOBAL_PARSER.task:
            global_config["task"] = task_choices
        elif "cluster" in GLOBAL_PARSER.task:
            global_config["task"] = set(
                cluster_choices + GLOBAL_PARSER.task.remove("cluster")
            )
        else:
            global_config["task"] = set(GLOBAL_PARSER.task)

    if isinstance(GLOBAL_PARSER.overwrite, str):
        if GLOBAL_PARSER.overwrite == "all":
            global_config["overwrite"] = task_choices
        elif GLOBAL_PARSER.overwrite == "cluster":
            global_config["overwrite"] = cluster_choices
            # TODO: Sort task choices into clustering extra list, join list of partition and
            # clusteringlist to task_choices. at top of file!
        else:
            global_config["overwrite"] = [GLOBAL_PARSER.overwrite]
    elif not GLOBAL_PARSER.overwrite:
        global_config["overwrite"] = []
    else:
        if "all" in GLOBAL_PARSER.overwrite:
            global_config["overwrite"] = task_choices
        elif "cluster" in GLOBAL_PARSER.overwrite:
            global_config["overwrite"] = set(
                cluster_choices + GLOBAL_PARSER.overwrite.remove("cluster")
            )
        else:
            global_config["overwrite"] = set(GLOBAL_PARSER.overwrite)

    if "io-bwn" in global_config["task"] or "io-bwn-rust" in global_config["task"]:
        if (
            GLOBAL_PARSER.min_comms is None
            or GLOBAL_PARSER.max_comms is None
            or GLOBAL_PARSER.max_tries is None
        ):
            glogger.critical(
                "Minimum and/or maximum number of wanted communities and/or maximum number "
                "of tries not given. Please specify --min_comms, --max_comms and --max_tries"
            )
            return

    if GLOBAL_PARSER.config is not None:
        try:
            global_config["params"] = CLUSTERING_PARAMS_DEFAULT
            update_config(global_config["params"], toml.load(GLOBAL_PARSER.config))
        except BaseException:
            glogger.exception("Could not load params toml due to:")
            return
    else:
        if not os.path.exists("clustering_params.toml"):
            with open("clustering_params.toml", "w") as outfile:
                toml.dump(CLUSTERING_PARAMS_DEFAULT, outfile)
        else:
            glogger.warning(
                "A clustering config exists at clustering_params.toml"
                ". Do you want to use it, maybe?"
            )
        global_config["params"] = CLUSTERING_PARAMS_DEFAULT

    if isinstance(GLOBAL_PARSER.designs, str):
        design_path = GLOBAL_PARSER.designs
        if design_path.endswith(".txt"):
            designs = [design_path]
        else:
            designs = glob.glob(os.path.join(design_path, "*.txt"))
            glogger.info("Found {} adjacency lists.".format(len(designs)))
    else:
        designs = []
        for design_path in GLOBAL_PARSER.designs:
            if design_path.endswith(".txt"):
                designs.append(design_path)
            else:
                add_designs = glob.glob(os.path.join(design_path, "*.txt"))
                glogger.info(
                    "Found {} adjacency lists in {}.".format(
                        len(add_designs), design_path
                    )
                )
                designs.extend(add_designs)

    designs = sorted(designs, key=lambda x: os.path.getsize(x), reverse=True)

    # real hierarchy
    mult = []
    for design_file in designs:
        design_name = os.path.basename(design_file)[:-4]
        if GLOBAL_PARSER.used_lib:
            used_lib = GLOBAL_PARSER.used_lib
        else:
            # use "autodetection"
            used_lib = os.path.basename(os.path.dirname(os.path.dirname(design_file)))
            if not used_lib:
                glogger.error(
                    "Autodetection failed for {}: used_lib detected "
                    "is empty.".format(
                        design_file,
                    )
                )
                continue
        partition_graph_path = os.path.join(
            GLOBAL_PARSER.partition_graph_path.format(used_lib)
        )
        clustered_graph_path = os.path.join(
            GLOBAL_PARSER.clustered_graph_path.format(used_lib)
        )
        hierarchy_path = os.path.join(GLOBAL_PARSER.hierarchy_path.format(used_lib))
        hierarchy_file = os.path.join(
            hierarchy_path, "hierarchy_" + design_name + ".csv"
        )

        os.makedirs(partition_graph_path, exist_ok=True)
        os.makedirs(clustered_graph_path, exist_ok=True)
        if isfile(hierarchy_file):
            design_name = os.path.basename(design_file)[:-4]
            mult.append(
                (
                    design_file,
                    hierarchy_file,
                    partition_graph_path,
                    clustered_graph_path,
                )
            )
        elif not GLOBAL_PARSER.no_hierarchy:
            glogger.warning("For design {} no hierarchy output.".format(design_name))
        else:
            design_name = os.path.basename(design_file)[:-4]
            mult.append(
                (
                    design_file,
                    None,
                    partition_graph_path,
                    clustered_graph_path,
                )
            )

    glogger.info("Found {} designs.".format(len(mult)))
    if not len(mult) > 0:
        glogger.critical("Nothing to be done. Exiting...")
        return

    if GLOBAL_PARSER.legacy:
        pool_wrapper.run_in_pool_with_progress(
            multi_run_wrapper_legacy,
            mult,
            "Processing:",
            "designs",
            processes=GLOBAL_PARSER.cores,
        )
    else:
        pool_wrapper.run_in_pool_with_progress(
            multi_run_wrapper,
            mult,
            "Processing:",
            "designs",
            processes=GLOBAL_PARSER.cores,
        )

    glogger.info("Finished clustering")
