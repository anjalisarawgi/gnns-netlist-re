#!usr/bin/ipython3

# read in graph

# find best clustering

# replace clusters with single nodes, with info on size compared to total

import glob
import logging
import os

os.environ["NUMEXPR_NUM_THREADS"] = "8"
os.environ["BLOSC_NOLOCK"] = "1"

import sys  # noqa: E402

import networkx as nx  # noqa: E402
import pandas as pd  # noqa: E402
from itertools import product  # noqa: E402
from re_verilog2features.globalArgParse import GLOBAL_PARSER  # noqa: E402

from re_verilog2features.clustering import clustering_algorithms  # noqa: E402
from re_verilog2features.clustering.clustering_helpers import (  # noqa: E402
    store_clusters,
    ModuleDictProxy,
    export_partitions,
    get_match2,
    export_single_run,
)


glogger = logging.getLogger(__name__)

# ~ from networkx.algorithms.community import greedy_modularity_communities
COMPLEVEL = 9
COMPLIB = "blosc:snappy"

hierarchy_path_default = "outputFiles/{}/hierarchy/"
pg_path_default = "outputFiles/{}/partition_graph/"
cg_path_default = "outputFiles/{}/clustered_graph/"
cluster_choices = [
    "mcl",
    "louvain",
    "louvain_dend",
    "leiden-mod",
    "leiden-cpm",
    "walkscan",
    "walkscan-py",
    "io-bwn",
    "io-bwn-rust",
    "nsbm",
]
task_choices = ["partition"] + cluster_choices
task_options = ["all", "cluster"] + task_choices


def get_results(
    design_file,
    hierarchy_file,
    partition_graph_path,
    clustered_graph_path,
    global_config,
):
    # real hierarchy

    # convert to networkx DiGraph
    glogger.info("Runner begins with {}".format(design_file))
    design_name = os.path.basename(design_file)[:-4]

    glogger.debug("Read adjlist")
    graph = nx.read_adjlist(design_file, create_using=nx.DiGraph())
    no_clk_rst_graph = nx.subgraph_view(
        graph,
        filter_node=lambda node: not (
            node.startswith("INPUT")
            and (node.find("clk") >= 0 or node.find("rst") >= 0)
        ),
    )
    if not graph or not graph.number_of_edges():
        glogger.error("Graph has no edges or no nodes: %s", design_file)
        return
    glogger.debug("Read adjlist")

    if hierarchy_file is None:
        glogger.info(
            "Empty hierarchy for {}. Performing no golden and outputting all partitions.".format(
                design_name
            )
        )
        module_dict = ModuleDictProxy()
        modules_dict = ModuleDictProxy()
    else:
        module_dict = pd.read_csv(hierarchy_file, dtype=str, keep_default_na=True).drop(
            ["Unnamed: 0"], axis=1
        )
        module_dict = module_dict.to_dict("series")
        module_dict = {k: set(v.dropna()) for k, v in module_dict.items()}
        glogger.debug("Read module csv")

        hierarchy_modules_file = "hierarchy_modules".join(
            hierarchy_file.rsplit("hierarchy", 1)
        )
        modules_dict = pd.read_csv(hierarchy_modules_file, index_col=0, dtype=str)
        modules_dict = modules_dict.to_dict()
        glogger.debug("Read hierarchy")

        # write out csvs and partition adj list
        if not module_dict:
            glogger.info("Empty module_dict for {}. Skipping.".format(design_name))
            sys.stdout.flush()
            return
    # huge if-else discerning the tasks to be done.
    if "partition" in global_config["task"] and not hierarchy_file is None:
        if (
            os.path.exists(os.path.join(partition_graph_path, design_name))
            # existing_p
            and "partition" not in global_config["overwrite"]
        ):
            glogger.error(
                "Partitions for {} seem to be processed already. Skipping. Use "
                "`--overwrite partition` to overwrite.".format(design_name)
            )
        else:
            dfs = export_partitions(
                modules_dict,
                design_name,
                graph,
                module_dict,
            )
            store_clusters(
                partition_graph_path, design_name, "_partitionReal.hdf5", dfs
            )

    if "mcl" in global_config["task"]:
        # for mcl
        I = global_config["params"]["mcl"]["I"]  # noqa: E741
        PreI = global_config["params"]["mcl"]["PreI"]
        params = product(PreI, I)
        t = str(GLOBAL_PARSER.gt_cores)
        for prei, i in params:
            param = {"prei": float(prei), "i": float(i)}
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name
                        + "/partitionCluster_mcl/prei_{p[prei]:1.2f}_i_{p[i]:1.2f}/*".format(
                            p=param,
                        ),
                    )
                )
                and "mcl" not in global_config["overwrite"]
            ):
                glogger.error(
                    "MCL cluster for params prei={}, I={} already done. Skipping. Use "
                    "`--overwrite mcl` to overwrite".format(prei, i)
                )
                continue
            cluster_modules = clustering_algorithms.clustering_mcl(
                no_clk_rst_graph, i, prei, design_name, t
            )

            glogger.info(
                "mcl prei={}, I={} found {} clusters. matching now...".format(
                    prei, i, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "mcl/prei_{p[prei]:1.2f}_i_{p[i]:1.2f}/cluster_{c}",
                param,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "louvain_dend" in global_config["task"]:
        #####################################################
        # for louvain - this is different each time, maybe run several times?
        postprocessing = global_config["params"]["louvain_dend"]["postprocessing"]
        if len(postprocessing) > 2 or any(
            p not in ("flattened", "unflattened") for p in postprocessing
        ):
            raise ValueError(
                "Your config option postprocessing `{}` is not allowed".format(
                    postprocessing
                )
            )
        for p in postprocessing:
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name
                        + "/partitionCluster_louvain_dend/post_{}*".format(p),
                    )
                )
                or glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name
                        + "/partitionCluster_louvain_dend/post_{}/*".format(p),
                    )
                )
            ) and "louvain_dend" not in global_config["overwrite"]:
                glogger.error(
                    "louvain_dend cluster {} already done. Skipping. Use"
                    "`--overwrite louvain_dend` to overwrite".format(p)
                )
            else:
                if p == "flattened":
                    cluster_modules = clustering_algorithms.cluster_graph_louvain_dend(
                        no_clk_rst_graph,
                    )
                    glogger.info(
                        "louvain_dend found {} clusters. matching now...".format(
                            len(cluster_modules)
                        )
                    )

                    match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

                    dfs = export_single_run(
                        match,
                        graph,
                        cluster_modules,
                        modules_dict,
                        design_name,
                        "louvain_dend/post_flattened/cluster_{c}",
                        None,
                    )
                    store_clusters(clustered_graph_path, design_name, ".pq", dfs)
                else:
                    cluster_modules_levels = (
                        clustering_algorithms.cluster_graph_louvain_dend_unflattened(
                            no_clk_rst_graph,
                        )
                    )
                    for i, level in enumerate(cluster_modules_levels):
                        glogger.info(
                            "louvain_dend found {} clusters. matching now...".format(
                                len(level)
                            )
                        )

                        match = get_match2(level, module_dict, GLOBAL_PARSER.threshold)

                        dfs = export_single_run(
                            match,
                            graph,
                            level,
                            modules_dict,
                            design_name,
                            "louvain_dend/post_unflattened_level_{p}/cluster_{c}",
                            i,
                        )
                        store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "louvain" in global_config["task"]:
        #####################################################
        # for louvain - this is different each time, maybe run several times?
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path,
                    design_name + "/partitionCluster_louvain/*",
                )
            )
            and "louvain" not in global_config["overwrite"]
        ):
            glogger.error(
                "Louvain cluster already done. Skipping. Use "
                "`--overwrite louvain` to overwrite"
            )
        else:
            cluster_modules = clustering_algorithms.clustering_louvain_undirected(
                no_clk_rst_graph
            )

            glogger.info(
                "louvain found {} clusters. matching now...".format(
                    len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "louvain/cluster_{c}",
                None,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)
    if "leiden-mod" in global_config["task"]:
        #####################################################
        # for leiden
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path,
                    design_name + "/partitionCluster_leiden-mod/*",
                )
            )
            and "leiden-mod" not in global_config["overwrite"]
        ):
            glogger.error(
                "Leiden-mod cluster already done. Skipping. Use "
                "`--overwrite leiden-mod` to overwrite"
            )
        else:
            cluster_modules = clustering_algorithms.clustering_leiden_mod(
                no_clk_rst_graph, design_name
            )

            glogger.info(
                "leiden_mod found {} clusters. matching now...".format(
                    len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "leiden-mod/cluster_{c}",
                None,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "leiden-cpm" in global_config["task"]:
        #####################################################
        # for leiden

        resolution_parameters = global_config["params"]["leiden-cpm"]["r"]

        for resolution_parameter in resolution_parameters:
            resolution_parameter = float(resolution_parameter)
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name
                        + "/partitionCluster_leiden-cpm/r_{p:.4f}/*".format(
                            p=resolution_parameter
                        ),
                    )
                )
                and "leiden-cpm" not in global_config["overwrite"]
            ):
                glogger.error(
                    "Leiden-cpm cluster for r={} already done. Skipping. Use "
                    "`--overwrite leiden-cpm` to overwrite".format(resolution_parameter)
                )
                continue

            cluster_modules = clustering_algorithms.clustering_leiden_CPM(
                no_clk_rst_graph, design_name, resolution_parameter
            )

            glogger.info(
                "leiden_cpm r={} found {} clusters. matching now...".format(
                    resolution_parameter, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "leiden-cpm/r_{p:.4f}/cluster_{c}",
                resolution_parameter,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)
    if "walkscan" in global_config["task"]:
        #####################################################
        # for walkscan
        nb_steps = global_config["params"]["walkscan"]["nb_steps"]
        epsilon = global_config["params"]["walkscan"]["epsilon"]
        min_pts = global_config["params"]["walkscan"]["min_pts"]
        params = product(nb_steps, epsilon, min_pts)
        for param in params:
            param = {
                "nb_steps": int(param[0]),
                "epsilon": float(param[1]),
                "min_pts": float(param[2]),
            }
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name
                        + "/partitionCluster_walkscan/nb_{p[nb_steps]}_e_{p[epsilon]}_mp_{p[min_pts]}/*".format(
                            p=param
                        ),
                    )
                )
                and "walkscan" not in global_config["overwrite"]
            ):
                glogger.error(
                    "Walkscan cluster already done. Skipping. Use "
                    "`--overwrite walkscan` to overwrite"
                )
                continue
            param["name"] = design_name
            cluster_modules = clustering_algorithms.clustering_walkscan_c(
                no_clk_rst_graph,
                param["nb_steps"],
                param["epsilon"],
                param["min_pts"],
                param["name"],
            )

            glogger.info(
                "walkscan param={} found {} clusters. matching now...".format(
                    str(param), len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "walkscan/nb_{p[nb_steps]}_e_{p[epsilon]}_mp_{p[min_pts]}/cluster_{c}",
                param,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)
    if "walkscan-py" in global_config["task"]:
        #####################################################
        # for walkscan
        nb_steps = global_config["params"]["walkscan"]["nb_steps"]
        epsilon = global_config["params"]["walkscan"]["epsilon"]
        min_pts = global_config["params"]["walkscan"]["min_pts"]
        params = product(nb_steps, epsilon, min_pts)
        for param in params:
            param = {
                "nb_steps": int(param[0]),
                "epsilon": float(param[1]),
                "min_pts": float(param[2]),
            }
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name
                        + "/partitionCluster_walkscan/nb_{p[nb_steps]}_e_{p[epsilon]}_mp_{p[min_pts]}/*".format(
                            p=param
                        ),
                    )
                )
                and "walkscan" not in global_config["overwrite"]
            ):
                glogger.error(
                    "Walkscan cluster already done. Skipping. Use"
                    "`--overwrite walkscan` to overwrite"
                )
                continue
            param["name"] = design_name
            cluster_modules = clustering_algorithms.clustering_walkscan_py(
                no_clk_rst_graph,
                param["nb_steps"],
                param["epsilon"],
                param["min_pts"],
                param["name"],
            )

            glogger.info(
                "walkscan_py param={} found {} clusters. matching now...".format(
                    param, len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "walkscan/nb_{p[nb_steps]}_e_{p[epsilon]}_mp_{p[min_pts]}_cluster_{c}",
                param,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "nsbm" in global_config["task"]:
        #####################################################
        # for nsbm
        postprocessing = global_config["params"]["nsbm"]["postprocessing"]
        if len(postprocessing) > 2 or any(
            p not in ("flattened", "unflattened") for p in postprocessing
        ):
            raise ValueError(
                "Your config option postprocessing `{}` is not allowed".format(
                    postprocessing
                )
            )
        for p in postprocessing:
            if (
                glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name + "/partitionCluster_nsbm/post_{}*".format(p),
                    )
                )
                or glob.glob(
                    os.path.join(
                        clustered_graph_path,
                        design_name + "/partitionCluster_nsbm/post_{}/*".format(p),
                    )
                )
            ) and "nsbm" not in global_config["overwrite"]:
                glogger.error(
                    "nsbm cluster {} already done. Skipping. Use"
                    "`--overwrite nsbm` to overwrite".format(p)
                )
            else:
                if p == "flattened":
                    cluster_modules = clustering_algorithms.clustering_nsbm(
                        no_clk_rst_graph,
                        design_name,
                    )
                    glogger.info(
                        "nsbm found {} clusters. matching now...".format(
                            len(cluster_modules)
                        )
                    )

                    match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

                    dfs = export_single_run(
                        match,
                        graph,
                        cluster_modules,
                        modules_dict,
                        design_name,
                        "nsbm/post_flattened/cluster_{c}",
                        None,
                    )
                    store_clusters(clustered_graph_path, design_name, ".pq", dfs)
                else:
                    cluster_modules_levels = (
                        clustering_algorithms.clustering_nsbm_unflattened(
                            no_clk_rst_graph,
                            design_name,
                        )
                    )
                    for i, level in enumerate(cluster_modules_levels):
                        glogger.info(
                            "nsbm found {} clusters. matching now...".format(len(level))
                        )

                        match = get_match2(level, module_dict, GLOBAL_PARSER.threshold)

                        dfs = export_single_run(
                            match,
                            graph,
                            level,
                            modules_dict,
                            design_name,
                            "nsbm/post_unflattened_level_{p}/cluster_{c}",
                            i,
                        )
                        store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "io-bwn-rust" in global_config["task"]:
        #####################################################
        # for walkscan
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_io_bwn/*"
                )
            )
            and "io-bwn-rust" not in global_config["overwrite"]
        ):
            glogger.error(
                "IO-betweenness cluster already done. Skipping. Use"
                "`--overwrite io-bwn-rust` to overwrite"
            )
        else:
            cluster_modules = clustering_algorithms.clustering_iobwn_rust(
                no_clk_rst_graph,
                GLOBAL_PARSER.min_comms,
                GLOBAL_PARSER.max_comms,
                GLOBAL_PARSER.max_tries,
                name=design_name,
            )

            glogger.info(
                "io_bwn_rust found {} clusters. matching now...".format(
                    len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "io_bwn/cluster_{c}",
                None,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)

    if "io-bwn" in global_config["task"]:
        #####################################################
        # for walkscan
        if (
            glob.glob(
                os.path.join(
                    clustered_graph_path, design_name + "/partitionCluster_io_bwn/*"
                )
            )
            and "io-bwn" not in global_config["overwrite"]
        ):
            glogger.error(
                "IO-betweenness cluster already done. Skipping. Use"
                "`--overwrite io-bwn` to overwrite"
            )
        else:
            cluster_modules = clustering_algorithms.clustering_iobwn_gt(
                no_clk_rst_graph,
                GLOBAL_PARSER.min_comms,
                GLOBAL_PARSER.max_comms,
                GLOBAL_PARSER.max_tries,
                name=design_name,
            )

            glogger.info(
                "io_bwn_rust found {} clusters. matching now...".format(
                    len(cluster_modules)
                )
            )

            match = get_match2(cluster_modules, module_dict, GLOBAL_PARSER.threshold)

            dfs = export_single_run(
                match,
                graph,
                cluster_modules,
                modules_dict,
                design_name,
                "io_bwn/cluster_{c}",
                None,
            )
            store_clusters(clustered_graph_path, design_name, ".pq", dfs)
    sys.stdout.flush()
