#!usr/bin/ipython3
"""
File contains set of clustering algorithms
"""

import logging

# imports
import os
import pickle
import subprocess
import sys
from pprint import pprint
import math

import numpy as np
from scipy import sparse

import networkx as nx
import pyintergraph

import re_verilog2features.clustering.clustering_cmty as cmty
from networkx.algorithms.centrality import edge_betweenness_centrality_subset
from networkx.exception import NetworkXError
from sklearn.preprocessing import normalize

# own imports
from .clustering_walkscan import WalkSCAN
from re_verilog2features.globalArgParse import GLOBAL_PARSER
from re_verilog2features.graph_algo_func import nx2igraph

glogger = logging.getLogger(__name__)

np.set_printoptions(threshold=sys.maxsize)
np.set_printoptions(suppress=True)


def read_string(filename):
    """!
    Generic function to read string from file

    @param [in] filename as string of name of file to be read
    """
    with open(filename, "r+") as handle:
        read = handle.read()

    return read


def clustering_leiden_mod(graph, name, n_iterations=2):
    """
    https://github.com/vtraag/leidenalg
    """

    import leidenalg as la

    ig_graph = nx2igraph(graph)

    glogger.info("Starting to cluster nodes in {}. Method: leiden-mod".format(name))
    partition = la.find_partition(ig_graph, la.ModularityVertexPartition, n_iterations=n_iterations)
    clusters = list(partition)
    clusters_named = [
        frozenset(ig_graph.vs[i]["name"] for i in cluster) for cluster in clusters
    ]

    return clusters_named


def clustering_leiden_CPM(graph, name, resolution_parameter=0.05):
    """
    https://github.com/vtraag/leidenalg
    """

    import leidenalg as la

    ig_graph = nx2igraph(graph)

    glogger.info(
        "Starting to cluster nodes in {}. Method: leiden-cpm, r={}".format(
            name, resolution_parameter
        )
    )
    partition = la.find_partition(
        ig_graph, la.CPMVertexPartition, resolution_parameter=resolution_parameter
    )
    clusters = list(partition)
    clusters_named = [
        frozenset(ig_graph.vs[i]["name"] for i in cluster) for cluster in clusters
    ]

    return clusters_named


def clustering_nsbm_unflattened(graph, name):
    glogger.info("Starting to cluster nodes in {}. Method: nsbm_unflattened".format(name))
    return clustering_nsbm_inner(graph)


def clustering_nsbm(graph, name):
    glogger.info("Starting to cluster nodes in {}. Method: nsbm".format(name))
    unflat = clustering_nsbm_inner(graph)

    flattened = [cluster for level in unflat for cluster in level]
    return flattened


def clustering_nsbm_inner(graph):
    # late import, so that it only happens if nsbm is actually used
    import graph_tool as gt

    gt.openmp_set_num_threads(GLOBAL_PARSER.gt_cores)
    gt_graph = pyintergraph.nx2gt(graph, labelname="node_name")
    state2 = gt.inference.minimize_nested_blockmodel_dl(gt_graph)
    levels = state2.get_levels()

    all_clusters = []
    for level in range(len(levels)):
        clusters = {}
        for node in gt_graph.vertices():
            r = levels[0].get_blocks()[node]
            for _ in range(level - 1):
                r = levels[0].get_blocks()[r]
            clusters.setdefault(r, set()).add(gt_graph.vp.node_name[node])
        all_clusters.append(clusters)

    unflattened = [ [cluster for cluster in level.values()] for level in all_clusters]
    return unflattened


def clustering_iobwn_gt(
    graph, min_comms, max_comms, max_tries, name="default", use_true_io=False
):
    import graph_tool.centrality
    import graph_tool.topology
    graph_tool.openmp_set_num_threads(GLOBAL_PARSER.gt_cores)
    glogger.info(
        "Starting to cluster nodes in {}. Method: io_bwn_gt; min_comms={}, max_comms={}, max_tries={}".format(
            name, min_comms, max_comms, max_tries
        )
    )
    if use_true_io:
        inputs = [
            node
            for node in graph
            if node.startswith("INPUT")
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in graph if node.startswith("OUTPUT")]
    else:
        inputs = [
            node
            for node in graph
            if graph.in_degree(node) == 0
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in graph if graph.out_degree(node) == 0]
    clock = [
        node
        for node in graph
        if node.startswith("INPUT")
        and (node.lower().find("clk") >= 0 or node.lower().find("rst") >= 0)
    ]

    comp = iobwn_gt(graph, inputs, outputs, clock, max_tries)
    comms = next(comp)
    while len(comms) < min_comms:
        try:
            comms = next(comp)
        except StopIteration:
            glogger.info("Clustering exhausted before any cluster appeared.")
            return []
    limited = set([frozenset(comm) for comm in comms])
    while len(comms) <= max_comms:
        try:
            limited.update([frozenset(comm) for comm in comms])
            comms = next(comp)
        except StopIteration:
            glogger.info(
                "Clustering exhausted before {} clusters appeared.".format(max_comms)
            )
            break
    return list(limited)


def iobwn_gt(G, inputs, outputs, clock, max_tries):
    """Finds communities in a graph using the Girvan–Newman method.

    Parameters
    ----------
    G : NetworkX graph

    most_valuable_edge : function
        Function that takes a graph as input and outputs an edge. The
        edge returned by this function will be recomputed and removed at
        each iteration of the algorithm.

        If not specified, the edge with the highest
        :func:`networkx.edge_betweenness_centrality` will be used.

    Returns
    -------
    iterator
        Iterator over tuples of sets of nodes in `G`. Each set of node
        is a community, each tuple is a sequence of communities at a
        particular level of the algorithm.

    Examples
    --------
    To get the first pair of communities::

        >>> G = nx.path_graph(10)
        >>> comp = girvan_newman(G)
        >>> tuple(sorted(c) for c in next(comp))
        ([0, 1, 2, 3, 4], [5, 6, 7, 8, 9])

    To get only the first *k* tuples of communities, use
    :func:`itertools.islice`::

        >>> import itertools
        >>> G = nx.path_graph(8)
        >>> k = 2
        >>> comp = girvan_newman(G)
        >>> for communities in itertools.islice(comp, k):
        ...     print(tuple(sorted(c) for c in communities)) # doctest: +SKIP
        ...
        ([0, 1, 2, 3], [4, 5, 6, 7])
        ([0, 1], [2, 3], [4, 5, 6, 7])

    To stop getting tuples of communities once the number of communities
    is greater than *k*, use :func:`itertools.takewhile`::

        >>> import itertools
        >>> G = nx.path_graph(8)
        >>> k = 4
        >>> comp = girvan_newman(G)
        >>> limited = itertools.takewhile(lambda c: len(c) <= k, comp)
        >>> for communities in limited:
        ...     print(tuple(sorted(c) for c in communities)) # doctest: +SKIP
        ...
        ([0, 1, 2, 3], [4, 5, 6, 7])
        ([0, 1], [2, 3], [4, 5, 6, 7])
        ([0, 1], [2, 3], [4, 5], [6, 7])

    To just choose an edge to remove based on the weight::

        >>> from operator import itemgetter
        >>> G = nx.path_graph(10)
        >>> edges = G.edges()
        >>> nx.set_edge_attributes(G, {(u, v): v for u, v in edges}, 'weight')
        >>> def heaviest(G):
        ...     u, v, w = max(G.edges(data='weight'), key=itemgetter(2))
        ...     return (u, v)
        ...
        >>> comp = girvan_newman(G, most_valuable_edge=heaviest)
        >>> tuple(sorted(c) for c in next(comp))
        ([0, 1, 2, 3, 4, 5, 6, 7, 8], [9])

    To utilize edge weights when choosing an edge with, for example, the
    highest betweenness centrality::

        >>> from networkx import edge_betweenness_centrality as betweenness
        >>> def most_central_edge(G):
        ...     centrality = betweenness(G, weight='weight')
        ...     return max(centrality, key=centrality.get)
        ...
        >>> G = nx.path_graph(10)
        >>> comp = girvan_newman(G, most_valuable_edge=most_central_edge)
        >>> tuple(sorted(c) for c in next(comp))
        ([0, 1, 2, 3, 4], [5, 6, 7, 8, 9])

    To specify a different ranking algorithm for edges, use the
    `most_valuable_edge` keyword argument::

        >>> from networkx import edge_betweenness_centrality
        >>> from random import random
        >>> def most_central_edge(G):
        ...     centrality = edge_betweenness_centrality(G)
        ...     max_cent = max(centrality.values())
        ...     # Scale the centrality values so they are between 0 and 1,
        ...     # and add some random noise.
        ...     centrality = {e: c / max_cent for e, c in centrality.items()}
        ...     # Add some random noise.
        ...     centrality = {e: c + random() for e, c in centrality.items()}
        ...     return max(centrality, key=centrality.get)
        ...
        >>> G = nx.path_graph(10)
        >>> comp = girvan_newman(G, most_valuable_edge=most_central_edge)

    Notes
    -----
    The Girvan–Newman algorithm detects communities by progressively
    removing edges from the original graph. The algorithm removes the
    "most valuable" edge, traditionally the edge with the highest
    betweenness centrality, at each step. As the graph breaks down into
    pieces, the tightly knit community structure is exposed and the
    result can be depicted as a dendrogram.

    """
    import graph_tool.centrality
    import graph_tool.topology

    # If the graph is already empty, simply return its connected
    # components.
    if G.number_of_edges() == 0:
        yield tuple(nx.connected_components(G))
        return
    # If no function is provided for computing the most valuable edge,
    # use the edge betweenness centrality.

    def most_valuable_edge(G):
        """Returns the edge with the highest io betweenness centrality
            in the graph `G`.

            """
        inputs = [
            node
            for node in G.vertices()
            if node.in_degree() == 0
            and G.vp.node_name[node].lower().find("clk") < 0
            and G.vp.node_name[node].lower().find("rst") < 0
        ]
        # outputs = [node for node in G.vertices() if node.out_degree() == 0]
        _, eb = graph_tool.centrality.betweenness(G, pivots=inputs)
        maximum_e = None
        maximum_eb = -math.inf
        for e in G.edges():
            if eb[e] > maximum_eb:
                maximum_e = e
                maximum_eb = eb[e]
        return maximum_e

    # The copy of G here must include the edge weight data.
    g = G.copy()
    g_u = g.to_undirected()
    g.remove_nodes_from(clock)
    g_u.remove_nodes_from(clock)
    # Self-loops must be removed because their removal has no effect on
    # the connected components of the graph.
    g.remove_edges_from(nx.selfloop_edges(g))
    g_u.remove_edges_from(nx.selfloop_edges(g_u))
    gt_graph = pyintergraph.nx2gt(g, labelname="node_name")
    gt_graph_u = pyintergraph.nx2gt(g_u, labelname="node_name")

    while gt_graph.num_edges() > 0:
        yield gt_filter_most_valuable_edge(
            gt_graph, gt_graph_u, most_valuable_edge, inputs, outputs, max_tries
        )


def gt_filter_most_valuable_edge(
    G, G_u, most_valuable_edge, inputs, outputs, max_tries
):
    """Returns the connected components of the graph that results from
    repeatedly removing the most "valuable" edge in the graph.

    `G` must be a non-empty graph. This function modifies the graph `G`
    in-place; that is, it removes edges on the graph `G`.

    `most_valuable_edge` is a function that takes the graph `G` as input
    (or a subgraph with one or more edges of `G` removed) and returns an
    edge. That edge will be removed and this process will be repeated
    until the number of connected components in the graph increases.

    """
    import graph_tool.centrality
    import graph_tool.topology

    io_filter = G.new_vertex_property("bool", val=True)
    for i in inputs:
        io_filter[graph_tool.util.find_vertex(G, G.vp.node_name, i)[0]] = False
    for i in outputs:
        io_filter[graph_tool.util.find_vertex(G, G.vp.node_name, i)[0]] = False
    G.set_vertex_filter(io_filter)
    _, hist = graph_tool.topology.label_components(G, directed=False)
    original_num_components = hist.size
    G.set_vertex_filter(None)
    num_new_components = original_num_components
    counter = 0
    edge_f = G.new_edge_property("bool", val=True)
    while num_new_components <= original_num_components:
        if counter >= max_tries:
            glogger.info("Max tries exhausted")
            raise StopIteration
        edge = most_valuable_edge(G)
        if edge is None:
            glogger.info("No edges to remove")
            break
        edge_f[edge] = False
        G.set_edge_filter(edge_f)
        G.set_vertex_filter(io_filter)
        components_p, hist = graph_tool.topology.label_components(G, directed=False)
        num_new_components = hist.size
        G.set_vertex_filter(None)
        counter += 1
    new_components = []
    for component in range(num_new_components):
        component_list = [
            G.vp.node_name[node]
            for node in G.vertices()
            if components_p[node] == component
        ]
        new_components.append(component_list)
    return new_components


##############################################################
# Rust version of io betweeenness clustering
##############################################################


def clustering_iobwn_rust(
    graph, min_comms, max_comms, max_tries, name="default", use_true_io=False
):
    glogger.info(
        "Starting to cluster nodes in {}. "
        "Method: io_bwn_rust; min_comms={}, max_comms={}, max_tries={}".format(
            name, min_comms, max_comms, max_tries
        )
    )

    in_file = os.path.join("/var/tmp/", name + ".edge")
    ins_file = os.path.join("/var/tmp/", name + ".inputs")
    outs_file = os.path.join("/var/tmp/", name + ".outputs")
    clocks_file = os.path.join("/var/tmp/", name + ".clocks")
    out_file = os.path.join("/var/tmp/", name + ".out")

    nx.write_edgelist(graph, in_file, comments=None, data=False)
    if use_true_io:
        inputs = [
            node
            for node in graph
            if node.startswith("INPUT")
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in graph if node.startswith("OUTPUT")]
    else:
        inputs = [
            node
            for node in graph
            if graph.in_degree(node) == 0
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in graph if graph.out_degree(node) == 0]
    clocks = [
        node
        for node in graph
        if node.startswith("INPUT")
        and (node.lower().find("clk") >= 0 or node.lower().find("rst") >= 0)
    ]
    write_list(inputs, ins_file)
    write_list(outputs, outs_file)
    write_list(clocks, clocks_file)
    try:
        run_iobwn_rust(
            in_file,
            ins_file,
            outs_file,
            clocks_file,
            out_file,
            min_comms,
            max_comms,
            max_tries,
        )
    except subprocess.CalledProcessError as e:
        glogger.exception(
            "io_bwn failed during clustering with a non-zero exit status.", exc_info=e,
        )
        os.remove(in_file)
        os.remove(ins_file)
        os.remove(outs_file)
        os.remove(clocks_file)
        try:
            os.remove(out_file)
        except FileNotFoundError:
            pass
        return []
    all_clusters = read_iobwn_rust(out_file)

    os.remove(in_file)
    os.remove(ins_file)
    os.remove(outs_file)
    os.remove(clocks_file)
    os.remove(out_file)

    glogger.info("Found " + str(len(all_clusters)) + " clusters in graph")

    return list(all_clusters)


def write_list(list, list_file):
    with open(list_file, "w") as f:
        for item in list:
            f.write("{}".format(item) + "\n")


def run_iobwn_rust(
    in_file,
    ins_file,
    outs_file,
    clocks_file,
    out_file,
    min_comms,
    max_comms,
    max_tries=100,
):

    output = subprocess.run(
        [
            "io-bwn-rust",
            in_file,
            ins_file,
            outs_file,
            clocks_file,
            out_file,
            "{:d}".format(min_comms),
            "{:d}".format(max_comms),
            "{:d}".format(max_tries),
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        check=True,
    )

    outs = output.stdout
    glogger.debug(outs)

    return


def read_iobwn_rust(filename):
    """Read io_bwn_rust output file
    """

    string = read_string(filename)
    string = string.split("\n")
    all_clusters = set()
    for line in string:
        cluster = []
        nodes = line.split("\t")
        for node in nodes:
            cluster.append(node)
        cluster = frozenset(cluster)
        all_clusters.add(cluster)
    return all_clusters


def read_iobwn_rust_old(filename):
    """Read io_bwn_rust output file by level
    """

    string = read_string(filename)
    string = string.split("\n")
    all_clusters = set()
    levels = {}
    cur_level = -1
    for line in string:
        if line.startswith("Level"):
            cur_level = int(line.split("Level ")[1][:-1])
            levels[cur_level] = set()
        elif not cur_level == -1:
            cluster = []
            nodes = line.split("\t")
            for node in nodes:
                cluster.append(node)
            cluster = frozenset(cluster)
            levels[cur_level].add(cluster)
    for _, clusters in levels.items():
        all_clusters.update(clusters)
    return all_clusters, levels


##############################################################
# CUSTOM GIRVAN NEWMAN ignoring IO when clustering
##############################################################


def clustering_girvan_newman_io(
    graph, min_comms, max_comms, max_tries, use_true_io=False
):
    if use_true_io:
        inputs = [
            node
            for node in graph
            if node.startswith("INPUT")
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in graph if node.startswith("OUTPUT")]
    else:
        inputs = [
            node
            for node in graph
            if graph.in_degree(node) == 0
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in graph if graph.out_degree(node) == 0]
    clock = [
        node
        for node in graph
        if node.startswith("INPUT")
        and (node.lower().find("clk") >= 0 or node.lower().find("rst") >= 0)
    ]

    comp = girvan_newman_io(graph, inputs, outputs, clock, max_tries)
    comms = next(comp)
    while len(comms) < min_comms:
        try:
            comms = next(comp)
        except StopIteration:
            glogger.info("Clustering exhausted before any cluster appeared.")
            return []
    limited = set([frozenset(comm) for comm in comms])
    while len(comms) <= max_comms:
        try:
            limited.update([frozenset(comm) for comm in comms])
            comms = next(comp)
        except StopIteration:
            glogger.info("Clustering exhausted before 50 clusters appeared.")
            break
    return list(limited)


def girvan_newman_io(G, inputs, outputs, clock, max_tries):
    """Finds communities in a graph using the Girvan–Newman method.

    Parameters
    ----------
    G : NetworkX graph

    most_valuable_edge : function
        Function that takes a graph as input and outputs an edge. The
        edge returned by this function will be recomputed and removed at
        each iteration of the algorithm.

        If not specified, the edge with the highest
        :func:`networkx.edge_betweenness_centrality` will be used.

    Returns
    -------
    iterator
        Iterator over tuples of sets of nodes in `G`. Each set of node
        is a community, each tuple is a sequence of communities at a
        particular level of the algorithm.

    Examples
    --------
    To get the first pair of communities::

        >>> G = nx.path_graph(10)
        >>> comp = girvan_newman(G)
        >>> tuple(sorted(c) for c in next(comp))
        ([0, 1, 2, 3, 4], [5, 6, 7, 8, 9])

    To get only the first *k* tuples of communities, use
    :func:`itertools.islice`::

        >>> import itertools
        >>> G = nx.path_graph(8)
        >>> k = 2
        >>> comp = girvan_newman(G)
        >>> for communities in itertools.islice(comp, k):
        ...     print(tuple(sorted(c) for c in communities)) # doctest: +SKIP
        ...
        ([0, 1, 2, 3], [4, 5, 6, 7])
        ([0, 1], [2, 3], [4, 5, 6, 7])

    To stop getting tuples of communities once the number of communities
    is greater than *k*, use :func:`itertools.takewhile`::

        >>> import itertools
        >>> G = nx.path_graph(8)
        >>> k = 4
        >>> comp = girvan_newman(G)
        >>> limited = itertools.takewhile(lambda c: len(c) <= k, comp)
        >>> for communities in limited:
        ...     print(tuple(sorted(c) for c in communities)) # doctest: +SKIP
        ...
        ([0, 1, 2, 3], [4, 5, 6, 7])
        ([0, 1], [2, 3], [4, 5, 6, 7])
        ([0, 1], [2, 3], [4, 5], [6, 7])

    To just choose an edge to remove based on the weight::

        >>> from operator import itemgetter
        >>> G = nx.path_graph(10)
        >>> edges = G.edges()
        >>> nx.set_edge_attributes(G, {(u, v): v for u, v in edges}, 'weight')
        >>> def heaviest(G):
        ...     u, v, w = max(G.edges(data='weight'), key=itemgetter(2))
        ...     return (u, v)
        ...
        >>> comp = girvan_newman(G, most_valuable_edge=heaviest)
        >>> tuple(sorted(c) for c in next(comp))
        ([0, 1, 2, 3, 4, 5, 6, 7, 8], [9])

    To utilize edge weights when choosing an edge with, for example, the
    highest betweenness centrality::

        >>> from networkx import edge_betweenness_centrality as betweenness
        >>> def most_central_edge(G):
        ...     centrality = betweenness(G, weight='weight')
        ...     return max(centrality, key=centrality.get)
        ...
        >>> G = nx.path_graph(10)
        >>> comp = girvan_newman(G, most_valuable_edge=most_central_edge)
        >>> tuple(sorted(c) for c in next(comp))
        ([0, 1, 2, 3, 4], [5, 6, 7, 8, 9])

    To specify a different ranking algorithm for edges, use the
    `most_valuable_edge` keyword argument::

        >>> from networkx import edge_betweenness_centrality
        >>> from random import random
        >>> def most_central_edge(G):
        ...     centrality = edge_betweenness_centrality(G)
        ...     max_cent = max(centrality.values())
        ...     # Scale the centrality values so they are between 0 and 1,
        ...     # and add some random noise.
        ...     centrality = {e: c / max_cent for e, c in centrality.items()}
        ...     # Add some random noise.
        ...     centrality = {e: c + random() for e, c in centrality.items()}
        ...     return max(centrality, key=centrality.get)
        ...
        >>> G = nx.path_graph(10)
        >>> comp = girvan_newman(G, most_valuable_edge=most_central_edge)

    Notes
    -----
    The Girvan–Newman algorithm detects communities by progressively
    removing edges from the original graph. The algorithm removes the
    "most valuable" edge, traditionally the edge with the highest
    betweenness centrality, at each step. As the graph breaks down into
    pieces, the tightly knit community structure is exposed and the
    result can be depicted as a dendrogram.

    """
    # If the graph is already empty, simply return its connected
    # components.
    if G.number_of_edges() == 0:
        yield tuple(nx.connected_components(G))
        return

    # If no function is provided for computing the most valuable edge,
    # use the edge betweenness centrality.
    def most_valuable_edge(G, G_u):
        """Returns the edge with the highest io betweenness centrality
            in the graph `G`.

            """
        inputs = [
            node
            for node in G
            if G.in_degree(node) == 0
            and node.lower().find("clk") < 0
            and node.lower().find("rst") < 0
        ]
        outputs = [node for node in G if G.out_degree(node) == 0]
        centrality = edge_betweenness_centrality_subset(G_u, inputs, outputs)
        return max(centrality, key=centrality.get)

    # The copy of G here must include the edge weight data.
    g = G.copy()
    g_u = g.to_undirected()
    g.remove_nodes_from(clock)
    g_u.remove_nodes_from(clock)
    # Self-loops must be removed because their removal has no effect on
    # the connected components of the graph.
    g.remove_edges_from(nx.selfloop_edges(g))
    g_u.remove_edges_from(nx.selfloop_edges(g_u))

    while g.number_of_edges() > 0:
        yield _without_most_central_edges_io(
            g, g_u, most_valuable_edge, inputs, outputs, max_tries
        )


def _without_most_central_edges_io(
    G, G_u, most_valuable_edge, inputs, outputs, max_tries
):
    """Returns the connected components of the graph that results from
    repeatedly removing the most "valuable" edge in the graph.

    `G` must be a non-empty graph. This function modifies the graph `G`
    in-place; that is, it removes edges on the graph `G`.

    `most_valuable_edge` is a function that takes the graph `G` as input
    (or a subgraph with one or more edges of `G` removed) and returns an
    edge. That edge will be removed and this process will be repeated
    until the number of connected components in the graph increases.

    """
    _add_temp_connection_of_io(G_u, inputs, outputs)
    original_num_components = nx.number_connected_components(G_u)
    _remove_temp_connection_of_io(G_u)
    num_new_components = original_num_components
    counter = 0
    while num_new_components <= original_num_components:
        if counter >= max_tries:
            raise StopIteration
        edge = most_valuable_edge(G, G_u)
        try:
            G.remove_edge(*edge)
        except NetworkXError:
            G.remove_edge(*reversed(edge))
        G_u.remove_edge(*edge)
        _add_temp_connection_of_io(G_u, inputs, outputs)
        new_components = tuple(nx.connected_components(G_u))
        num_new_components = len(new_components)
        _remove_temp_connection_of_io(G_u)
        counter += 1
    return new_components


def _add_temp_connection_of_io(G, inputs, outputs):
    inputs_r = inputs.copy()
    inputs_r.append(inputs_r.pop())
    outputs_r = outputs.copy()
    outputs_r.append(outputs_r.pop())

    G.add_edges_from(zip(inputs, inputs_r), temp=True)
    G.add_edges_from(zip(outputs, outputs_r), temp=True)


def _remove_temp_connection_of_io(G):
    remove_list = [(b, e) for b, e, t in G.edges(data="temp", default=False) if t]
    G.remove_edges_from(remove_list)


##############################################################
# WALKSCAN Clustering
##############################################################


def clustering_walkscan_py(G, nb_steps=2, epsilon=0.1, min_pts=3, name=None):
    numbered_graph = G.copy()
    rename_dict_there = {}
    rename_dict_back = {}
    for i, node in enumerate(numbered_graph):
        rename_dict_there[node] = str(i)
        rename_dict_back[str(i)] = node
    nx.relabel_nodes(numbered_graph, rename_dict_there, copy=False)
    ws = WalkSCAN(nb_steps=nb_steps, eps=epsilon, min_samples=min_pts)
    init_vector = {node: 1 / len(G) for node in numbered_graph}
    ws.detect_communities(numbered_graph, init_vector)
    return ws.communities_


def clustering_walkscan_c(G, nb_steps=2, epsilon=0.1, min_pts=3, name="default"):
    numbered_graph = G.copy()
    rename_dict_there = {}
    rename_dict_back = {}
    for i, node in enumerate(numbered_graph):
        rename_dict_there[node] = str(i)
        rename_dict_back[str(i)] = node
    nx.relabel_nodes(numbered_graph, rename_dict_there, copy=False)
    glogger.info(
        "Starting to cluster nodes in graph. Method: walkscan; "
        "nb_steps={}, epsilon={}, min_pts={}".format(
            nb_steps, epsilon, min_pts
        )
    )

    in_file = os.path.join("/var/tmp/", name + ".edge")
    seed_file = os.path.join("/var/tmp/", name + ".seed")
    out_file = os.path.join("/var/tmp/", name + ".out")
    nx.write_edgelist(numbered_graph, in_file, comments=None, data=False)
    write_seed(numbered_graph, seed_file)

    run_walkscan(in_file, seed_file, out_file, nb_steps, epsilon, min_pts)
    clusters = read_walkscan(out_file)
    clusters_translated = []
    for cluster in clusters:
        clusters_translated.append([rename_dict_back[node] for node in cluster])

    # os.remove(in_file)
    # os.remove(seed_file)
    # os.remove(out_file)

    glogger.info("Found " + str(len(clusters)) + " clusters in graph")

    return clusters


def write_seed(G, seed_file):
    with open(seed_file, "w") as f:
        nodes = [str(node) for node in sorted(G)]
        f.write(" ".join(nodes) + "\n")


def run_walkscan(in_file, seed_file, out_file, nb_steps=2, epsilon=0.1, min_pts=3):

    output = subprocess.Popen(
        [
            "walkscan",
            "-a",
            "2",
            "-i",
            in_file,
            "-o",
            out_file,
            "-s",
            seed_file,
            "-t",
            "{:d}".format(nb_steps),
            "--epsilon",
            "{:f}".format(epsilon),
            "--min-elems",
            "{:d}".format(min_pts),
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    _, errs = output.communicate("")
    if errs:
        pprint(str(errs))
        # ~ input("ok?")

    return


def read_walkscan(filename):
    """!
    """

    file_content = read_string(filename)
    lines = file_content.split("\n")
    clusters = []
    for s in lines:
        s = s.split(" ")
        cluster = []
        for x in s:
            # if x.startswith("INPUT_\\") or x.startswith("OUTPUT_\\"):
            # 	x = x + " "
            cluster.append(x)
        clusters.append(cluster)
    return clusters[:-1]


########################################################################
# mcl clustering using mcl tool
########################################################################


def clustering_mcl(G, I, PreI, name, t="1"):
    """!
    """

    glogger.info("Starting to cluster nodes in graph. Method: mcl; I={}".format(I))

    in_file = name + "myfile.edge"
    out_file = name + "out_file.out"
    U = G.to_undirected()
    nx.write_edgelist(U, in_file)

    run_mcl(in_file, out_file, I, PreI, t=t)
    clusters = read_output(out_file)

    os.remove(in_file)
    os.remove(out_file)

    glogger.info("Found " + str(len(clusters)) + " clusters in graph")

    return clusters


def run_mcl(in_file, out_file, I, PreI, t="1"):

    output = subprocess.Popen(
        ["mcl", in_file, "--abc", "-te", t, "-I", I, "-pi", PreI, "-o", out_file],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    outs, _ = output.communicate("")
    glogger.debug(outs.decode("utf8"))

    return


def read_output(filename):
    """!
    """

    string = read_string(filename)
    string = string.split("\n")
    clusters = []
    for s in string:
        s = s.split("\t")
        cluster = set()
        for x in s:
            # if x.startswith("INPUT_\\") or x.startswith("OUTPUT_\\"):
            # 	x = x + " "
            cluster.add(x)
        clusters.append(cluster)
    return clusters[:-1]


########################################################################
# mcl clustering using mcl algorithm (much slower, better control
# over variables
########################################################################
def cluster_mcl_manual(G, e, r):
    glogger.info("Starting to cluster nodes in graph. Method: new")

    G = G.to_undirected()
    A = nx.adjacency_matrix(G)  # A is a sparse matrix,

    A = A.todense()  # change to dense matrix
    A = np.array(A)

    # add identify matrix of size A for self loops (see method in ...)
    I = np.identity(A.shape[0])  # shape is size of array,  # noqa: E741
    A = A + I

    N = normalize(
        A, norm="l1", axis=0
    )  # x = o indicates normalisation by column, for row normalisation axis = 1

    change = np.ones(A.shape[0])
    counter = 0
    while (
        not np.array_equiv(change, np.zeros(A.shape[0])) or counter > 100
    ):  # fixme: what if convergent state is never reached?
        counter = counter + 1
        pprint(counter)
        # reset const_e and old matrix N (to calculate change)
        const_e = e
        N_old = N
        # expand
        while const_e > 1:
            N = sparse.csc_matrix(N)
            N = N.dot(N)
            const_e = const_e - 1

        N = N.todense()
        N = np.array(N)
        # inflate
        N = N ** r

        N = normalize(N, norm="l1", axis=0)

        # calculate if there is any change  - if yes, next iteration
        change = N_old - N

    # transfer back to sparse matrix
    S = sparse.csr_matrix(N)

    node_dict = {}
    for i in range(len(G.nodes())):
        node_dict[str(i)] = G.nodes()[i]

    # group nodes with numbers on same row
    cluster_list = []
    for entry in S:
        if list(entry.indices):
            cluster = []
            for index in list(entry.indices):
                cluster.append(node_dict[str(index)])
            cluster_list.append(cluster)

    glogger.info("Found " + str(len(cluster_list)) + " clusters in graph")

    return cluster_list


########################################################################
# louvain clustering using community package - requires local install
########################################################################
def clustering_louvain_undirected(graph, resolution=1., random_state=None):
    # uses louvain using community of networkx
    import community

    glogger.info("Starting to cluster nodes in graph. Method: louvain_undirected")
    undirected = graph.to_undirected()
    if random_state is None:
        parts = community.best_partition(undirected, resolution=resolution, randomize=False)  # Louvain algrithm
    else:
        parts = community.best_partition(undirected, resolution=resolution, random_state=random_state)  # Louvain algrithm
    clusters_louvain = {}
    for cell, cluster_id in parts.items():
        clusters_louvain.setdefault(cluster_id, set()).add(cell)
    return list(clusters_louvain.values())



def cluster_graph_louvain_dend(graph):
    glogger.info("Starting to cluser nodes in graph. Method: louvain_dendrite")
    unflat = cluster_graph_louvain_dend_inner(graph)

    flattened = [cluster for level in unflat for cluster in level]
    return flattened


def cluster_graph_louvain_dend_unflattened(graph):
    glogger.info("Starting to cluser nodes in graph. Method: louvain_dendrite_unflattened")
    return cluster_graph_louvain_dend_inner(graph)


def cluster_graph_louvain_dend_inner(graph):
    # uses louvain using community of networkx
    import community

    undirected = graph.to_undirected()
    parts = community.generate_dendrogram(undirected)  # Louvain algrithm

    all_clusters = []
    for i, level in enumerate(parts):
        clusters = {}
        for node, c_id in level.items():
            if i == 0:
                clusters.setdefault(c_id, set()).add(node)
            else:
                clusters.setdefault(c_id, set()).update(all_clusters[i - 1][node])
        all_clusters.append(clusters)

    unflattened = [[cluster for cluster in level.values()] for level in all_clusters]
    return unflattened


########################################################################
# Girvan Newman clustering using cmty.py file
########################################################################
def clustering_cmty(G):
    """! uses cmty as supplied by...
    """
    glogger.info("Starting to cluster nodes in graph. Method: GN")
    mapping = {}
    counter = 0
    for node in G.nodes():
        mapping[node] = counter
        counter = counter + 1

    H = nx.relabel_nodes(G, mapping)
    filename = "edgelist.txt"
    write_file(H, filename)
    cluster_list = cmty.cluster(filename)

    mapping_rev = {v: k for k, v in mapping.items()}
    cluster_list_matched = []
    for clusters in cluster_list:
        cluster_new = []
        for cluster in clusters:
            cluster_s = []
            for c_set in cluster:
                cluster_s.append(mapping_rev[c_set])
            cluster_new.append(cluster_s)
        cluster_list_matched.append(cluster_new)

    glogger.info("Found " + str(len(cluster_list)) + " seperate cluster sets in graph")

    return cluster_list_matched


def write_file(H, filename):

    nx.write_edgelist(H, filename, data=False, delimiter=",")

    return


########################################################################
# other clustering stuff
########################################################################


def find_cluster_boundaries(G, cluster_list, nodeTypes, cell_lib, word_length_min):

    cluster_bounds = {}
    for clusters in cluster_list:
        for cluster in clusters:

            if len(cluster) > 1:
                in_bound = []
                out_bound = []
                subG = G.subgraph(cluster)

                for node in subG.nodes():
                    if node.startswith("INPUT"):
                        in_bound.append(node)
                    elif node.startswith("OUTPUT"):
                        out_bound.append(node)
                    else:
                        if (
                            subG.in_degree(node)
                            is not cell_lib[nodeTypes[node]]["inputs"]
                        ):
                            in_bound.append(node)
                        if subG.out_degree(node) == 0:
                            out_bound.append(node)

                in_bound = sorted(list(set(in_bound)))
                out_bound = sorted(list(set(out_bound)))

                if len(in_bound) >= word_length_min:
                    if str(in_bound) not in cluster_bounds:
                        cluster_bounds[str(in_bound)] = [cluster]
                    else:
                        cluster_bounds[str(in_bound)].append(cluster)
                if len(out_bound) >= word_length_min:
                    if str(out_bound) not in cluster_bounds:
                        cluster_bounds[str(out_bound)] = [cluster]
                    else:
                        cluster_bounds[str(out_bound)].append(cluster)

    return cluster_bounds


def write_cluster_boundaries(filename, clusterbounds):

    return


def draw_clusters_new(G, clusters, filename="myfile"):
    colours = [
        "blue",
        "yellow",
        "green",
        "red",
        "lightorange",
        "plum",
        "crimson",
        "magenta",
        "cyan",
        "cadetblue1",
        "magenta",
        "brown",
        "skyblue",
        "darkgreen",
        "gray",
        "dodgerblue",
        "gold",
        "hotpink1",
        "indianred2",
        "maroon3",
        "plum",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "seagreen",
        "peru",
        "moccasin",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "blue",
        "aquamarine",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "crimson",
        "darkgreen",
        "darkolivegreen2",
        "darkslategray1",
        "deeppink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "maroon3",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "yellowgreen",
        "seagreen",
        "magenta",
        "peru",
        "moccasin",
        "lightpink",
        "darkslategray1",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "blue",
        "aquamarine",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "crimson",
        "cyan",
        "darkgreen",
        "darkolivegreen2",
        "darkorchid4",
        "deeppink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "cyan",
        "indianred2",
        "maroon3",
        "plum",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "moccasin",
        "lightpink",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "blueviolet",
        "darksalmon",
        "blue",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "chocolate",
        "darkorchid4",
        "crimson",
        "cyan",
        "darkgreen",
        "darkolivegreen2",
        "darkorchid4",
        "darkslategray1",
        "deeppink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "indianred2",
        "maroon3",
        "plum",
        "aquamarine",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "seagreen",
        "magenta",
        "peru",
        "moccasin",
        "lightpink",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "blue",
        "aquamarine",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "crimson",
        "cyan",
        "darkgreen",
        "darkolivegreen2",
        "darkorchid4",
        "darkslategray1",
        "deeppink",
        "deeppink",
        "lightpink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "indianred2",
        "maroon3",
        "plum",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "seagreen",
        "magenta",
        "peru",
        "moccasin",
        "lightpink",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "peru",
        "darkolivegreen2",
    ]

    cluster_dict = {}

    counter = 0
    for cluster in clusters:

        for node in cluster:
            cluster_dict[node] = colours[counter]

        counter = counter + 1

    write_new_dot(cluster_dict, filename)

    return


def draw_clusters(G, clusters, PIs=[], POs=[], filename="myfile", e=0, r=0):
    """!
    """

    glogger.info("Drawing cluster")
    # ~ "aquamarine"
    colours = [
        "blue",
        "yellow",
        "green",
        "red",
        "lightorange",
        "plum",
        "crimson",
        "magenta",
        "cyan",
        "cadetblue1",
        "magenta",
        "brown",
        "skyblue",
        "darkgreen",
        "gray",
        "dodgerblue",
        "gold",
        "hotpink1",
        "indianred2",
        "maroon3",
        "plum",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "seagreen",
        "peru",
        "moccasin",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "blue",
        "aquamarine",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "crimson",
        "darkgreen",
        "darkolivegreen2",
        "darkslategray1",
        "deeppink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "maroon3",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "yellowgreen",
        "seagreen",
        "magenta",
        "peru",
        "moccasin",
        "lightpink",
        "darkslategray1",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "blue",
        "aquamarine",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "crimson",
        "cyan",
        "darkgreen",
        "darkolivegreen2",
        "darkorchid4",
        "deeppink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "cyan",
        "indianred2",
        "maroon3",
        "plum",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "moccasin",
        "lightpink",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "blueviolet",
        "darksalmon",
        "blue",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "chocolate",
        "darkorchid4",
        "crimson",
        "cyan",
        "darkgreen",
        "darkolivegreen2",
        "darkorchid4",
        "darkslategray1",
        "deeppink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "indianred2",
        "maroon3",
        "plum",
        "aquamarine",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "seagreen",
        "magenta",
        "peru",
        "moccasin",
        "lightpink",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "blue",
        "aquamarine",
        "brown",
        "blueviolet",
        "cadetblue1",
        "chocolate",
        "crimson",
        "cyan",
        "darkgreen",
        "darkolivegreen2",
        "darkorchid4",
        "darkslategray1",
        "deeppink",
        "deeppink",
        "lightpink",
        "dodgerblue",
        "gold",
        "green",
        "hotpink1",
        "indianred2",
        "maroon3",
        "plum",
        "yellow",
        "tan1",
        "steelblue1",
        "violetred",
        "blueviolet",
        "darkgoldenrod",
        "darkorange",
        "olivedrab3",
        "palevioletred",
        "skyblue",
        "yellowgreen",
        "seagreen",
        "magenta",
        "peru",
        "moccasin",
        "lightpink",
        "cadetblue",
        "burlywood1",
        "chartreuse3",
        "darksalmon",
        "peru",
        "darkolivegreen2",
    ]

    P = nx.drawing.nx_pydot.to_pydot(G)

    # ~ #FIXME
    # ~ S = pydot.Cluster("inputs" )
    # ~ for node in PIs:
    # ~ S.add_node(pydot.Node(node))
    # ~ P.add_subgraph(S)

    # ~ S = pydot.Cluster("outputs")
    # ~ for node in POs:
    # ~ S.add_node(pydot.Node(node))
    # ~ P.add_subgraph(S)

    counter = 0
    for cluster in clusters:
        for node in cluster:
            if node.startswith("INPUT") or node.startswith("OUTPUT"):
                # ~ pprint(node)
                try:
                    n = P.get_node('"' + node + '"')[0]
                except BaseException:
                    n = P.get_node(node)[0]
            else:
                n = P.get_node(node)[0]
            n.set_style("filled")
            n.set_color(colours[counter])
        counter = counter + 1

    P.write_raw(filename + ".dot")

    glogger.info("Finished")

    return


# This is a function to merge several nodes into one in a Networkx graph


def merge_nodes(G, nodes, new_node, attr_dict=None, **attr):
    """
    Merges the selected ``nodes`` of the graph G into one ``new_node``,
    meaning that all the edges that pointed to or from one of these
    ``nodes`` will point to or from the ``new_node``.
    attr_dict and ``**attr`` are defined as in ``G.add_node``.
    """

    G.add_node(new_node, attr_dict, **attr)  # Add the 'merged' node

    for n1, n2, data in G.edges(data=True):
        # For all edges related to one of the nodes to merge,
        # make an edge going to or coming from the `new gene`.
        if n1 in nodes:
            G.add_edge(new_node, n2, data)
        elif n2 in nodes:
            G.add_edge(n1, new_node, data)

    for n in nodes:  # remove the merged nodes
        G.remove_node(n)

    return G


def write_clusters(filename, cluster_list):

    if len(cluster_list) == 1:
        clusters = cluster_list[0]
        with open(filename, "wb") as f:
            pickle.dump(clusters, f)
    else:
        counter = 0
        for clusters in cluster_list:
            with open(filename + str(counter), "wb") as f:
                pickle.dump(clusters, f)
            counter = counter + 1

    return


def read_clusters(filename):

    with open(filename, "rb") as f:
        clusters = pickle.load(f)

    return clusters


def words_vs_clusters(wordList, cluster_bounds):
    # todo!

    for word in wordList:

        for x in cluster_bounds.keys():
            pprint(word)
            pprint(literal_eval(x))

            # ~ if set(word).issubset(set(literal_eval(x)))
            # ~
        # ~
        # ~ match = [x for x in cluster_bounds.keys() if set(word).issubset(set(literal_eval(x)))]
        # ~ pprint(word)
        # ~ pprint(match)
        # ~

    return


########################################################################
# old stuff
########################################################################

# ~ def clustering_3(G):
# ~ #skitlearn
# ~
# ~ centers = [[1, 1], [-1, -1], [1, -1]]
# ~ X, labels_true = make_blobs(n_samples=300, centers=centers, cluster_std=0.5, random_state=0)
# ~ pprint(X)
# ~ nx.write_shp(G, "myfile")
# ~
# ~ input()
# ~ af = AffinityPropagation(preference=-50).fit(G)
# ~ n_clusters_ = len(cluster_centers_indices)
# ~
# ~ return


# ~ def clustering_4(G):
# ~ # pymetis
# ~
# ~ adjacency_list = [x for x in nx.generate_adjlist(G, delimiter=' ')]
# ~ adjacency_list = G.adjacency_list()
# ~ ad_matrix = nx.adjacency_matrix(G)
# ~ ad_matrix = ad_matrix.todense()
# ~ num_clusters = 8
# ~ part = pymetis.part_graph(num_clusters, adjacency=adjacency_list)
# ~ input()
# ~
# ~ return
# ~


# ~ def clustering_6(G):
# ~
# ~ X = nx.floyd_warshall(G, )
# ~ N = nx.floyd_warshall_numpy(G)
# ~ print("n found")
# ~ pprint(X)
# ~ input()
# ~ clusterid, error, nfound = kmedoids (N, nclusters=6)
# ~
# ~ pprint(clusterid)
# ~ input()
# ~
# ~ return
# ~

