import logging
import os
import networkx as nx
import warnings
import tables
import pandas as pd
from pathlib import PurePath

import tueisec_myparsing.pool_wrapper as pool_wrapper  # noqa: E402

glogger = logging.getLogger(__name__)


class ModuleDictProxy:
    def __getitem__(self, key):
        return self

    def __str__(self):
        return "UNDEFINED"

    def __repr__(self):
        return "UNDEFINED"


def store_clusters(base_graph_path, design_name, appendix, dfs):
    glogger.info("Storing into {}".format(design_name + appendix))
    overlong_filename_number = 0
    overlong_dirname_number = 0
    placeholder_len = len(f"_-_OVERL_NAME_{overlong_filename_number:010d}")
    for key_name, df in dfs:
        keyname_path = PurePath(key_name)
        keyname_dir = keyname_path.parent
        output_dir = PurePath(base_graph_path).joinpath(keyname_dir)
        output_dirname = output_dir.name
        os.makedirs(
            output_dir.parent, exist_ok=True
        )
        maxlen = os.pathconf(output_dir.parent, "PC_NAME_MAX")
        if len(output_dirname) >= maxlen:
            # dirname too long. replace with placeholder and write a helper file
            new_dirname = str(output_dirname)[:maxlen-1-placeholder_len] + f"_-_OVERL_NAME_{overlong_dirname_number:010d}"
            overlong_dirname_number += 1
            with open(os.path.join(output_dir.parent, "renameclusters.txt"), "a") as renameclusters:
                renameclusters.writelines([f"{new_dirname}\t{output_dirname}\n"])
            output_dir = output_dir.parent.joinpath(new_dirname)

        os.makedirs(
            output_dir, exist_ok=True
        )
        keyname_ext = ''.join(keyname_path.suffixes)
        keyname_name = keyname_path.name
        keyname_stem = PurePath(str(keyname_name).split(keyname_ext)[0])
        if len(keyname_name) >= maxlen:
            # filename too long. replace with placeholder and write a helper file
            new_filename = str(keyname_stem)[:maxlen-1-placeholder_len-len(keyname_ext)] + f"_-_OVERL_NAME_{overlong_filename_number:010d}"
            overlong_filename_number += 1
            with open(os.path.join(output_dir, "renamepartitions.txt"), "a") as renamepartitions:
                renamepartitions.writelines([f"{new_filename}\t{keyname_stem}"])
            keyname_name = f"{new_filename}{keyname_ext}"

        path = output_dir.joinpath(keyname_name)

        save_df_to_parquet(df, path)
        glogger.info("Finished storing into {}".format(design_name + appendix))

def save_df_to_parquet(data_frame, path):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", tables.NaturalNameWarning)
        data_frame.to_parquet(
            path,
            engine="pyarrow",
            compression="snappy",
        )


def export_partitions(
    modules_dict,
    design_name,
    graph,
    module_dict,
):
    dfs = []
    for module_name, module_info in modules_dict.items():
        design_n = (
            design_name
            + "/partitionReal_"
            + module_name
            + "_moduleName_"
            + module_info["type"]
        )
        try:
            mod = module_name
            mod_graph = graph.subgraph(module_dict[mod]).copy()
            mod_graph.remove_nodes_from(list(nx.isolates(mod_graph)))
        except BaseException:
            continue
        if not mod_graph.nodes():
            glogger.warning(
                "No connected part of graph for {} in {}".format(
                    module_name, design_name
                )
            )
            continue

        dfs.append((design_n + ".pq", nx.to_pandas_edgelist(mod_graph)))

        glogger.info("partition match created for {}".format(design_n))

    return dfs


def get_match2(cluster_modules, module_dict, threshold):
    if isinstance(module_dict, ModuleDictProxy):
        return get_match_all(cluster_modules, module_dict)
    T = threshold

    match_dict = {}

    ret = pool_wrapper.run_in_pool_iter(
        run_match2,
        range(len(cluster_modules)),
        processes=1,
        initializer=init_match2,
        initargs=(dict(enumerate(cluster_modules)), module_dict, T),
    )

    for match in ret:
        for cluster_id, real_name, j_i in match:
            add_cluster_to_match_dict(match_dict, cluster_id, real_name, j_i)

    return match_dict


def add_cluster_to_match_dict(match_dict, cluster_id, real_name, jaccard_index):
    if cluster_id is None:
        return
    try:
        match_dict[cluster_id].append(
            {"real_name": real_name, "jaccard_index": jaccard_index}
        )
    except KeyError:
        match_dict[cluster_id] = []
        match_dict[cluster_id].append(
            {"real_name": real_name, "jaccard_index": jaccard_index}
        )


def jaccard_index(len_a, len_b, len_overlap):
    return len_overlap / (len_a + len_b - len_overlap)


def init_match2(cluster_modules, module_dict, T):
    global g_cluster_modules, g_module_dict, g_T
    g_cluster_modules, g_module_dict, g_T = (cluster_modules, module_dict, T)


def run_match2(cluster_id):
    global g_cluster_modules, g_module_dict, g_T

    cluster_cells = g_cluster_modules[cluster_id]

    all_matches = []

    for real_name, real_cells in g_module_dict.items():
        len_real_cells = len(list(real_cells))
        overlap = len(real_cells & cluster_cells)
        j_i = jaccard_index(len_real_cells, len(cluster_cells), overlap)
        if j_i > g_T:
            all_matches.append((cluster_id, real_name, j_i))
        else:
            continue  # this cluster does not respect above criteria

    return all_matches


def get_match_all(cluster_modules, module_dict):

    match_dict = {}

    for cluster_id, cluster_cells in enumerate(cluster_modules):
        if isinstance(module_dict, ModuleDictProxy):
            add_cluster_to_match_dict(
                match_dict, cluster_id, "UNKNOWN", 0
            )  # the matched module is choosen arbitrarily as the first module
        else:
            add_cluster_to_match_dict(
                match_dict, cluster_id, next(iter(module_dict.items()))[0], 0
            )  # the matched module is choosen arbitrarily as the first module
        # returned from module_dict

    return match_dict


def export_single_run(
    match,
    graph,
    cluster_modules,
    modules_dict,
    design_name,
    cluster_name_format,
    params,
):
    method = cluster_name_format.split("/")[0]
    if match:
        dfs = []
        for cluster_id, cluster_info_list in match.items():
            cluster_info_max_jaccard = max(
                cluster_info_list, key=lambda x: x["jaccard_index"]
            )
            cluster_type = "{}_{:.4f}".format(
                modules_dict[cluster_info_max_jaccard["real_name"]]["type"],
                cluster_info_max_jaccard["jaccard_index"],
            )

            cluster_types = []
            for cluster_info in cluster_info_list:
                cluster_types.append(
                    (
                        str(modules_dict[cluster_info["real_name"]]["type"]),
                        cluster_info["jaccard_index"],
                    )
                )

            cluster_name = cluster_name_format.format(p=params, c=cluster_id)

            mod_graph = graph.subgraph(cluster_modules[cluster_id]).copy()
            mod_graph.remove_nodes_from(list(nx.isolates(mod_graph)))
            if not mod_graph.nodes():
                glogger.warning(
                    "No connected part of graph for {} cluster {} matching {}".format(
                        method, cluster_name, cluster_type
                    )
                )

            design_n = (
                design_name
                + "/partitionCluster_"
                + cluster_name
                + "_moduleNames_"
                + cluster_type
            )

            dfs.append(
                (
                    design_n + "/all_matched.pq",
                    pd.DataFrame.from_records(
                        cluster_types,
                        columns=["match", "jaccard_index"],
                        index="match",
                    ),
                )
            )

            dfs.append((design_n + "/adj.pq", nx.to_pandas_edgelist(mod_graph)))

            glogger.info("cluster {} match created for {}".format(method, design_n))
        return dfs
    else:
        glogger.warning("Sorry, no {} match for {}".format(method, design_name))
        return []
