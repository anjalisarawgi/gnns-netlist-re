"""
   Copyright 2008-2011, Eli Bendersky

   License: BSD

   PLYParser class and other utilites for simplifying programming parsers with PLY
"""

from tueisec_myparsing.verilog_parsing_errors import VerilogParsingError

class Coord(object):
    """ Coordinates of a syntactic element. Consists of:
            - File name
            - Line number
            - (optional) column number, for the Lexer
    """

    def __init__(self, file, line, column=None):
        self.file = file
        self.line = line
        self.column = column

    def __str__(self):
        str = "%s:%s" % (self.file, self.line)
        if self.column:
            str += ":%s" % self.column
        return str


class PLYParser(object):
    def _coord(self, lineno, column=None):
        return Coord(
            file=self.lexer.filename,
            line=lineno,
            column=column)

    def _parse_error(self, msg, coord):
        raise VerilogParsingError(coord, msg)
