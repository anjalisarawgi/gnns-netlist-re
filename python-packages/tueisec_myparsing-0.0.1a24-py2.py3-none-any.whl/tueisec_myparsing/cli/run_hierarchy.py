#!/usr/bin/env python3
"""Run hierarchy.

.. code-block::
    :caption: Synopsys:

    usage: run_hierarchy [-h] [--debug] [-l OSU035_PATH] [-L SYNTH_LOG_PATH]
                         [-D DESIGN_NAME] [-u USED_LIB] [--sia SIA]
                         [-o OUTPUT_PATH] [--overwrite]
                         [--logger {info,debug,warning,error,critical}]
                         [--parsing_loglevel_error] [--cores CORES]
                         designs [designs ...]

    Recognize modules hierarchically in flat synthesis output.

    positional arguments:
      designs               Specify the designs (*.v) to be hierarchified as
                            command line arguments. Either submit a folder name,
                            single, or multiple file names.

    optional arguments:
      -h, --help            show this help message and exit
      -l OSU035_PATH, --osu035_path OSU035_PATH
                            The file containing osu035 cell library. Default: /nas
                            /ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tec
                            h/osu035/osu035_stdcells.lib
      -L SYNTH_LOG_PATH, --synth-log-path SYNTH_LOG_PATH
                            The path where synthesis logs can be found for
                            designs. Specify this to override autodetection, which
                            may function only in a few cases. Default: depends on
                            detected library. This may contain the placeholders
                            {design} and {module}, which are substituted with the
                            design-name and the module name as found in verilog.
      -D DESIGN_NAME, --design-name DESIGN_NAME
                            The name of the design, from which the currently
                            analyzed module stems. Specify this to override
                            autodetection, which may function only in a few cases.
                            Default: uses a parsing of file path useful only for
                            Alex Hepp.
      -u USED_LIB, --used_lib USED_LIB
                            The library used for the designs. Specify this to
                            override autodetection, which may function only in a
                            few cases. The default is to recognize this from the
                            design file paths (base folder name).
      --sia SIA             Deprecated option kept for compatibility. Do not use.
      -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The folder where output files will be stored.You may
                            use {}, which is replaced with the process name.
                            Default is: outputFiles/{}/hierarchy/
      --overwrite           Overwrite existing hierarchies
      --logger {info,debug,warning,error,critical}
                            logger level. Default: info
      --parsing_loglevel_error
                            Set the parsing loglevel to error, if you want to
                            ignore warnings, such as'constant one-bit assignment'
                            etc.
      --cores CORES         Cores to use for processing. Default is to use all
                            cores.

    main:
      --debug               Enable debug output. Overrides --logger
"""

import glob
import os
from os.path import isfile
import re
from copy import deepcopy

import pandas as pd

import tueisec_myparsing.myparsing_ply as myparsing
from tueisec_myparsing.module_tree_node import ModuleTreeNode
from tueisec_myparsing.pool_wrapper import run_in_pool_with_progress
from .helpers import setup_cli

from argparse import ArgumentParser

import queue

import logging

glogger = logging.getLogger(__name__)

osu035_default = "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tech/osu035/osu035_stdcells.lib"
output_path_default = "outputFiles/{}/hierarchy/"
auto_osu035_logs = (
    "benchmark_synthesis/automated_osu035/{design}/log/synth_{module}.log"
)
osu035_logs = "component_synthesis/log/synth_{module}.log"

lib_to_log_dict = {"osu035": osu035_logs, "automated_osu035": auto_osu035_logs}

lib_to_output_dict = {"osu035": "osu035", "automated_osu035": "osu035"}

FLATTEN_PARSING_RE_LEGACY = re.compile(
    r"^Mapping (?P<module_name>[^.]+).(?P<submodule_hierarchy>\S+)(?: \(\S+\))? using (?P<name_type>\S+)\.$"
)

FLATTEN_PARSING_RE_PARAM_LEGACY = re.compile(
    r"^\$paramod\\(?P<name_type_pure>\S+)\\$"
)

FLATTEN_PARSING_RE_MODERN = re.compile(
    r"^Flattening (?P<module_type>[^.]+).(?P<submodule_name>\S+) \((?P<submodule_type>\S+)\).$"
)


def invert_dict(d):
    inverse = dict()
    for key in d:
        # Go through the list that is saved in the dict:
        for item in d[key]:
            # Check if in the inverted dict the key exists
            if item not in inverse:
                # If not create a new list
                inverse[item] = [key]
            else:
                inverse[item].append(key)
    return inverse


def get_hierarchy(design_file):
    # dict must stay here, as GLOBAL_PARSER must be available
    lib_to_path_dict = {
        "osu035": GLOBAL_PARSER.osu035_path,
        "automated_osu035": GLOBAL_PARSER.osu035_path,
    }

    if GLOBAL_PARSER.used_lib:
        used_lib = GLOBAL_PARSER.used_lib
        output_path = os.path.join(GLOBAL_PARSER.output_path.format(used_lib))
    else:
        # use "autodetection"
        used_lib = os.path.basename(os.path.dirname(design_file))
        try:
            output_path = os.path.join(
                GLOBAL_PARSER.output_path.format(lib_to_output_dict[used_lib])
            )
        except KeyError:
            glogger.error(
                "Autodetection failed for {}: used_lib detected as `{}`, "
                "which is a unknown lib.".format(
                    design_file,
                    used_lib
                )
            )
            return

    os.makedirs(output_path, exist_ok=True)

    libPath = lib_to_path_dict[used_lib]
    file_name = os.path.basename(design_file)[:-2]
    if (
        os.path.isfile(os.path.join(output_path, "hierarchy_" + file_name + ".csv"))
        and os.path.isfile(
            os.path.join(output_path, "hierarchy_modules_" + file_name + ".csv")
        )
        and not GLOBAL_PARSER.overwrite
    ):
        glogger.warning(
            "Hierarchy file for {} exists already. Skipping. Use --overwrite to overwrite".format(
                file_name
            )
        )
        return

    if GLOBAL_PARSER.parsing_loglevel_error:
        l = logging.getLogger("tueisec_myparsing")
        l.setLevel(logging.ERROR)

    if GLOBAL_PARSER.sia is not None:
        glogger.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")

    parsed_verilog = myparsing.parse_to_obj(design_file, libPath)

    # find module names
    modules = []

    module_name = parsed_verilog.module_name
    glogger.debug("Module name is {}".format(module_name))
    if GLOBAL_PARSER.design_name:
        design_name = GLOBAL_PARSER.design_name
    else:
        # use "autodetection"
        design_name = file_name.rsplit("_" + module_name, 1)[
            0
        ]  # design name is file name with underscore and module name split off at right side

    glogger.debug("Design name is {}".format(design_name))

    # find path of log file
    if GLOBAL_PARSER.synth_log_path:
        log_file_name = os.path.join(
            GLOBAL_PARSER.synth_log_path.format(design=design_name, module=module_name)
        )
    else:
        # use "autodetection"
        log_file_name = os.path.join(
            lib_to_log_dict[used_lib].format(design=design_name, module=module_name)
        )

    glogger.debug("Log file name is {}".format(log_file_name))

    # search line for "Mapping positional arguments of cell"
    # if no log file? - hierarchy
    if not isfile(log_file_name):
        glogger.error("{} doesn't have a log file".format(file_name))
        return

    all_nodes = parsed_verilog.nodes[1].copy()
    all_nodes.update(parsed_verilog.nodes[0])
    all_nodes.update(parsed_verilog.nodes[2])

    glogger.debug("parsing hierarchy...")
    tree_root = get_hierarchy_tree(
        log_file_name, design_file, file_name, parsed_verilog, all_nodes, module_name
    )

    if tree_root is None:
        return

    hierarchy = tree_root.node_hierarchy()

    modules_dict = tree_root.modules_dict()

    df_design = pd.DataFrame.from_dict(hierarchy, orient="index").T
    df_design.sort_index(axis=1, inplace=True)
    df_design.to_csv(os.path.join(output_path, "hierarchy_" + file_name + ".csv"))

    df_module = pd.DataFrame(modules_dict, index=["type"])
    df_module.sort_index(axis=1, inplace=True)
    df_module.to_csv(
        os.path.join(output_path, "hierarchy_modules_" + file_name + ".csv")
    )


def detect_version(log_file_name):
    regex = re.compile(r"^\s*Yosys (?P<version>\d\.\d+)(?:\+\d+)? .*\n$")
    version = None
    with open(log_file_name, "r+") as lfile:
        for line in lfile:
            match = regex.fullmatch(line)
            if match:
                version = match.group("version")
                break
    if version:
        return version
    else:
        raise ValueError("Log file does not contain version number")


def get_hierarchy_tree(
    log_file_name, design_file, file_name, parsed_verilog, all_nodes, module_name
):

    version = detect_version(log_file_name)
    if version == "0.8" or version == "0.7":
        tree_root = get_hierarchy_tree_legacy(
            log_file_name,
            design_file,
            file_name,
            parsed_verilog,
            all_nodes,
            module_name,
        )
    else:
        tree_root = get_hierarchy_tree_modern(
            log_file_name,
            design_file,
            file_name,
            parsed_verilog,
            all_nodes,
            module_name,
        )

    return tree_root


def get_hierarchy_tree_modern(
    log_file_name, design_file, file_name, parsed_verilog, all_nodes, module_name
):
    modules = {}
    top_module = None
    flatten_section = False
    glogger.debug("Reading logfile")
    with open(log_file_name, "r+") as lfile:
        for line in lfile:
            if line.startswith("Top module:  \\") and not top_module:
                top_module_type = line.strip().split("Top module:  \\")[1]
                top_module = ModuleTreeNode(frozenset(), "top", top_module_type)
                # modules["_*root*_"] = [top_module]
            if "Executing FLATTEN pass" in line:
                if top_module is None:
                    glogger.error(
                        f"The logfile {log_file_name} of {file_name} is malformed: I can not get the top module."
                    )
                    return None
                else:
                    flatten_section = True
            else:
                if flatten_section:
                    if line == "\n":
                        break
                    elif not line.startswith("Flattening"):
                        continue
                    else:
                        line = line.strip()
                        matches = FLATTEN_PARSING_RE_MODERN.fullmatch(line)
                        submodule = ModuleTreeNode(
                            frozenset(),
                            matches.group("submodule_name"),
                            matches.group("submodule_type"),
                        )
                        modules.setdefault(matches.group("module_type"), []).append(
                            submodule
                        )

    glogger.debug("read logfile")
    # now build a tree:
    tree_root = ModuleTreeNode(frozenset(), "tree_root", "tree_root", root=True)
    tree_root.add(top_module)
    # go deeper into the tree and add submodules
    to_visit = queue.deque([top_module])
    while to_visit:
        cur_mod = to_visit.pop()
        submodules = modules.get(cur_mod.module_type, [])
        submodule_deepcopies = []
        for submodule in submodules:
            # copy is IMPORTANT: there might be multiple instantiations of a module.
            # If we do not copy, all instantiations share the same container =>
            # Only the last instantiation is ever used.
            current_submodule_deepcopy = deepcopy(submodule)
            cur_mod.add(current_submodule_deepcopy)
            submodule_deepcopies.append(current_submodule_deepcopy)
        to_visit.extend(submodule_deepcopies)

    glogger.debug("built module tree")

    net_hierarchy_names_dict_re = tree_root.net_hierarchy_names_DFS_postorder_dict('[.\\\\_]{1,2}')

    glogger.debug("built net_dict")

    net_hierarchy_names_nodes_dict = {}

    assigned_nodes = set()

    # for all the nodes check if the incident nets are named after a module
    for net, node_list in parsed_verilog.nets.items():
        for net_hierarchy_name_re in net_hierarchy_names_dict_re:
            # if "parse_blif\\$27038" in net_hierarchy_name_re and "parse_blif$27038" in net:
            #     print(net_hierarchy_name_re, net, re.search(net_hierarchy_name_re, net))
            if re.search(net_hierarchy_name_re, net):
                unassigned = set(node_list) - assigned_nodes
                net_hierarchy_names_nodes_dict.setdefault(
                    net_hierarchy_name_re, set()
                ).update(unassigned)
                assigned_nodes.update(unassigned)

    # for those cells where the output nets have a name like a possible module
    for net, node in parsed_verilog.nets_to_nodes.items():
        for net_hierarchy_name_re in net_hierarchy_names_dict_re:
            if re.search(net_hierarchy_name_re, net):
                if node not in assigned_nodes:
                    net_hierarchy_names_nodes_dict.setdefault(
                        net_hierarchy_name_re, set()
                    ).add(node)
                    assigned_nodes.add(node)
    glogger.debug("completed net dict")

    ########################################################################
    # now for all nodes that do not belong to any module, set module as top
    unknowns = set(all_nodes.keys()) - set().union(
        *net_hierarchy_names_nodes_dict.values()
    )

    if unknowns:
        top_module.immediate_nodes = frozenset(unknowns)
    ########################################################################

    # add the other netlist nodes to their respective hierarchy_nodes
    for net_hierarchy_name_re, nodes in net_hierarchy_names_nodes_dict.items():
        net_hierarchy_names_dict_re[net_hierarchy_name_re].immediate_nodes = frozenset(nodes)

    return tree_root


def get_hierarchy_tree_legacy(
    log_file_name,
    design_file,
    file_name,
    parsed_verilog,
    all_nodes,
    module_name,
):
    modules = []
    module_types = []
    with open(log_file_name, "r+") as lfile:
        counter = False
        for line in lfile:
            if "Executing FLATTEN pass" in line:
                counter = True
            else:
                if counter:
                    if line.startswith("No more expansions possible."):
                        break
                    elif not line.startswith("Mapping"):
                        continue
                    else:
                        line = line.strip()
                        matches = FLATTEN_PARSING_RE_LEGACY.fullmatch(line)
                        name = "+".join(matches.group("submodule_hierarchy").split("."))

                        name_type_match = FLATTEN_PARSING_RE_PARAM_LEGACY.fullmatch(matches.group("name_type"))
                        if name_type_match is None:
                            name_type = matches.group("name_type")
                        else:
                            name_type = name_type_match.group("name_type_pure")

                        if ("top+" + name, name_type) not in modules:
                            modules.append(("top+" + name, name_type))
                            module_types.append(design_file + "_" + name_type)
    # pprint(modules)

    # module name is something like top+something+something+something

    module_list_for_nodenames = ["_".join(x.split("+")[1:]) for x, y in modules]
    module_list = [x for x, y in modules]

    if not modules:
        glogger.error(
            "No modules in {}, setting top to contain all nodes.".format(file_name)
        )
        node_dict = {}
    else:

        # intialise module dict
        node_dict = {}
        for module in module_list:
            node_dict[module] = []

        # ~ for those cells where the input nets have a name like a possible module
        for net, node_list in parsed_verilog.nets.items():
            for module_nodename, module in zip(module_list_for_nodenames, module_list):
                if module_nodename in net:
                    node_dict[module].extend(node_list)

                    # now check for each node if output net is a ABC-internal net. Then the nodes
                    # that are driven by this net also belong to the module
                    while node_list:
                        mod_node = node_list.pop()
                        for _, dest in all_nodes[mod_node]["dest"]:
                            if dest is None:
                                continue
                            if dest.startswith("_"):
                                node_list.extend(parsed_verilog.nets[dest])
                                node_dict[module].extend(parsed_verilog.nets[dest])

        # for those cells where the output nets have a name like a possible module
        for net, node in parsed_verilog.nets_to_nodes.items():
            for module_nodename, module in zip(module_list_for_nodenames, module_list):
                if module_nodename in net:
                    node_dict[module].append(node)

    ########################################################################
    # now for all nodes that do not belong to any module, set module as top
    unknowns = set(all_nodes.keys()) - set(
        [node for node_list in node_dict.values() for node in node_list]
    )

    if unknowns:
        node_dict["top"] = unknowns
        modules.append(("top", module_name))
    ########################################################################

    tree_root = ModuleTreeNode.from_modules(modules, node_dict)
    return tree_root


def hierarchy():

    if isinstance(GLOBAL_PARSER.designs, str):
        design_path = GLOBAL_PARSER.designs
        if design_path.endswith(".v"):
            designs = [design_path]
        else:
            designs = glob.glob(os.path.join(design_path, "*.v"))
            glogger.info("Found {} designs.".format(len(designs)))
    else:
        designs = []
        for design_path in GLOBAL_PARSER.designs:
            if design_path.endswith(".v"):
                designs.append(design_path)
            else:
                add_designs = glob.glob(os.path.join(design_path, "*.v"))
                glogger.info(
                    "Found {} designs in {}.".format(len(add_designs), design_path)
                )
                designs.extend(add_designs)
    mult = []
    for design_file in designs:
        mult.append(design_file)
        glogger.info("Working on {}".format(os.path.basename(design_file)))

    run_in_pool_with_progress(
        get_hierarchy, mult, processes=GLOBAL_PARSER.cores, abort_on_kint=False
    )
    glogger.info("Finished hierarchy for {} designs.".format(len(designs)))


def main():
    global GLOBAL_PARSER
    parser = ArgumentParser(
        description="Recognize modules hierarchically in flat synthesis output."
    )
    group = parser.add_argument_group("main")
    group.add_argument(
        "--debug", help="Enable debug output. Overrides --logger", action="store_true"
    )

    parser.add_argument(
        "-l",
        "--osu035_path",
        help="The file containing osu035 cell library. Default: " + osu035_default,
        default=osu035_default,
    )

    parser.add_argument(
        "-L",
        "--synth-log-path",
        help="The path where synthesis logs can be found for designs. Specify "
        "this to override autodetection, which may function only in a few "
        "cases. Default: depends on detected library. This may contain the "
        "placeholders {design} and {module}, which are substituted with the "
        "design-name and the module name as found in verilog.",
    )

    parser.add_argument(
        "-D",
        "--design-name",
        help="The name of the design, from which the currently analyzed module stems. Specify this to override "
        "autodetection, which may function only in a few cases. Default: uses a parsing of file path useful only for Alex Hepp.",
    )

    parser.add_argument(
        "-u",
        "--used_lib",
        help="The library used for the designs. Specify this to override "
        "autodetection, which may function only in a few cases. The default is "
        "to recognize this from the design file paths (base folder name).",
    )

    parser.add_argument(
        "--sia", help="Deprecated option kept for compatibility. Do not use.", type=bool
    )

    parser.add_argument(
        "designs",
        help="Specify the designs (*.v) to be hierarchified as command line arguments."
        " Either submit a folder name, single, or multiple file names.",
        nargs="+",
    )

    parser.add_argument(
        "-o",
        "--output_path",
        help="The folder where output files will be stored."
        "You may use {}, which is replaced with the process name. Default is: "
        + output_path_default,
        default=output_path_default,
    )

    parser.add_argument(
        "--overwrite", help="Overwrite existing hierarchies", action="store_true"
    )

    parser.add_argument(
        "--logger",
        help="logger level. Default: info",
        choices=["info", "debug", "warning", "error", "critical"],
        default="info",
    )

    parser.add_argument(
        "--parsing_loglevel_error",
        help="Set the parsing loglevel to error, if you want to ignore warnings, such as"
        "'constant one-bit assignment' etc.",
        action="store_true",
    )

    parser.add_argument(
        "--cores",
        help="Cores to use for processing. Default is to use all cores.",
        type=int,
    )

    GLOBAL_PARSER = parser.parse_args()
    if GLOBAL_PARSER.debug:
        GLOBAL_PARSER.logger = "debug"

    setup_cli(log_level=GLOBAL_PARSER.logger, additional_loggers=["tueisec_myparsing"])
    hierarchy()
