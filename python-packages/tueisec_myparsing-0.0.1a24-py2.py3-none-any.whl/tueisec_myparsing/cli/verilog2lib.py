"""
Create a mock stdlib from a verilog file. This is an interactive command asking
you details about each and every gate in the netlist. Attention, this has been
restructured and is currently untested.

.. code-block::
    :caption: Synopsys:

    usage: verilog2lib [-h] [--guessing_tech GUESSING_TECH]
      [--separator SEPARATOR] [--overwrite]
      [--logger {info,debug,warning,error,critical}]
      filepath outpath

    Create a mock stdlib from a verilog file. Cell functions will be guessed
    based on a guessing library, in which the cell names are searched

    positional arguments:
      filepath              file (*.v) to get info about.
      outpath               path for generated lib.

    optional arguments:
      -h, --help            show this help message and exit
      --guessing_tech GUESSING_TECH
                            path of a qflow tech folder (needed: the qflow
                            TECH.sh, that defines `separator` and the liberty
                            path). CAREFUL: no slash at end!
      --separator SEPARATOR
                            the separator between cell function and driving
                            strength in the cells of the verilog file.
      --overwrite
      --logger, -l {info,debug,warning,error,critical}
                            logger level. Default: info
"""

import argparse

import tueisec_myparsing.synthed_verilog_parser as svp
from tueisec_myparsing.synthed_verilog_ast import (
    ModuleDef,
    Instance,
)

from tueisec_myparsing.base_ply_parser import VerilogParsingError
from tueisec_myparsing.liberty_parsing import (
    own_parseLibertyToDataStruct,
    parse_liberty_file,
)
from .helpers import setup_cli

import os

import shlex

import re

import logging

import difflib

glogger = logging.getLogger(__name__)

parser = argparse.ArgumentParser(
    description="Create a mock stdlib from a verilog file. Cell functions "
    "will be guessed based on a guessing library, in which the cell names "
    " are searched"
)
parser.add_argument("filepath", help="file (*.v) to get info about.")

parser.add_argument("outpath", help="path for generated lib.")

parser.add_argument(
    "--guessing_tech",
    help="path of a qflow tech folder (needed: "
    "the qflow TECH.sh, that defines `separator` "
    "and the liberty path). CAREFUL: no slash at end!",
    default="/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/" "share/qflow/tech/gscl45nm",
)

parser.add_argument(
    "--separator",
    help="the separator between cell function and driving strength in the "
    "cells of the verilog file.",
    default="M",
)

parser.add_argument("--overwrite", action="store_true")

parser.add_argument(
    "--logger",
    "-l",
    help="logger level. Default: info",
    choices=["info", "debug", "warning", "error", "critical"],
    default="info",
)


def main(args=None):
    args = parser.parse_args(args=args)
    setup_cli(log_level=args.logger, additional_loggers=["tueisec_myparsing"])
    filepath = args.filepath
    if os.path.exists(args.outpath) and not args.overwrite:
        print("File {} already exists. aborting".format(args.outpath))
        exit(-1)

    try:
        ast, _ = svp.parse(filepath)
    except VerilogParsingError as e:
        glogger.error("file does not parse: '{}' due to: {}".format(filepath, e))
        return

    known_std_cells = set()

    for definition in ast.description.definitions:
        if isinstance(definition, ModuleDef):
            modinst = definition
            for item in modinst.items:
                if isinstance(item, Instance):
                    stdcell = {}
                    stdcell["module"] = item.module
                    stdcell["ports"] = set()
                    for port in item.portlist:
                        stdcell["ports"].add(port.portname)
                    stdcell["ports"] = frozenset(stdcell["ports"])
                    stdcell = frozenset((k, stdcell[k]) for k in sorted(stdcell.keys()))
                    known_std_cells.add(stdcell)

    known_types = [
        # {"type" : "AND"},
        # {"type" : "NAND"},
        # {"type" : "OR"},
        # {"type" : "NOR"},
        # {"type" : "BUF"},
        # {"type" : "XOR"},
        # {"type" : "XNOR"},
        # {"type" : "AOI"},
        # {"type" : "OAI"},
        # {"type" : "DFF"},
        # {"type" : "else"},
        {"type": "cell"},
        {"type": "FF"},
    ]

    cells_for_writing = []

    try:
        for cell in list(known_std_cells):
            tempcell = dict(cell)
            print(tempcell["module"], list(tempcell["ports"]))
            if tempcell["module"].startswith("D"):
                guess = "1"
            else:
                guess = "0"
            key = input(
                "Is this a {}? [{}]".format(
                    list(
                        "{}: {}".format(i, t["type"]) for i, t in enumerate(known_types)
                    ),
                    guess,
                )
            )
            if key == "":
                key = guess
            while True:
                try:
                    tempcell["type"] = known_types[int(key)]["type"]
                except BaseException:
                    print("Bad type, retry:")
                    key = input(
                        "Is this a {}? [{}]".format(
                            list(
                                "{}: {}".format(i, t["type"])
                                for i, t in enumerate(known_types)
                            ),
                            guess,
                        )
                    )
                else:
                    break
            print("ok, this is a {}".format(tempcell["type"]))
            newports = []
            outputs = []
            for port in sorted(list(tempcell["ports"])):
                if port.startswith("Z"):
                    guess = "output"
                elif port.startswith("CO"):
                    guess = "output"
                elif port.startswith("S"):
                    if (
                        not tempcell["module"].startswith("MUX")
                        and not tempcell["type"] == "FF"
                    ):
                        guess = "output"
                elif port.startswith("Y"):
                    guess = "output"
                elif port.startswith("Q"):
                    guess = "output"
                else:
                    guess = "input"
                yesno = input("Is {} an input or output [{}]? ".format(port, guess))
                if yesno == "":
                    yesno = guess
                if yesno == "output":
                    outputs.append({"pin": port, "io": yesno, "function": ""})
                else:
                    newports.append({"pin": port, "io": yesno, "function": ""})
            for port in outputs:
                guess = guess_port_function(tempcell, newports, port["pin"], args)
                function = input(
                    "What is {} function? [{}] ".format(port["pin"], guess)
                )
                if function == "":
                    function = guess
                newports.append(
                    {
                        "pin": port["pin"],
                        "io": "output",
                        "function": "function: {};".format(function),
                    }
                )
            tempcell["ports"] = newports
            cells_for_writing.append(tempcell)
    except KeyboardInterrupt:
        pass

    with open(args.outpath, "w") as f:
        f.write("library (generic_cells) {\n  define(drive_strength, cell, float);\n")
        for cell in cells_for_writing:
            f.write(
                "  cell ({}) {{\n"
                "    drive_strengthi: 1;\n"
                "    area: 1.0;\n\n"
                "    pg_pin(VDD) {{\n"
                "      voltage_name: VDD;\n"
                "      pg_type: primary_power;\n"
                "    }}\n\n"
                "    pg_pin(VSS) {{\n"
                "      voltage_name: VSS;\n"
                "      pg_type: primary_ground;\n"
                "    }}\n\n".format(cell["module"])
            )
            if cell["type"] == "FF":
                f.write(
                    '    ff ("IQ" , "IQN") {'
                    '      next_state: "D";'
                    '      clocked_on: "CK";'
                    '      preset: "!NS";'
                    '      clear: "!NR";'
                    "      clear_preset_var1: L;"
                    "      clear_preset_var2: L;"
                    "    }\n\n"
                )
            for port in cell["ports"]:
                f.write(
                    "    pin ({pin}) {{\n"
                    "      direction: {io}\n"
                    '      related_power_pin: "VDD";\n'
                    '      related_ground_pin: "VSS";\n'
                    "      {function}\n"
                    "    }}\n\n".format(**port)
                )
            f.write("  }\n")
        f.write("}\n")


# ugly memoization of the guessing cell lib
cell_lib = None
guessing_separator = None


def guess_port_function(cell, newports, port, args):
    global cell_lib
    global guessing_separator
    if cell_lib is None:
        techfolder = args.guessing_tech
        techfile = os.path.join(techfolder, os.path.basename(techfolder) + ".sh")
        with open(techfile) as f:
            processed = f.read().replace("set ", "")
        for line in shlex.split(processed):
            var, _, value = line.partition("=")
            if var == "libertyfile":
                lib = parse_liberty_file(os.path.join(techfolder, value), os.getcwd())
                cell_lib = own_parseLibertyToDataStruct(
                    lib, exprvar=False, space_is_and=False
                )
            if var == "separator":
                guessing_separator = value

    cname = cell["module"].rsplit(args.separator, 1)[0]

    function = ""

    if guessing_separator == "":
        print("no guessing separator - using fuzzy algorithm")
        fuzzy_matcher = difflib.SequenceMatcher(None, "", cname)
        guesses = {}
        for c in cell_lib.keys():
            fuzzy_matcher.set_seq1(c)
            guesses[c] = fuzzy_matcher.get_matching_blocks()[:-1]
        ordered_guesses = sorted(
            sorted(
                sorted(
                    [(c, m) for c, l_m in guesses.items() for m in l_m],
                    key=lambda x: x[1].size,
                    reverse=True,
                ),
                key=lambda x: x[1].a,
            ),
            key=lambda x: x[1].b,
        )
        for c, _ in ordered_guesses:
            print("guessing {} = {}".format(c, cell["module"]))
            try:
                function = optimize_function(c, port, cell, newports)
                ans = input("Found {}. Stop guessing? [y]".format(function))
                if ans in ["", "yes", "y", "Y", "j", "J"]:
                    break
            except KeyboardInterrupt:
                raise
            except KeyError:
                print("exact port does not exist")
                try:
                    function = optimize_function(c, port[0], cell, newports)
                    ans = input("Found {}. Stop guessing? [y]".format(function))
                    if ans in ["", "yes", "y", "Y", "j", "J"]:
                        break
                except KeyError:
                    print("also first letter port does not exist...")
                    continue

        return function

    second_guess = []

    for c in cell_lib.keys():
        nameguess = c.rsplit(guessing_separator, 1)[0]
        if nameguess == cname:
            print("guessing {} = {}".format(c, cell["module"]))
            try:
                function = optimize_function(c, port, cell, newports)
                ans = input("Found {}. Stop guessing? [y]".format(function))
                if ans in ["", "yes", "y", "Y", "j", "J"]:
                    second_guess = []
                    break
            except KeyboardInterrupt:
                raise
            except KeyError:
                print("exact port does not exist")
                try:
                    function = optimize_function(c, port[0], cell, newports)
                    ans = input("Found {}. Stop guessing? [y]".format(function))
                    if ans in ["", "yes", "y", "Y", "j", "J"]:
                        second_guess = []
                        break
                except KeyError:
                    print("also first letter port does not exist...")
                    continue

        elif cname.startswith(nameguess):
            second_guess.append(c)
    if function == "":
        for c in second_guess:
            print("guessing {} = {}".format(c, cell["module"]))
            try:
                function = optimize_function(c, port, cell, newports)
                ans = input("Found {}. Stop guessing? [y]".format(function))
                if ans in ["", "yes", "y", "Y", "j", "J"]:
                    break
                break
            except KeyboardInterrupt:
                raise
            except KeyError:
                print("exact port does not exist")
                try:
                    function = optimize_function(c, port[0], cell, newports)
                    ans = input("Found {}. Stop guessing? [y]".format(function))
                    if ans in ["", "yes", "y", "Y", "j", "J"]:
                        break
                    break
                except KeyError:
                    print("also first letter port does not exist...")
                    continue
    return function


def optimize_function(c, port, cell, newports):
    function = cell_lib[c][port]["function"]
    finp = get_first_input(newports)
    if finp not in function:
        print("replaceing")
        function = replace_inps_ABC(function, newports)
    return function


def get_first_input(newports):
    sports = sorted(newports, key=lambda x: x["pin"])
    for port in sports:
        if port["io"] == "input":
            return port["pin"]


regex_replace_pins = r"\b{}\b"


def replace_inps_ABC(function, ports):
    portnames = sorted(p["pin"] for p in ports if p["io"] == "input")
    portnames_iter = iter(portnames)
    cur_portname = next(portnames_iter)
    for new_name in ["A", "B", "C", "D", "E", "F", "I"]:
        new, count = re.subn(
            regex_replace_pins.format(new_name), cur_portname, function
        )
        if count == 0:
            continue
        else:
            try:
                cur_portname = next(portnames_iter)
            except StopIteration:
                function = new
                break
            function = new
    return function
