"""
Run hierarchy.

.. code-block::
    :caption: Synopsys:

    usage: hierarchy2verilog [-h] [-c CELL_LIB_PATH]
           [--logger {info,debug,warning,error,critical}]
           original_verilog hierarchy_path hierarchy_name

    Extract a module from a netlist according to design hierarchy.
    IMPORTANT: A special yosys module must be used to support "very-simple-lhs", which is used by cluster2verilog.
    Use "module load yosys/0.19-RE-fsm-vslhs" for that.

    positional arguments:
      original_verilog      original verilog netlist to be read by yosys.
      hierarchy_path        The hierarchy_....csv file
      hierarchy_name        hierarchy name to output.

    optional arguments:
      -h, --help            show this help message and exit
      -c CELL_LIB_PATH, --cell_lib_path CELL_LIB_PATH
                            The file containing the cell library. Default:
                            /nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tech/osu035/osu035_stdcells.lib
      --logger {info,debug,warning,error,critical}, -l {info,debug,warning,error,critical}
                            logger level. Default: info

"""
import argparse
import logging
import os
import re
import subprocess
import sys
from tempfile import NamedTemporaryFile

import pandas as pd

from .helpers import setup_cli


glogger = logging.getLogger(__name__)


parser = argparse.ArgumentParser(
    description="Extract a module from a netlist according to design hierarchy."
)
parser.add_argument(
    "original_verilog", help="original verilog netlist to be read by yosys."
)
parser.add_argument(
    "hierarchy_path",
    help="The hierarchy_....csv file",
)
parser.add_argument("hierarchy_name", help="hierarchy name to output.")
osu035_default = (
    "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/"
    "qflow/tech/osu035/osu035_stdcells.lib"
)
parser.add_argument(
    "-c",
    "--cell_lib_path",
    help="The file containing the cell library. Default: " + osu035_default,
    default=osu035_default,
)


parser.add_argument(
    "--logger",
    "-l",
    help="logger level. Default: info",
    choices=["info", "debug", "warning", "error", "critical"],
    default="info",
)


def main(args=None):
    args = parser.parse_args(args=args)
    setup_cli(log_level=args.logger, additional_loggers=["tueisec_myparsing"])
    original_verilog = args.original_verilog
    design_name = os.path.basename(original_verilog)[:-2]

    module_dict = pd.read_csv(
        args.hierarchy_path, dtype=str, keep_default_na=True
    ).drop(["Unnamed: 0"], axis=1)
    module_dict = module_dict.to_dict("series")
    module_dict = {k: set(v.dropna()) for k, v in module_dict.items()}
    glogger.debug("Read module csv")

    hierarchy_modules_file = "hierarchy_modules".join(
        args.hierarchy_path.rsplit("hierarchy", 1)
    )
    modules_dict = pd.read_csv(hierarchy_modules_file, index_col=0, dtype=str)
    modules_dict = modules_dict.to_dict()
    glogger.debug("Read hierarchy")
    hierarchy_name = args.hierarchy_name
    verilog_plain_id_re = re.compile(r"(([a-zA-Z_])([a-zA-Z_0-9$])*)")
    if not verilog_plain_id_re.fullmatch(hierarchy_name):
        escaped_hierarchy_name = "\\\\" + hierarchy_name + " "
    else:
        escaped_hierarchy_name = hierarchy_name
    cell_lib_path = args.cell_lib_path

    # write out csvs and partition adj list
    if not module_dict:
        glogger.critical(
            "Empty module_dict for {}. Cannot continue.".format(design_name)
        )
        return

    module_type = modules_dict[hierarchy_name]

    glogger.info(f"{hierarchy_name} is a {module_type}")

    nodes_in_module = module_dict[hierarchy_name]

    with NamedTemporaryFile("w+", encoding="utf8", suffix=".ys") as f:
        actual_name = f.name

        selection_string = " ".join(f"*/c:{node}" for node in nodes_in_module)
        print(selection_string)
        f.write(
            f"""
read_verilog {original_verilog}
read_liberty {cell_lib_path}
select {selection_string}
submod -name {escaped_hierarchy_name}
select {escaped_hierarchy_name}
write_verilog -selected -very-simple-lhs -noattr -norename {hierarchy_name}.v
        """
        )

        if (
            subprocess.run(
                ["yosys", "-s", actual_name], stdout=sys.stdout, stderr=sys.stderr
            ).returncode
            == 0
        ):
            glogger.info(
                f"Successfully extracted {hierarchy_name} into {hierarchy_name}.v"
            )
        else:
            glogger.info(
                f"Some yosys error when extracting {hierarchy_name} into "
                f"{hierarchy_name}.v. Please inspect yosys output above."
            )
