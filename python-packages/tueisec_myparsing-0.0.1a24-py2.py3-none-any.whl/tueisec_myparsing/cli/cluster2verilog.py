"""
Run hierarchy.

.. code-block::
    :caption: Synopsys:

    usage: cluster2verilog [-h] [-c CELL_LIB_PATH]
           [--logger {info,debug,warning,error,critical}]
           original_verilog cluster_path output_file

    Extract a module from a netlist according to a cluster.
    IMPORTANT: A special yosys module must be used to support "very-simple-lhs", which is used by cluster2verilog
    Use "module load yosys/0.19-RE-fsm-vslhs" for that.

    positional arguments:
      original_verilog      original verilog netlist to be read by yosys.
      cluster_path          The cluster in .pq format as output by run_clustering
      output_file           The file name of the verilog file to write to.

    optional arguments:
      -h, --help            show this help message and exit
      -c CELL_LIB_PATH, --cell_lib_path CELL_LIB_PATH
                            The file containing the cell library. Default:
                            /nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tech/osu035/osu035_stdcells.lib
      --logger {info,debug,warning,error,critical}, -l {info,debug,warning,error,critical}
                            logger level. Default: info

"""
import argparse
import logging
import os
import re
import subprocess
import sys
from tempfile import NamedTemporaryFile

import pandas as pd
import networkx as nx

from .helpers import setup_cli


glogger = logging.getLogger(__name__)


parser = argparse.ArgumentParser(
    description="Extract a module from a netlist according to a cluster."
)
parser.add_argument(
    "original_verilog", help="original verilog netlist to be read by yosys."
)
parser.add_argument(
    "cluster_path",
    help="The cluster in .pq format as output by run_clustering",
)
parser.add_argument(
    "output_file",
    help="The file name of the verilog file to write to.",
)
osu035_default = (
    "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/"
    "qflow/tech/osu035/osu035_stdcells.lib"
)
parser.add_argument(
    "-c",
    "--cell_lib_path",
    help="The file containing the cell library. Default: " + osu035_default,
    default=osu035_default,
)
parser.add_argument(
    "--logger",
    "-l",
    help="logger level. Default: info",
    choices=["info", "debug", "warning", "error", "critical"],
    default="info",
)


def main(args=None):
    args = parser.parse_args(args=args)
    setup_cli(log_level=args.logger, additional_loggers=["tueisec_myparsing"])
    original_verilog = args.original_verilog

    nodes_in_module = list(
        nx.from_pandas_edgelist(pd.read_parquet(args.cluster_path)).nodes()
    )
    glogger.debug("Read cluster")

    output_file = args.output_file
    hierarchy_name = os.path.splitext(os.path.basename(output_file))[0]
    verilog_plain_id_re = re.compile(r"(([a-zA-Z_])([a-zA-Z_0-9$])*)")
    if not verilog_plain_id_re.fullmatch(hierarchy_name):
        escaped_hierarchy_name = "\\\\" + hierarchy_name + " "
    else:
        escaped_hierarchy_name = hierarchy_name
    cell_lib_path = args.cell_lib_path

    with NamedTemporaryFile("w+", encoding="utf8", suffix=".ys") as f:
        actual_name = f.name

        selection_string = " ".join(f"*/c:{node}" for node in nodes_in_module)

        f.write(
            f"""
read_verilog {original_verilog}
read_liberty {cell_lib_path}
select {selection_string}
submod -name {escaped_hierarchy_name}
select {escaped_hierarchy_name}
write_verilog -selected -very-simple-lhs -noattr -norename {output_file}
        """
        )

        if (
            subprocess.run(
                ["yosys", "-s", actual_name], stdout=sys.stdout, stderr=sys.stderr
            ).returncode
            == 0
        ):
            glogger.info(
                f"Successfully extracted {escaped_hierarchy_name} into {output_file}"
            )
        else:
            glogger.info(
                f"Some yosys error when extracting {escaped_hierarchy_name} into "
                f"{output_file}. Please inspect yosys output above."
            )
