"""
Command line app to parse a verilog file and generate some stats

.. code-block::
    :caption: Synopsys:

    usage: netlist-statistics [-h] filepath

    Print various statistics about a synthesized verilog file.

    positional arguments:
    filepath    file (*.v) to get info about.

    optional arguments:
    -h, --help  show this help message and exit

"""
import argparse

import tueisec_myparsing.synthed_verilog_parser as svp
from tueisec_myparsing.synthed_verilog_ast import (
    ModuleDef,
    Instance,
    Input,
    Output,
    Assign,
    Rvalue,
    Lvalue,
    Identifier,
    IntConst,
    Decl
)

from tueisec_myparsing.base_ply_parser import VerilogParsingError
from .helpers import setup_cli

import logging

glogger = logging.getLogger(__name__)

parser = argparse.ArgumentParser(
    description="Print various statistics about a synthesized verilog file."
)
parser.add_argument("filepath", help="file (*.v) to get info about.")

parser.add_argument(
    "--logger",
    "-l",
    help="logger level. Default: info",
    choices=["info", "debug", "warning", "error", "critical"],
    default="info",
)


def main(args=None):
    args = parser.parse_args(args=args)
    setup_cli(log_level=args.logger, additional_loggers=["tueisec_myparsing"])
    filepath = args.filepath

    try:
        ast, _ = svp.parse(filepath)
    except VerilogParsingError as e:
        glogger.error(
            "file does not parse: '{}' due to: {}".format(filepath, e)
        )
        return

    count_pragmas = 0
    count_modules = 0
    count_std_cells_per_module = {}
    count_in_per_module = {}
    count_out_per_module = {}
    count_assigns_per_module = {}

    for definition in ast.description.definitions:
        if isinstance(definition, ModuleDef):
            modinst = definition
            count_std_cells_per_module.setdefault(count_modules, 0)
            count_in_per_module.setdefault(count_modules, 0)
            count_out_per_module.setdefault(count_modules, 0)
            count_assigns_per_module.setdefault(count_modules, 0)
            for item in modinst.items:
                if isinstance(item, Instance):
                    count_std_cells_per_module[count_modules] += 1
                if isinstance(item, Assign):
                    count_assigns_per_module[count_modules] += 1
                if isinstance(item, Decl):
                    for i in range(len(item.list)):
                        if isinstance(item.list[i], Input):
                             count_in_per_module[count_modules] += 1
                        if isinstance(item.list[i], Output):
                             count_out_per_module[count_modules] += 1
            count_modules += 1
        else:
            count_pragmas += 1

    print("Number of pragmas: {}".format(count_pragmas))
    print("Number of modules: {}".format(count_modules))
    print("")

    for module in range(count_modules):
        print("Module {}".format(module))
        print("Number of inputs: {}".format(count_in_per_module[module]))
        print("Number of outputs: {}".format(count_out_per_module[module]))
        print("Number of std cells: {}".format(count_std_cells_per_module[module]))
        print("Number of assigns: {}".format(count_assigns_per_module[module]))
        print("")
