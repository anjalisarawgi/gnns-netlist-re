"""Helper functions for cli tools
"""
import logging

log_config = {
    "fmt": "{levelname}: - {asctime} - [{name}] - {message}",
    "style": "{",
    "datefmt": "%Y-%m-%d %H:%M:%S",
}

FILE_LOGGING_DEFAULTS = [
    {
        "path": "all.log",
        "mode": "w",
        "level": "debug"
    },
    {
        "path": "error.log",
        "mode": "w",
        "level": "error"
    },
]


def setup_cli(
    log_level="debug",
    file_logging=False,
    additional_loggers=None,
    log_config=log_config,
    file_logging_path="all.log",
):
    """setup logging for cli

    recommended parser config is:

    .. code-block:: python
        :caption: setup argparse

        parser.add_argument(
            "--logger",
            "-l",
            help="logger level. Default: info",
            choices=["info", "debug", "warning", "error", "critical"],
            default="info",
        )

    :param log_level: loglevel, as returned by recommended argparser, defaults
                      to "debug"
    :type log_level: str, optional
    :param file_logging: if file logging shall be enabled, defaults to False
    :type file_logging: bool, optional
    :param additional_loggers: provide an iterable of additional logger names to
                            set the logging level for, defaults to None
    :type additional_loggers: iterable, optional
    :param log_config:  config dict for logging, input with ``**log_config`` to
                        :py:class:`logging.Formatter`, defaults to

                        .. code-block:: python
                            :caption: default formatting config

                            log_config = {
                                "fmt": "{levelname}: - {asctime} - [{name}] - {message}",
                                "style": "{",
                                "datefmt": "%Y-%m-%d %H:%M:%S"
                            }

    :type log_config: bool, optional
    :param file_logging_path: if file logging is enabled, log to this path.
    :type file_logging_path: str, optional

    :raises ValueError: ValueError if the provided log_level is unknown.
    """
    # get root logger
    logger = logging.getLogger()
    # set global logging level - no messages lower than this will be used by the
    # handlers
    logger.setLevel(logging.DEBUG)
    # ~ logger = logging.getLogger("root")

    # create console handler
    console = logging.StreamHandler()
    formatter = logging.Formatter(**log_config)
    console.setFormatter(formatter)

    console.setLevel(str_to_logginglevel(log_level))

    # add the handlers to the logger
    logger.propagate = False
    logger.addHandler(console)

    # create file handlers
    file_handlers = []
    if file_logging:
        if isinstance(file_logging, bool):
            file_logging = FILE_LOGGING_DEFAULTS
        for file_logging_config in file_logging:
            handler = logging.FileHandler(
                file_logging_config["path"],
                file_logging_config["mode"],
                encoding=None,
                delay="true"
            )

            # create a logging format
            formatter = logging.Formatter(**log_config)
            handler.setFormatter(formatter)
            handler.setLevel(str_to_logginglevel(file_logging_config["level"]))

            logger.addHandler(handler)
            file_handlers.append(handler)

    if additional_loggers is not None:
        for logger in additional_loggers:
            requests_logger = logging.getLogger(logger)
            requests_logger.setLevel(console.level)
            requests_logger.propagate = False
            for h in file_handlers:
                requests_logger.addHandler(h)
            requests_logger.addHandler(console)


def str_to_logginglevel(log_level):
    """return a python logging loglevel for string log levels

        :param log_level: a loglevel string. Possible values
            are info, debug, warning, error and critical
        :type log_level: str
        :raises ValueError: If a unknown string was supplied to log_level
    """
    if log_level == "info":
        return logging.INFO
    elif log_level == "debug":
        return logging.DEBUG
    elif log_level == "warning":
        return logging.WARNING
    elif log_level == "error":
        return logging.ERROR
    elif log_level == "critical":
        return logging.CRITICAL
    else:
        raise ValueError("wrong logger level selected")
