#!/usr/bin/env python3
"""Run write adjlist.

.. code-block::
    :caption: Synopsys:

    usage: run_write_adjlist [-h] [--debug] [-l CELL_LIBRARY] [-o OUTPUT_PATH]
                         [--cores CORES] [--sia SIA] [--vparsing-debug]
                         [--prepend_types | --use_attr]
                         designs [designs ...]

    WARNING: THIS TOOL IS DEPECATED, use verilog2graph!
    Write adjacency lists for a collection of verilog files.

    positional arguments:
    designs               Specify the designs (*.v) to be parsed as command line
                            arguments. Either submit a folder name, single, or
                            multiple file names.

    optional arguments:
    -h, --help            show this help message and exit
    -l CELL_LIBRARY, --cell_library CELL_LIBRARY
                            The cell library path to use. Default:
                            /nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tech/osu035/osu035_stdcells.lib
    -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The folder where output files will be stored.You may
                            use {}, which is replaced with the process name.
                            Default is: outputFiles/{}/design_graph/
    --cores CORES         Cores to use for processing. Default is all cores
    --sia SIA             Deprecated option kept for compatibility. Do not use.
    --vparsing-debug      Activate debug output of verilog parsing.
    --prepend_types       If set, the graph nodes will be prepended with the
                            node types, if the node type is not yet in the node
                            name. Careful: this is a expensive operation. Consider
                            using a more complex graph storage format where
                            storing node data is possible.
    --write_node_type     If set, the graph nodes get an attribute "node_type"
                            that contains the cell type. Careful, output can not
                            be an adjlist any more, but is a gzipped graphml file

    main:
    --debug               Enable debug output

"""

import glob
import logging
import os
import json
from argparse import ArgumentParser

import networkx as nx
import tueisec_myparsing.myparsing_ply as myparsing
from tueisec_myparsing.verilog_parsing_errors import (
    ASTParsingError,
    VerilogParsingError,
)
from tueisec_myparsing.pool_wrapper import run_in_pool_with_progress
from .helpers import setup_cli

glogger = logging.getLogger(__name__)

cell_library_default = "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tech/osu035/osu035_stdcells.lib"
output_path_default = "outputFiles/{}/design_graph/"

parser = ArgumentParser(
    description=(
        "WARNING: THIS TOOL IS DEPECATED, use verilog2graph! Write adjacency "
        "lists for a collection of verilog files."
    )
)
group = parser.add_argument_group("main")
group.add_argument("--debug", help="Enable debug output", action="store_true")

parser.add_argument(
    "designs",
    help="Specify the designs (*.v) to be parsed as command line arguments."
    " Either submit a folder name, single, or multiple file names.",
    nargs="+",
)
parser.add_argument(
    "-l",
    "--cell_library",
    help="The cell library path to use. Default: " + cell_library_default,
    default=cell_library_default,
)

parser.add_argument(
    "-o",
    "--output_path",
    help="The folder where output files will be stored."
    "You may use {}, which is replaced with the process name. Default is: "
    + output_path_default,
    default=output_path_default,
)

parser.add_argument(
    "--cores", help="Cores to use for processing. Default is all cores", type=int
)
parser.add_argument(
    "--sia", help="Deprecated option kept for compatibility. Do not use.", type=bool
)
parser.add_argument(
    "--vparsing-debug",
    help="Activate debug output of verilog parsing.",
    action="store_true",
)

parser.add_argument(
    "--overwrite",
    help="Overwrite existing files.",
    action="store_true",
)

g = parser.add_mutually_exclusive_group()

g.add_argument(
    "--prepend_types",
    help="If set, the graph nodes will be prepended with the node types, "
    "if the node type is not yet in the node name. Careful: this is a "
    "expensive operation. Consider using a more complex graph storage format "
    "where storing node data is possible.",
    action="store_true",
)

g.add_argument(
    "--write_node_type",
    help="If set, the graph nodes get an attribute \"node_type\" that contains the cell type. "
        "Careful, output can not be an adjlist any more, but is a gzipped graphml file",
    action="store_true",
)

parser.add_argument(
    "--write_json",
    help="If set, output is a graph in json format, useful for d3",
    action="store_true",
)


def main():
    GLOBAL_PARSER = parser.parse_args()
    if GLOBAL_PARSER.debug:
        setup_cli(log_level="debug", additional_loggers=["tueisec_myparsing"])
    else:
        setup_cli(log_level="warning", additional_loggers=["tueisec_myparsing"])

    if isinstance(GLOBAL_PARSER.designs, str):
        design_path = GLOBAL_PARSER.designs
        if design_path.endswith(".v"):
            designs = [design_path]
        else:
            designs = glob.glob(os.path.join(design_path, "*.v"))
            glogger.info("Found {} designs.".format(len(designs)))
    else:
        designs = []
        for design_path in GLOBAL_PARSER.designs:
            if design_path.endswith(".v"):
                designs.append(design_path)
            else:
                add_designs = glob.glob(os.path.join(design_path, "*.v"))
                glogger.info(
                    "Found {} designs in {}.".format(len(add_designs), design_path)
                )
                designs.extend(add_designs)
    glogger.info("Found {} designs".format(len(designs)))
    libPath = GLOBAL_PARSER.cell_library
    cell_lib_name = os.path.basename(libPath).split("_")[0]

    if GLOBAL_PARSER.sia is not None:
        glogger.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")

    output_path = os.path.join(GLOBAL_PARSER.output_path.format(cell_lib_name))
    os.makedirs(output_path, exist_ok=True)

    vparsing_debug = GLOBAL_PARSER.vparsing_debug
    prepend_types = GLOBAL_PARSER.prepend_types
    write_node_type = GLOBAL_PARSER.write_node_type
    write_json = GLOBAL_PARSER.write_json
    overwrite_adj = GLOBAL_PARSER.overwrite

    mult = []
    for i, design_file in enumerate(designs):
        mult.append((design_file, libPath, output_path, vparsing_debug, prepend_types, write_node_type, write_json, overwrite_adj))
    run_in_pool_with_progress(
        write_adj, mult, processes=GLOBAL_PARSER.cores, abort_on_kint=False
    )


def write_adj(args):
    design_file, libPath, output_path, vparsing_debug, prepend_types, write_node_type, write_json, overwrite_adj = args
    design_name = os.path.basename(design_file)[:-2]

    if write_json:
        out_file_name = os.path.join(output_path, design_name + ".json")
    elif write_node_type:
        out_file_name = os.path.join(output_path, design_name + ".graphml.gz")
    else:
        out_file_name = os.path.join(output_path, design_name + ".txt")

    if os.path.exists(out_file_name) and not overwrite_adj:
        glogger.warning("Outfile {} already exists. Skipping. Use --overwrite to overwrite.".format(design_name))
        return

    try:
        parsed_verilog = myparsing.parse_to_obj(
            design_file,
            libPath,
            vparsing_debug=vparsing_debug,
        )
    except (ASTParsingError, VerilogParsingError) as e:
        glogger.exception("Exception while parsing {}".format(design_file), exc_info=e)
        return

    if prepend_types:
        graph = nx.DiGraph(parsed_verilog.get_graph_with_types_in_names())
        return
    elif write_node_type:
        graph = parsed_verilog.get_networkx_graph(node_types=True)
        if write_json:
            with open(os.path.join(output_path, design_name + ".json"), "w") as f:
                json.dump(nx.node_link_data(graph), f)
        else:
            nx.write_graphml(graph, os.path.join(output_path, design_name + ".graphml.gz"))
        return
    else:
        graph = parsed_verilog.get_networkx_graph()
        if write_json:
            with open(os.path.join(output_path, design_name + ".json"), "w") as f:
                json.dump(nx.node_link_data(graph), f)
        else:
            nx.write_adjlist(graph, os.path.join(output_path, design_name + ".txt"))
        return

