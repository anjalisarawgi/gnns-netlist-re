#!/usr/bin/env python3
"""prepare generic verilog gates to a format that parser understands.

This executable needs the liberty and associated generic cell files.
There is a working default included in this package, which will be used by default.

For parsing later, use eg.:

```
run_write_adjlist -l path/to/tueisec_myparsing/generic_cells/generic_cells.lib --sia false ...
```

.. code-block::
    :caption: Synopsys:

    usage: prepare_generic_cells [-h]
                             [--logger {info,debug,warning,error,critical}]
                             [-o] [-t TECH_FOLDER] [-d DEST_PATH] [-f]
                             design [design ...]

    Synthesize files in an existing qflow folder structure.

    positional arguments:
    design                Design file paths that should be prepped.

    optional arguments:
    -h, --help            show this help message and exit
    --logger {info,debug,warning,error,critical}, -l {info,debug,warning,error,critical}
                            logger level. Default: info
    -o, --overwrite       Overwrite designs if already in %dest_path%
    -t TECH_FOLDER, --tech_folder TECH_FOLDER
                            The folder where the generic_cells tech files are
                            located. Default is the integrated generic_cells
                            folder, which just works.
    -d DEST_PATH, --dest_path DEST_PATH
                            The folder where the prepared files will be put.
                            Default: cwd
    -f, --file_logging    Log to file additionally.

"""

import os.path
import logging
import re

from argparse import ArgumentParser

from ..defines import (
    MODULE_INSTANTIATION_LINE_NODOT_RE,
    CONNECTIONS_NODOT_RE,
    IO_PORT_LINE_RE,
)
from .helpers import setup_cli

glogger = logging.getLogger(__name__)

DEFAULT_GENERIC_CELLS_DIR = os.path.abspath(
    os.path.dirname(os.path.abspath(__file__)) + "/../generic_cells/"
)


def get_var_from_tcsh(varname, shfile):
    regex = re.compile(
        r"""^\s*(?:set\s+(?P<variable>\w+)=(?P<value>[\w\d#+?'\\/&%$!-.]*"""
        + r"""|"[\s\w\d#+?'\\/&%$!.-]*"|'[\s\w\d#+?'\\/&%$!.-]*')\s*)?;?(?:[#].+)?$"""
    )
    with open(shfile, "r") as handle:
        for line in handle:
            match = regex.match(line)
            if match is None:
                raise ValueError("Cannot parse shfile, line '{}' is bad".format(line))
            else:
                if match["variable"] == varname:
                    return match["value"].strip("\"'")
                else:
                    continue


def prepare():

    libname = os.path.basename(GLOBAL_PARSER.tech_folder)

    shfile = os.path.join(GLOBAL_PARSER.tech_folder, libname + ".sh")
    numbersep = get_var_from_tcsh("separator", shfile)

    if isinstance(GLOBAL_PARSER.designs, str):
        all_designs = [GLOBAL_PARSER.designs]
    else:
        all_designs = set(GLOBAL_PARSER.designs)

    prepare_designs = []
    will_overwrite = False
    for design in all_designs:
        if os.path.exists(
            os.path.join(GLOBAL_PARSER.dest_path, os.path.basename(design))
        ):
            if GLOBAL_PARSER.overwrite:
                will_overwrite = True
                prepare_designs.append(design)
        else:
            prepare_designs.append(design)
    if prepare_designs:
        print("Will prepare these designs: " + ", ".join(prepare_designs))
    else:
        print("Woops, no files to prepare. Maybe you have to specify --overwrite?")
        return
    if will_overwrite:
        print("Last Warning: will overwrite some designs!")
        input("ok?")

    ################
    # start doing actual work:
    ################

    ALLOWED_CELLS = {
        "and": {"repl": "AND", "max": 6, "min": 2},
        "or": {"repl": "OR", "max": 6, "min": 2},
        "nand": {"repl": "NAND", "max": 6, "min": 2},
        "nor": {"repl": "NOR", "max": 6, "min": 2},
        "xor": {"repl": "XOR", "max": 2, "min": 2},
        "xnor": {"repl": "XNOR", "max": 2, "min": 2},
        "buf": {"repl": "BUF", "max": 1, "min": 1},
        "not": {"repl": "INV", "max": 1, "min": 1},
    }

    IN_NAMES = ["A", "B", "C", "D", "E", "F"]

    for design in prepare_designs:
        with open(design, "r") as inhandle:
            outfile = os.path.join(GLOBAL_PARSER.dest_path, os.path.basename(design))

            collected_io = []

            with open(outfile, "w") as outhandle:
                for line in inhandle:
                    line_s = line.strip()
                    io_match = IO_PORT_LINE_RE.match(line_s)
                    if io_match:
                        collected_io.append(
                            (io_match["ioro"], io_match["width"], io_match["portname"])
                        )
                        continue
                    if line_s.startswith(");"):
                        ports = ",\n\t".join(
                            [portname for _, _, portname in collected_io]
                        )
                        outhandle.write("\t{}\n);\n".format(ports))
                        for ioro, width, portname in collected_io:
                            if width is None:
                                outhandle.write("\t{} {};\n".format(ioro, portname))
                            else:
                                outhandle.write(
                                    "\t{} {} {};\n".format(ioro, width, portname)
                                )
                        continue
                    instantiation_match = MODULE_INSTANTIATION_LINE_NODOT_RE.match(
                        line_s
                    )
                    if instantiation_match is None:
                        outhandle.write(line)
                        continue
                    cell_name = instantiation_match.group("cell_name")
                    if cell_name not in ALLOWED_CELLS.keys():
                        raise ValueError("Unallowed cell in file: {}".format(cell_name))
                    inst_name = instantiation_match.group("inst_name")
                    connections = instantiation_match.group("connections")
                    connections_match = CONNECTIONS_NODOT_RE.finditer(connections)

                    connections_list = [match for match in connections_match]

                    output = connections_list.pop(0)

                    num_of_ins = len(connections_list)
                    if (
                        num_of_ins > ALLOWED_CELLS[cell_name]["max"]
                        or num_of_ins < ALLOWED_CELLS[cell_name]["min"]
                    ):
                        raise ValueError(
                            "Cell {} has {} inputs, which is not in allowed range ({}-{})".format(
                                cell_name,
                                num_of_ins,
                                ALLOWED_CELLS[cell_name]["min"],
                                ALLOWED_CELLS[cell_name]["max"],
                            )
                        )

                    new_cell_name = "{}{}{}1".format(
                        ALLOWED_CELLS[cell_name]["repl"], num_of_ins, numbersep
                    )

                    newins_l = []

                    for match, portname in zip(connections_list, IN_NAMES):
                        net_name = match.group("net_name")
                        newins_l.append(".{}({})".format(portname, net_name))

                    newins = ", ".join(newins_l)
                    new_ports = ".Z({}), {}".format(output.group("net_name"), newins)

                    newline = "{} {} ({});".format(new_cell_name, inst_name, new_ports)

                    outhandle.write(newline + "\n")


def main():
    global GLOBAL_PARSER
    parser = ArgumentParser(
        description="Synthesize files in an existing qflow folder structure."
    )

    parser.add_argument(
        "--logger",
        "-l",
        help="logger level. Default: info",
        choices=["info", "debug", "warning", "error", "critical"],
        default="info",
    )

    parser.add_argument(
        "-o",
        "--overwrite",
        help="Overwrite designs if already in %%dest_path%% ",
        action="store_true",
    )

    parser.add_argument(
        "-t",
        "--tech_folder",
        help="The folder where the generic_cells tech files are located. "
        "Default is the integrated generic_cells folder, which just works.",
        default=DEFAULT_GENERIC_CELLS_DIR,
    )

    parser.add_argument(
        "-d",
        "--dest_path",
        help="The folder where the prepared files will be put. Default: cwd",
        default=os.getcwd(),
    )

    parser.add_argument(
        metavar="design",
        dest="designs",
        help=("Design file paths that should be prepped. "),
        nargs="+",
    )

    parser.add_argument(
        "-f", "--file_logging", help="Log to file additionally.", action="store_true"
    )

    GLOBAL_PARSER = parser.parse_args()
    setup_cli(log_level=GLOBAL_PARSER.logger, file_logging=GLOBAL_PARSER.file_logging)
    prepare()
