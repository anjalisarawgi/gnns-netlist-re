#!/usr/bin/env python3
"""Create a graph from verilog with additional attributes.

.. code-block::
    :caption: Synopsys:

    usage: verilog2graph [-h] [--debug] [-l CELL_LIBRARY] [-o OUTPUT_PATH]
                         [--cores CORES] [--sia SIA] [--vparsing-debug]
                         [--do-not-zip] [--overwrite]
                         [--output_info {plain,prepend_types,write_node_type,complete_data}]
                         [--output_format {adjlist,gexf,gml,graphml,json}]
                         designs [designs ...]

    Create a graph from verilog with additional attributes.

    positional arguments:
    designs               Specify the designs (*.v) to be parsed as command line
                          arguments. Either submit a folder name, single, or
                          multiple file names.

    optional arguments:
    -h, --help            show this help message and exit
    -l CELL_LIBRARY, --cell_library CELL_LIBRARY
                          The cell library path to use. Default: /nas/ei/share/s
                          ec/tools/qflow/qflow-1.3-RE/share/qflow/tech/osu035/os
                          u035_stdcells.lib
    -o OUTPUT_PATH, --output_path OUTPUT_PATH
                          The folder where output files will be stored.You may
                          use {}, which is replaced with the process name.
                          Default is: outputFiles/{}/design_graph/
    --cores CORES         Cores to use for processing. Default is all cores
    --sia SIA             Deprecated option kept for compatibility. Do not use.
    --vparsing-debug      Activate debug output of verilog parsing.
    --do-not-zip          No zipping of output files
    --overwrite           Overwrite existing files.
    --output_info {plain,prepend_types,write_node_type,complete_data}
                          If `plain`, only nodes and edges are in the graph.
                          This is the default. If `prepend_types`, the graph
                          nodes will be prepended with the node types, if the
                          node type is not yet in the node name. Careful: this
                          is a expensive operation. Consider using a more
                          complex graph storage format where storing node data
                          is possible. If `write_node_type`, the graph nodes get
                          an attribute "nodeType" that contains the cell type.
                          Careful, output can not be an adjlist any more, but
                          any other format. If `complete_data`, the graph
                          contains as much data as possible, as parsed from the
                          verilog file. Be Careful, output can not be an adjlist
                          any more, but any other format.
    --output_format {adjlist,gexf,gml,graphml,json}
                          Choose the output format wisely.

    main:
    --debug               Enable debug output

"""  # noqa: E501

import glob
import logging
import os
from argparse import ArgumentParser
from enum import Enum

import networkx as nx
import tueisec_myparsing.myparsing_ply as myparsing
from tueisec_myparsing.verilog_parsing_errors import (
    ASTParsingError,
    VerilogParsingError,
)
from tueisec_myparsing.graph_output_file_formats import GraphOutputFormat
from tueisec_myparsing.pool_wrapper import run_in_pool_with_progress
from .helpers import setup_cli

glogger = logging.getLogger(__name__)

cell_library_default = (
    "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/"
    "share/qflow/tech/osu035/osu035_stdcells.lib"
)
output_path_default = "outputFiles/{}/design_graph/"

parser = ArgumentParser(
    description="Create a graph from verilog with additional attributes."
)
group = parser.add_argument_group("main")
group.add_argument("--debug", help="Enable debug output", action="store_true")

parser.add_argument(
    "designs",
    help="Specify the designs (*.v) to be parsed as command line arguments."
    " Either submit a folder name, single, or multiple file names.",
    nargs="+",
)
parser.add_argument(
    "-l",
    "--cell_library",
    help="The cell library path to use. Default: " + cell_library_default,
    default=cell_library_default,
)

parser.add_argument(
    "-o",
    "--output_path",
    help="The folder where output files will be stored."
    "You may use {}, which is replaced with the process name. Default is: "
    + output_path_default,
    default=output_path_default,
)

parser.add_argument(
    "--cores", help="Cores to use for processing. Default is all cores", type=int
)
parser.add_argument(
    "--sia", help="Deprecated option kept for compatibility. Do not use.", type=bool
)
parser.add_argument(
    "--vparsing-debug",
    help="Activate debug output of verilog parsing.",
    action="store_true",
)
parser.add_argument(
    "--do-not-zip", help="No zipping of output files", action="store_true",
)

parser.add_argument(
    "--overwrite", help="Overwrite existing files.", action="store_true",
)


class OutputInformation(Enum):
    plain = "plain"
    prepend_types = "prepend_types"
    write_node_type = "write_node_type"
    complete_data = "complete_data"

    def __str__(self):
        return self.value


parser.add_argument(
    "--output_info",
    help="If `plain`, only nodes and edges are in the graph. This is the default."
    "                                                                          "
    "If `prepend_types`, the graph nodes will be prepended with the node types, "
    "if the node type is not yet in the node name. Careful: this is a "
    "expensive operation. Consider using a more complex graph storage format "
    "where storing node data is possible."
    "                                                                          "
    "If `write_node_type`, the graph nodes get an attribute 'nodeType' that "
    "contains the cell type. "
    "Careful, output can not be an adjlist any more, but any other format."
    "                                                                          "
    "If `complete_data`, the graph contains as much data as possible, as parsed "
    "from the verilog file. "
    "Be Careful, output can not be an adjlist any more, but any other format.",
    default=OutputInformation.plain,
    type=OutputInformation,
    choices=list(OutputInformation),
)

parser.add_argument(
    "--output_format",
    help="Choose the output format wisely.",
    default=GraphOutputFormat.adjlist,
    type=GraphOutputFormat,
    choices=list(GraphOutputFormat),
)


def main():
    GLOBAL_PARSER = parser.parse_args()
    if GLOBAL_PARSER.debug:
        setup_cli(log_level="debug", additional_loggers=["tueisec_myparsing"])
    else:
        setup_cli(log_level="warning", additional_loggers=["tueisec_myparsing"])

    if (
        GLOBAL_PARSER.output_info == OutputInformation.write_node_type
        or GLOBAL_PARSER.output_info == OutputInformation.complete_data
    ) and (GLOBAL_PARSER.output_format == GraphOutputFormat.adjlist or GLOBAL_PARSER.output_format == GraphOutputFormat.simpleParquet):
        glogger.critical(
            "If you want to have complex data, choose a complex output format, please."
        )
        exit()

    if isinstance(GLOBAL_PARSER.designs, str):
        design_path = GLOBAL_PARSER.designs
        if design_path.endswith(".v"):
            designs = [design_path]
        else:
            designs = glob.glob(os.path.join(design_path, "*.v"))
            glogger.info("Found {} designs.".format(len(designs)))
    else:
        designs = []
        for design_path in GLOBAL_PARSER.designs:
            if design_path.endswith(".v"):
                designs.append(design_path)
            else:
                add_designs = glob.glob(os.path.join(design_path, "*.v"))
                glogger.info(
                    "Found {} designs in {}.".format(len(add_designs), design_path)
                )
                designs.extend(add_designs)
    glogger.info("Found {} designs".format(len(designs)))
    libPath = GLOBAL_PARSER.cell_library
    cell_lib_name = os.path.basename(libPath).split("_")[0]

    if GLOBAL_PARSER.sia is not None:
        glogger.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")

    output_path = os.path.join(GLOBAL_PARSER.output_path.format(cell_lib_name))
    os.makedirs(output_path, exist_ok=True)

    vparsing_debug = GLOBAL_PARSER.vparsing_debug
    output_info = GLOBAL_PARSER.output_info
    output_format = GLOBAL_PARSER.output_format
    overwrite_adj = GLOBAL_PARSER.overwrite
    do_not_zip = GLOBAL_PARSER.do_not_zip

    mult = []
    for design_file in designs:
        mult.append(
            (
                design_file,
                libPath,
                output_path,
                vparsing_debug,
                output_info,
                output_format,
                overwrite_adj,
                do_not_zip,
            )
        )
    run_in_pool_with_progress(
        output_graph, mult, processes=GLOBAL_PARSER.cores, abort_on_kint=False
    )


def output_graph(args):
    (
        design_file,
        libPath,
        output_path,
        vparsing_debug,
        output_info,
        output_format,
        overwrite_adj,
        do_not_zip,
    ) = args
    design_name = os.path.basename(design_file)[:-2]

    out_file_name = output_format.get_filename(
        os.path.join(output_path, design_name), do_not_zip
    )

    if os.path.exists(out_file_name) and not overwrite_adj:
        glogger.warning(
            "Outfile {} already exists. Skipping. Use --overwrite to overwrite.".format(
                design_name
            )
        )
        return

    add_const_as_input = output_info == OutputInformation.complete_data
    try:
        parsed_verilog = myparsing.parse_to_obj(
            design_file,
            libPath,
            vparsing_debug=vparsing_debug,
            add_const_as_input=add_const_as_input,
        )
    except (ASTParsingError, VerilogParsingError) as e:
        glogger.exception("Exception while parsing {}".format(design_file), exc_info=e)
        return

    if output_info == OutputInformation.prepend_types:
        graph = nx.DiGraph(parsed_verilog.get_graph_with_types_in_names())
        write_graph(graph, output_path, design_name, output_format, do_not_zip)
        return
    elif output_info == OutputInformation.write_node_type:
        graph = parsed_verilog.get_networkx_graph(node_types=True)
        write_graph(graph, output_path, design_name, output_format, do_not_zip)
        return
    elif output_info == OutputInformation.complete_data:
        graph = parsed_verilog.get_networkx_graph(complete=True)
        write_graph(graph, output_path, design_name, output_format, do_not_zip)
    else:
        graph = parsed_verilog.get_networkx_graph()
        write_graph(graph, output_path, design_name, output_format, do_not_zip)
        return


def write_graph(graph, path, filename, format, do_not_zip):
    format.write_graph(graph, path, filename, do_not_zip)
