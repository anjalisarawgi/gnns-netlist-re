#!/usr/bin/env python3
"""Run hierarchy based on a toml file of regexes per hierarchy module.

.. code-block::
    :caption: Synopsys:

    usage: genus2hierarchy [-h] [--debug] [-o OUTPUT_PATH] [--overwrite]
                           [--logger {info,debug,warning,error,critical}]
                           [--parsing_loglevel_error] [--cores CORES]
                           hierarchyinfo [hierarchyinfo ...]

    Generate hierarchy files from named cells list, assign glue logic until the next named
    signal.

    positional arguments:
      hierarchyinfo         structured hierarchy input data (toml): File containing the hierarchy
                            to detect as a tree of modules. Each module defines a signal name as
                            a regex to search for.

    optional arguments:
      -h, --help            show this help message and exit
      -o OUTPUT_PATH, --output_path OUTPUT_PATH
                            The folder where output files will be stored.Default is:
                            outputFiles/hierarchy/
      --overwrite           Overwrite existing hierarchies
      --logger {info,debug,warning,error,critical}
                            logger level. Default: info
      --parsing_loglevel_error
                            Set the parsing loglevel to error, if you want to ignore warnings,
                            such as'constant one-bit assignment' etc.
      --cores CORES         Cores to use for processing. Default is to use all cores.

    main:
      --debug               Enable debug output. Overrides --logger


.. code-block::
    :caption: Example toml

     [ design ]
     filepath = "path_to_verilog_file.v"
     lib = "path_to_cell_lib.lib"
     type = "top_module_name"

     [ design.modules.first ]
     regex = ".*first.*"
     [ design.modules.first.modules.first_firstsub ]
     regex = ".*first_firstsub.*"
     [ design.modules.first.modules.first_secsub ]
     net_regex = ".*first_firstsub_netnames.*"
     node_regex = ".*first_firstsub_nodenames.*"
"""

import glob
import os
import re

import pandas as pd

import tueisec_myparsing.myparsing_ply as myparsing
from tueisec_myparsing.module_tree_node import ModuleTreeNode
from tueisec_myparsing.pool_wrapper import run_in_pool_with_progress
from .helpers import setup_cli

from argparse import ArgumentParser
import toml

import queue

import pickle

import logging

glogger = logging.getLogger(__name__)

osu035_default = (
    "/nas/ei/share/sec/tools/qflow/qflow-1.3-RE/share/qflow/tech/"
    "osu035/osu035_stdcells.lib"
)
output_path_default = "outputFiles/hierarchy/"


def invert_dict(d):
    inverse = dict()
    for key in d:
        # Go through the list that is saved in the dict:
        for item in d[key]:
            # Check if in the inverted dict the key exists
            if item not in inverse:
                # If not create a new list
                inverse[item] = [key]
            else:
                inverse[item].append(key)
    return inverse


def get_hierarchy(info_file):
    output_path = os.path.join(GLOBAL_PARSER.output_path)

    os.makedirs(output_path, exist_ok=True)

    hinfo = toml.load(info_file)

    try:
        file_path = hinfo["design"]["filepath"]
    except KeyError:
        glogger.critical(
            f"info file {info_file} does not contain design "
            f"filepath. Please put it at `design.filepath`."
        )
        return
    file_name = os.path.basename(file_path)[:-2]
    if (
        os.path.isfile(os.path.join(output_path, "hierarchy_" + file_name + ".csv"))
        and os.path.isfile(
            os.path.join(output_path, "hierarchy_modules_" + file_name + ".csv")
        )
        and not GLOBAL_PARSER.overwrite
    ):
        glogger.warning(
            "Hierarchy file for {} exists already. Skipping. Use --overwrite to overwrite".format(
                file_name
            )
        )
        return

    if GLOBAL_PARSER.parsing_loglevel_error:
        tulogger = logging.getLogger("tueisec_myparsing")
        tulogger.setLevel(logging.ERROR)

    try:
        libPath = hinfo["design"]["lib"]
    except KeyError:
        glogger.critical(
            f"info file {info_file} does not contain library "
            "setting. Please put it at `design.lib`."
        )
        return

    parsed_verilog = None
    pickle_path = os.path.join(output_path, "parsed_" + file_name + ".pickle")
    if (
        os.path.isfile(pickle_path)
    ):
        try:
            with open(pickle_path, "rb") as f:
                parsed_verilog = pickle.load(f)
            glogger.warning(f"Found pickle file at {pickle_path}. I will not parse the verilog to save time!")
        except BaseException:
            glogger.exception(f"Failed to load pickle file at {pickle_path}. Parsing verilog instead.")
            parsed_verilog = None

    if parsed_verilog is None:
        parsed_verilog = myparsing.parse_to_obj(
            file_path, libPath, 
        )

        with open(pickle_path, "wb") as f:
            pickle.dump(parsed_verilog, f)
            glogger.info(f"Pickle file at {pickle_path} created.")
        
    # find module names
    module_name = parsed_verilog.module_name
    glogger.debug("Module name is {}".format(module_name))

    all_nodes = parsed_verilog.nodes[1].copy()
    all_nodes.update(parsed_verilog.nodes[0])
    all_nodes.update(parsed_verilog.nodes[2])

    glogger.debug("parsing hierarchy...")
    tree_root = get_hierarchy_tree(
        hinfo, file_name, parsed_verilog, all_nodes, module_name
    )

    if tree_root is None:
        glogger.critical(
            f"Hierarchy generation for {info_file} failed. "
            f"Please see detailed error message above."
        )
        return

    hierarchy = tree_root.node_hierarchy()

    modules_dict = tree_root.modules_dict()

    df_design = pd.DataFrame.from_dict(hierarchy, orient="index").T
    df_design.sort_index(axis=1, inplace=True)
    df_design.to_csv(os.path.join(output_path, "hierarchy_" + file_name + ".csv"))

    df_module = pd.DataFrame(modules_dict, index=["type"])
    df_module.sort_index(axis=1, inplace=True)
    df_module.to_csv(
        os.path.join(output_path, "hierarchy_modules_" + file_name + ".csv")
    )


def get_hierarchy_tree(hinfo, file_name, parsed_verilog, all_nodes, module_name):

    glogger.debug("Building module tree")

    tree_root = ModuleTreeNode(frozenset(), "tree_root", "tree_root", root=True)

    try:
        top_mod_dict = hinfo["design"]["modules"]
    except KeyError:
        glogger.critical(
            f"top module of {file_name} has no submodules. "
            f"There is no hierarchy to generate here."
        )
        return None

    try:
        top_module_type = hinfo["design"]["type"]
    except KeyError:
        glogger.critical(
            f"in {file_name} there is no info about top module type. "
            f"Please put it at `design.type`."
        )
        return None

    top_module = ModuleTreeNode(frozenset(), "top", top_module_type)
    tree_root.add(top_module)

    to_visit = queue.deque([(top_module, top_mod_dict)])

    unknown_type_counter = 0

    while to_visit:
        parent_node, cur_mod_dict = to_visit.pop()
        for id, data in cur_mod_dict.items():
            try:
                type = data["type"]
            except KeyError:
                glogger.critical(
                    f"in {file_name} node data `{id}` has no type. "
                    f"the type is not strictly needed. I'll put "
                    f"`unknown_{unknown_type_counter}`. If that's not OK,"
                    f"please put it at `design.<hierarchy...>.{id}.type`."
                )
                type = f"unknown_{unknown_type_counter}"
                unknown_type_counter += 1

            child_node = ModuleTreeNode(
                frozenset(),
                id,
                type,
            )
            child_node.net_regex = re.compile(
                data.get("net_regex", data.get("regex", ""))
            )
            child_node.node_regex = re.compile(
                data.get("node_regex", data.get("regex", ""))
            )
            parent_node.add(child_node)
            to_visit.append((child_node, data.get("modules", {})))

    glogger.debug("built module tree")

    # this is an ordered dict of tree nodes. i.e. we can
    # search for the first regex, then the second, then...
    net_hierarchy_names_dict = tree_root.net_hierarchy_names_DFS_postorder_dict()

    glogger.debug("built net_dict")

    assigned_nodes = {}
    module_tree_nodes_set_cache = {}

    # for all nodes check if their name matches the name regex
    for node in all_nodes.keys():
        for module_tree_node in net_hierarchy_names_dict.values():
            if module_tree_node.node_regex.fullmatch(node):
                assigned_nodes[node] = module_tree_node
                module_tree_nodes_set_cache.setdefault(module_tree_node, set()).add(
                    node
                )

    # for all the nodes check if the incident nets are match the net regex
    for net, node_list in parsed_verilog.nets.items():
        for module_tree_node in net_hierarchy_names_dict.values():
            if module_tree_node.net_regex.fullmatch(net):
                unassigned = set(node_list) - assigned_nodes.keys()
                module_tree_nodes_set_cache.setdefault(module_tree_node, set()).update(
                    unassigned
                )
                assigned_nodes.update(((u, module_tree_node) for u in unassigned))

    # for those cells where the output nets have a name like a possible module
    for net, node in parsed_verilog.nets_to_nodes.items():
        for module_tree_node in net_hierarchy_names_dict.values():
            if module_tree_node.net_regex.fullmatch(net):
                if node not in assigned_nodes:
                    module_tree_nodes_set_cache.setdefault(module_tree_node, set()).add(
                        node
                    )
                    assigned_nodes[node] = module_tree_node
    glogger.debug("completed node regexing")

    ########################################################################
    # now follow i/o, one step at a time.
    # check for each node if output net or input net is a generated net.
    # Then the nodes on the other end of these nets also belong to the module.
    # only generated nets are handled by this, by ensuring one-step-at-a-time,
    # a fair separation between modules is done
    node_list = list(assigned_nodes)
    generated_prefix_re = re.compile(r"([^.]*\.)*([^.]+_)?n_")
    while node_list:
        node_list_cur = node_list
        node_list = []
        while node_list_cur:
            mod_node = node_list_cur.pop()
            for _, dest in all_nodes[mod_node]["dest"]:
                if dest is None:
                    continue
                if generated_prefix_re.fullmatch(dest):
                    nodes_driven_by_generated_net = parsed_verilog.nets[dest]
                    unassigned = (
                        set(nodes_driven_by_generated_net) - assigned_nodes.keys()
                    )
                    module_tree_nodes_set_cache.setdefault(
                        assigned_nodes[mod_node], set()
                    ).update(unassigned)
                    assigned_nodes.update(
                        (n, assigned_nodes[mod_node]) for n in unassigned
                    )
                    node_list.extend(unassigned)
            for _, src in all_nodes[mod_node]["src"]:
                if src is None:
                    continue
                if src.startswith(hinfo.get("generated_prefix", r"([^.]*\.)*([^.]+_)?n_")):
                    driver_node_of_generated_net = parsed_verilog.nets_to_nodes[src]
                    if driver_node_of_generated_net not in assigned_nodes:
                        module_tree_nodes_set_cache.setdefault(
                            assigned_nodes[mod_node], set()
                        ).add(driver_node_of_generated_net)
                        assigned_nodes[driver_node_of_generated_net] = assigned_nodes[
                            mod_node
                        ]
                        node_list.append(driver_node_of_generated_net)

    ########################################################################
    # now for all nodes that do not belong to any module, set module as top
    unknowns = set(all_nodes.keys()) - assigned_nodes.keys()

    if unknowns:
        top_module.immediate_nodes = frozenset(unknowns)
    ########################################################################

    # from the cache, populate the nodes,
    for module_tree_node, nodes in module_tree_nodes_set_cache.items():
        module_tree_node.immediate_nodes = frozenset(nodes)

    return tree_root


def hierarchy():

    if isinstance(GLOBAL_PARSER.hierarchyinfo, str):
        info_path = GLOBAL_PARSER.hierarchyinfo
        if info_path.endswith(".toml"):
            infos = [info_path]
        else:
            infos = glob.glob(os.path.join(info_path, "*.toml"))
            glogger.info("Found {} designs.".format(len(infos)))
    else:
        infos = []
        for info_path in GLOBAL_PARSER.hierarchyinfo:
            if info_path.endswith(".toml"):
                infos.append(info_path)
            else:
                add_infos = glob.glob(os.path.join(info_path, "*.toml"))
                glogger.info(
                    "Found {} designs in {}.".format(len(add_infos), info_path)
                )
                infos.extend(add_infos)
    mult = []
    for info_file in infos:
        mult.append(info_file)
        glogger.info("Working on {}".format(os.path.basename(info_file)))

    run_in_pool_with_progress(
        get_hierarchy, mult, processes=GLOBAL_PARSER.cores, abort_on_kint=False
    )
    glogger.info("Finished hierarchy for {} designs.".format(len(infos)))


def main():
    global GLOBAL_PARSER
    parser = ArgumentParser(
        description="Generate hierarchy files from named cells list, assign "
        "glue logic until the next named signal."
    )
    group = parser.add_argument_group("main")
    group.add_argument(
        "--debug", help="Enable debug output. Overrides --logger", action="store_true"
    )

    parser.add_argument(
        "hierarchyinfo",
        help="structured hierarchy input data (toml): File containing the "
        "hierarchy to detect as a tree of modules. "
        "Each module defines a signal name as a regex to search for.",
        nargs="+",
    )

    parser.add_argument(
        "-o",
        "--output_path",
        help="The folder where output files will be stored."
        "Default is: " + output_path_default,
        default=output_path_default,
    )

    parser.add_argument(
        "--overwrite", help="Overwrite existing hierarchies", action="store_true"
    )

    parser.add_argument(
        "--logger",
        help="logger level. Default: info",
        choices=["info", "debug", "warning", "error", "critical"],
        default="info",
    )

    parser.add_argument(
        "--parsing_loglevel_error",
        help="Set the parsing loglevel to error, if you want to ignore warnings, such as"
        "'constant one-bit assignment' etc.",
        action="store_true",
    )

    parser.add_argument(
        "--cores",
        help="Cores to use for processing. Default is to use all cores.",
        type=int,
    )

    GLOBAL_PARSER = parser.parse_args()
    if GLOBAL_PARSER.debug:
        GLOBAL_PARSER.logger = "debug"

    setup_cli(log_level=GLOBAL_PARSER.logger, additional_loggers=["tueisec_myparsing"])
    hierarchy()
