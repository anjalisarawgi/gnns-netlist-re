
def is_verilog_escaped(verilog_name):
    return verilog_name.startswith("\\") and verilog_name.find(" ") > 0

def continues_after_verilog_escape(verilog_name):
    if is_verilog_escaped(verilog_name):
        try:
            name, postfix = verilog_name.split(" ", maxsplit=1)
        except ValueError:
            return False
        if len(postfix) > 0:
            return True
        else:
            return False
    else:
        return False

def split_verilog_escape(verilog_name):
    if is_verilog_escaped(verilog_name):
        escaped, rest = verilog_name.split(" ", maxsplit=1)
        return escaped + " ", rest
    else:
        return verilog_name

__VERILOG_BUS = re.compile(r"(?P<id>\w+)\[(?P<n>\d+)\]")
__VERILOG_SUBBUS = re.compile(r"\[(?P<n>\d+)\]")

def is_verilog_unescaped_bus(verilog_name):
    if is_verilog_escaped(verilog_name):
        return False
    return __VERILOG_BUS.fullmatch(
        verilog_name
    )

def is_verilog_escaped_1d_bus(verilog_name):
    if not is_verilog_escaped(verilog_name):
        return False
    if not continues_after_verilog_escape(verilog_name):
        return is_verilog_unescaped_bus(verilog_name.lstrip("\\").rstrip(" "))
    else:
        return False

def is_verilog_escaped_id_bus(verilog_name):
    if not is_verilog_escaped(verilog_name):
        # if s:
            # print("notescaped", verilog_name)
        return False
    if not continues_after_verilog_escape(verilog_name):
        # if s:
            # print("notcont", verilog_name)
        return False
    escaped, bus = split_verilog_escape(verilog_name)
    match = is_verilog_unescaped_bus(f"dummy{bus.strip()}")
    if not match:
        return False
    return escaped, match["n"] 

def is_verilog_escaped_1d_bus_bus(verilog_name, s=False):
    if not is_verilog_escaped(verilog_name):
        # if s:
        #     print("notescaped", verilog_name)
        return False
    if not continues_after_verilog_escape(verilog_name):
        # if s:
        #     print("notcont", verilog_name)
        return False
    else:
        escaped, bus = split_verilog_escape(verilog_name)
        bus1 = is_verilog_escaped_1d_bus(
            escaped
        )
        if not bus1:
            # if s:
            #     print("notbus1", verilog_name)
            #     print(escaped, bus)
            return False
        bus2 = __VERILOG_SUBBUS.fullmatch(bus.strip())
        if not bus2:
            # if s:
            #     print("notbus2", verilog_name)
            return False
        return bus1, bus2
