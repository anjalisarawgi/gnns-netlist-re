
########################################################################
# derived from JB, partly changed by MB, refactored by AD
########################################################################

# stdlib imports
import os.path
import logging

# local imports
from .parsed_verilog_ply import ParsedVerilog
from .liberty_parsing import own_parseLibertyToDataStruct, parse_liberty_file

cell_lib = None
node_lookup = None
nets_to_nodes = None

glogger = logging.getLogger(__name__)

def parse_to_obj(
    netlist_file,
    liberty_file,
    pickle_folder=os.getcwd(),
    exprvar=False,
    space_is_and=None,
    vparsing_debug=False,
    add_const_as_input=False,
    delete_unconnected_inputs=True,
):
    """Main entry point for parsing a verilog file using a refined API.

    Specify the verilog file to parse and the liberty file to use.

    :param netlist_file: Filepath of the verilog file to parse
    :type netlist_file: str
    :param liberty_file: Filepath of the liberty file to use
    :type liberty_file: str
    :param pickle_folder: Folderpath, where the parsed liberty file can be found, 
        defaults to os.getcwd()
    :type pickle_folder: [type], str
    :param exprvar: If set to true, cell functions are returned as pyeda expressions,
        defaults to False
    :param space_is_and: Deprecated option kept for compatibility. Do not use.
        Defaults to :pycode:`None`.
    :type space_is_and: bool, optional
    :param vparsing_debug: Enable debug output from ply parsing, defaults to False
    :type vparsing_debug: bool, optional
    :type exprvar: bool, optional
    :return: Returns a ParsedVerilog object.
    :rtype: parsed_verilog_ply.ParsedVerilog
    """

    if space_is_and is not None:
        glogger.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")

    # check if lib was already parsed
    lib = parse_liberty_file(liberty_file, pickle_folder)

    # parse liberty file to the cell_lib data structure
    cell_lib = own_parseLibertyToDataStruct(lib, exprvar)

    # parse the verilog file using the cell_lib
    parsed_verilog = ParsedVerilog(
        netlist_file,
        cell_lib,
        debug_ply=vparsing_debug,
        add_const_as_input=add_const_as_input,
        delete_unconnected_inputs=delete_unconnected_inputs,
    )

    return parsed_verilog
