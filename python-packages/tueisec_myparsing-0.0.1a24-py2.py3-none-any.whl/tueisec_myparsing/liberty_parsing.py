import re
import os.path
import pickle
from pprint import pprint

from .eda_helper_functions import stringToPyeda
from . import plylibparser

import logging
glogger = logging.getLogger(__name__)


def parseLibertyToDataStruct(lib):
    """ reparses LibertyStructure to a own datastructure

    return:

    .. code-block::

        my_data[cell_name]
            ["inputs"]    : integer number of inputs
            ["outputs"]    : integer number of outpus
            ["inouts"]    : integer number of inouts
            [pin_name]
                ["function"]    : string
                ["direction"]    : string {input, output, inout}
                ["capacitance"]    : string
                ["rise_capacitance"]    : string
                ["fall_capacitance"]    : string
                ["max_capacitance"]    : string
                ["timing_raw"]    : list
                ["timing"]
                    [pin_name]: dict"""

    import copy

    # print(dir(lib))
    # ~ offset = 38
    # ~ pprint(lib.result["library"]["osu035_stdcells"][offset+0]["cell"]["AND2X1"])
    # cell = lib.result["library"]["osu035_stdcells"][offset+0]["cell"]["AND2X1"]

    if len(lib.result["library"].keys()) > 1:
        raise ValueError("more than 1 cell library in liberty file!")
    if "NangateOpenCellLibrary" in lib.result["library"]:
        stdcell = lib.result["library"]["NangateOpenCellLibrary"]
        space_is_and = False  # And(A,B) is (A & B)
    elif "osu035_stdcells" in lib.result["library"]:
        stdcell = lib.result["library"]["osu035_stdcells"]
        space_is_and = True  # And(A,B) is (A B) instead of (A & B)
    elif "osu018_stdcells" in lib.result["library"]:
        stdcell = lib.result["library"]["osu018_stdcells"]
        space_is_and = True  # And(A,B) is (A B) instead of (A & B)
    else:
        raise ValueError("unknown library!")

    # get rid of "library" information
    D_cells = {}  # Dict with all std_cells
    for cell in stdcell:
        if cell.get("cell") is not None:
            D_cells.update(cell.get("cell"))

    my_data = {}
    for cell_name in D_cells:
        my_data[cell_name] = {}
        my_data[cell_name]["inputs"] = 0
        my_data[cell_name]["outputs"] = 0
        my_data[cell_name]["inouts"] = 0
        for entry in D_cells[cell_name]:
            pin = entry.get("pin")
            if pin is not None:
                pin_name = pin.get("name")
                children = pin.get("children")
                my_data[cell_name][pin_name] = {}

                # should we check the index [0] or are we sure that direction is always first?
                direction = children[0].get("direction")
                my_data[cell_name][pin_name]["direction"] = direction

                if direction == "output":
                    my_data[cell_name]["outputs"] += 1
                elif direction == "input":
                    my_data[cell_name]["inputs"] += 1
                elif direction == "inout":
                    my_data[cell_name]["inouts"] += 1

                timing = []
                timing_simple_dict = {}
                for child in children:
                    if child.get("capacitance") is not None:
                        my_data[cell_name][pin_name]["capacitance"] = child.get(
                            "capacitance"
                        )
                    if child.get("rise_capacitance") is not None:
                        my_data[cell_name][pin_name]["rise_capacitance"] = child.get(
                            "rise_capacitance"
                        )
                    if child.get("fall_capacitance") is not None:
                        my_data[cell_name][pin_name]["fall_capacitance"] = child.get(
                            "fall_capacitance"
                        )
                    if child.get("max_capacitance") is not None:
                        my_data[cell_name][pin_name]["max_capacitance"] = child.get(
                            "max_capacitance"
                        )
                    if child.get("function") is not None:
                        if space_is_and:
                            my_data[cell_name][pin_name]["function"] = child.get(
                                "function"
                            ).replace(" ", "&")
                        else:
                            my_data[cell_name][pin_name]["function"] = child.get(
                                "function"
                            )

                    if (
                        child.get("timing") is not None
                    ):  # there may be multiple entries starting with "timing"
                        timing_raw = (child.get("timing")).get("children")
                        timing.append(timing_raw)

                        timing_raw_simple = copy.deepcopy(timing_raw)  # realy deep copy

                        timing_dict = {}

                        for t in timing_raw_simple:
                            if t.get("cell_fall") is not None:
                                timing_dict.update(
                                    {
                                        "cell_fall": (
                                            t.get("cell_fall")
                                            .get("children")[-1]
                                            .get("values")
                                        )
                                    }
                                )
                            #             t['cell_fall'] = (t.get('cell_fall').get('children')[-1].get('values'))
                            elif t.get("cell_rise") is not None:
                                timing_dict.update(
                                    {
                                        "cell_rise": (
                                            t.get("cell_rise")
                                            .get("children")[-1]
                                            .get("values")
                                        )
                                    }
                                )
                            #             t['cell_rise'] = (t.get('cell_rise').get('children')[-1].get('values'))
                            elif t.get("rise_transition") is not None:
                                timing_dict.update(
                                    {
                                        "rise_transition": (
                                            t.get("rise_transition")
                                            .get("children")[-1]
                                            .get("values")
                                        )
                                    }
                                )
                            #             t['rise_transition'] = (t.get('rise_transition').get('children')[-1].get('values'))
                            elif t.get("fall_transition") is not None:
                                timing_dict.update(
                                    {
                                        "fall_transition": (
                                            t.get("fall_transition")
                                            .get("children")[-1]
                                            .get("values")
                                        )
                                    }
                                )
                            #             t['fall_transition'] = (t.get('fall_transition').get('children')[-1].get('values'))
                            else:
                                timing_dict.update(t)
                        #     timing_simple.append(timing_dict)
                        timing_simple_dict[
                            timing_dict.get("related_pin")
                        ] = copy.deepcopy(timing_dict)

                my_data[cell_name][pin_name]["timing_raw"] = timing
                my_data[cell_name][pin_name]["timing"] = timing_simple_dict

    # print("function: ", my_data["AND2X1"]["Y"]["function"])
    # print("timing", my_data["AND2X1"]["Y"]["timing"])
    # print("timing simple", my_data["AND2X1"]["Y"]["timing_simple"])
    # import sys
    # print("my_data needs", sys.getsizeof(cell_lib), "bytes!")
    return my_data


def own_parseLibertyToDataStruct(lib, exprvar=False, space_is_and=None):
    """ reparses LibertyStructure to a own datastructure

    return:

    .. code-block:: 

        my_data[cell_name]
            ["inputs"]    : integer number of inputs
            ["outputs"]    : integer number of outpus
            ["inouts"]    : integer number of inouts
            [pin_name]
                ["function"]            : string
                ["state_function"]        : string
                ["direction"]            : string {input, output, inout}
                ["three_state"]            : arg
            ["ff/latch"] (if vorhanden für cell_name und Auswahl an vorhandenen Daten)
                ["next_state"]            : arg
                ["clocked_on"]            : arg
                ["clear"]                : arg
                ["preset"]                : arg
                ["clear_preset_var1"]    : arg
                ["clear_preset_var2"]    : arg
                ["data_in"]                : arg
                ["enable"]                : arg
    """
    # MB

    if len(lib["library"].keys()) > 1:
        raise ValueError("more than 1 cell library in liberty file!")

    library_name = next(iter(lib["library"]))
    if space_is_and is not None:
        glogger.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")
    stdcell = lib["library"][library_name]

    # get rid of "library" information
    D_cells = {}  # Dict with all std_cells
    global clockname
    setclockname = 0
    for cell in stdcell:
        if cell.get("cell") is not None:
            D_cells.update(cell.get("cell"))

    my_data = {}
    for cell_name in D_cells:
        my_data[cell_name] = {}
        my_data[cell_name]["inputs"] = 0
        my_data[cell_name]["outputs"] = 0
        my_data[cell_name]["inouts"] = 0
        for entry in D_cells[cell_name]:

            # first check if register, latch, ...
            ff = entry.get("ff")
            if ff is not None:
                my_data[cell_name]["ff"] = {}
                variable_1_2 = ff.get("arguments")
                if variable_1_2 is not None:
                    try:
                        my_data[cell_name]["ff"]["variable1"] = variable_1_2[0]
                    except IndexError:
                        glogger.error(
                            f"Syntax error in liberty file {library_name}. "
                            f"In FF {cell_name}, no variable1 exists. "
                            f"Gracefully ignoring..."
                        )
                    try:
                        my_data[cell_name]["ff"]["variable2"] = variable_1_2[1]
                    except IndexError:
                        glogger.error(
                            f"Syntax error in liberty file {library_name}. "
                            f"In FF {cell_name}, no variable2 exists. "
                            f"Gracefully ignoring..."
                        )
                else:
                    glogger.error(
                        f"Syntax error in liberty file {library_name}. "
                        f"In FF {cell_name}, no variable1 and 2 exist. "
                        f"Gracefully ignoring..."
                    )
                ff_attr = ff.get("attributes")
                for item in ff_attr:
                    nextstate = item.get("next_state")
                    if nextstate is not None:
                        my_data[cell_name]["ff"]["next_state"] = nextstate
                    clockedon = item.get("clocked_on")
                    if clockedon is not None:
                        my_data[cell_name]["ff"]["clocked_on"] = clockedon
                        if setclockname == 0:
                            clockname = clockedon.replace("!|+&^", "")
                            setclockname = 1
                    clearvar = item.get("clear")
                    if clearvar is not None:
                        my_data[cell_name]["ff"]["clear"] = clearvar
                    presetvar = item.get("preset")
                    if presetvar is not None:
                        my_data[cell_name]["ff"]["preset"] = presetvar
                    clearpresetvar1 = item.get("clear_preset_var1")
                    if clearpresetvar1 is not None:
                        my_data[cell_name]["ff"]["clear_preset_var1"] = clearpresetvar1
                    clearpresetvar2 = item.get("clear_preset_var2")
                    if clearpresetvar2 is not None:
                        my_data[cell_name]["ff"]["clear_preset_var2"] = clearpresetvar2
                    datain = item.get("data_in")
                    if datain is not None:
                        my_data[cell_name]["ff"]["data_in"] = datain
                    enablevar = item.get("enable")
                    if enablevar is not None:
                        my_data[cell_name]["ff"]["enable"] = enablevar
            latch = entry.get("latch")
            if latch is not None:
                my_data[cell_name]["latch"] = {}
                variable_1_2 = latch.get("arguments")
                if variable_1_2 is not None:
                    try:
                        my_data[cell_name]["latch"]["variable1"] = variable_1_2[0]
                    except IndexError:
                        glogger.error(
                            f"Syntax error in liberty file {library_name}. "
                            f"In latch {cell_name}, no variable1 exists. "
                            f"Gracefully ignoring..."
                        )
                    try:
                        my_data[cell_name]["latch"]["variable2"] = variable_1_2[1]
                    except IndexError:
                        glogger.error(
                            f"Syntax error in liberty file {library_name}. "
                            f"In latch {cell_name}, no variable2 exists. "
                            f"Gracefully ignoring..."
                        )
                else:
                    glogger.error(
                        f"Syntax error in liberty file {library_name}. "
                        f"In latch {cell_name}, no variable1 and 2 exist. "
                        f"Gracefully ignoring..."
                    )
                latch_attr = latch.get("attributes")

                for item in latch_attr:
                    nextstate = item.get("next_state")
                    if nextstate is not None:
                        my_data[cell_name]["latch"]["next_state"] = nextstate
                    clockedon = item.get("clocked_on")
                    if clockedon is not None:
                        my_data[cell_name]["latch"]["clocked_on"] = clockedon
                        if setclockname == 0:
                            clockname = clockedon.replace("!|+&^", "")
                            setclockname = 1
                    clearvar = item.get("clear")
                    if clearvar is not None:
                        my_data[cell_name]["latch"]["clear"] = clearvar
                    presetvar = item.get("preset")
                    if presetvar is not None:
                        my_data[cell_name]["latch"]["preset"] = presetvar
                    clearpresetvar1 = item.get("clear_preset_var1")
                    if clearpresetvar1 is not None:
                        my_data[cell_name]["latch"][
                            "clear_preset_var1"
                        ] = clearpresetvar1
                    clearpresetvar2 = item.get("clear_preset_var2")
                    if clearpresetvar2 is not None:
                        my_data[cell_name]["latch"][
                            "clear_preset_var2"
                        ] = clearpresetvar2
                    datain = item.get("data_in")
                    if datain is not None:
                        my_data[cell_name]["latch"]["data_in"] = datain
                    enablevar = item.get("enable")
                    if enablevar is not None:
                        my_data[cell_name]["latch"]["enable"] = enablevar

            # next check pins
            pin = entry.get("pin")
            if pin is not None:
                pin_name = pin.get("name")
                children = pin.get("pinAttr")
                my_data[cell_name][pin_name] = {}

                for child in children:
                    if child.get("direction") is not None:
                        direction = child.get("direction")
                        my_data[cell_name][pin_name]["direction"] = direction
                        if direction == "output":
                            my_data[cell_name]["outputs"] += 1
                        elif direction == "input":
                            my_data[cell_name]["inputs"] += 1
                        elif direction == "inout":
                            my_data[cell_name]["inouts"] += 1
                    if child.get("function") is not None:
                        my_data[cell_name][pin_name]["function"] = parse_cell_function(
                            child.get("function"), library_name, space_is_and, exprvar
                        )
                    if child.get("state_function") is not None:
                        if space_is_and:
                            my_data[cell_name][pin_name]["state_function"] = child.get(
                                "state_function"
                            ).replace(" ", "&")
                        else:
                            my_data[cell_name][pin_name]["state_function"] = child.get(
                                "state_function"
                            )
                    if child.get("three_state") is not None:
                        threestate = child.get("three_state")
                        my_data[cell_name][pin_name]["three_state"] = threestate

    # ~ pprint(my_data)
    # ~ input()
    return my_data


def parse_cell_function(function, library_name, space_is_and=None, exprvar=False):
    """Normalize the cell functions.

    If the library uses space as and, parse all spaces to ampersand chars. If
    the space surrounds a plus sign (as with the osu035 lib), so not replace it.

    Args:
        function (:obj:`str`): The function string as provided by the library
    """

    if space_is_and is not None:
        glogger.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")
    if exprvar:
        return stringToPyeda(function)
    return function


def parse_liberty_file(liberty_file, pickle_folder, debug_lib_parser=False):
    # check if lib was already parsed
    lib_file_name = "{}_lib.txt".format(
        os.path.splitext(os.path.basename(liberty_file))[0]
    )
    pickle_file_path = os.path.join(pickle_folder, lib_file_name)
    if os.path.isfile(pickle_file_path):
        with open(lib_file_name, "rb") as handle:
            lib = pickle.loads(handle.read())
    else:
        # own parsing
        f = open(liberty_file, "r")
        lib_raw = f.read()
        f.close()

        own_lexer = plylibparser.create_lexer()
        glogger.info("sucessful lexer creation")
        # ~ input()
        own_parser = plylibparser.create_parser()
        glogger.info("successful parser creation")
        # ~ input()
        lib = own_parser.parse(
            lib_raw, lexer=own_lexer, debug=debug_lib_parser
        )  # debug kann auch entfert werden
        glogger.info("successful lib")
        # pprint(lib)
        # ~ input()

        with open(pickle_file_path, "wb") as handle:
            pickle.dump(lib, handle)

    return lib
