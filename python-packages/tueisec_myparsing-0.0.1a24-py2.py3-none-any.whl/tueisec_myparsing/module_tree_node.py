import logging
import re
from collections import OrderedDict

INCLUDING_SUBMODULES_PREFIX_CHAR = "@"

glogger = logging.getLogger(__name__)


class ModuleTreeNode(object):

    __slots__ = (
        "branches",
        "_immediate_nodes",
        "_module_name",
        "_module_type",
        "_root",
        "net_regex",
        "node_regex",
    )

    def __init__(self, immediate_nodes, module_name, module_type, root=False):
        self.branches = set()
        if isinstance(immediate_nodes, frozenset):
            self._immediate_nodes = immediate_nodes
        else:
            raise TypeError("immediate_nodes must be a frozenset")
        self._module_name = module_name
        self._module_type = module_type
        self._root = root
        self.net_regex = ""
        self.node_regex = ""

    @property
    def immediate_nodes(self):
        return self._immediate_nodes

    @immediate_nodes.setter
    def immediate_nodes(self, value):
        if isinstance(value, frozenset):
            self._immediate_nodes = value
        else:
            raise TypeError("immediate_nodes must be a frozenset.")

    @property
    def module_name(self):
        return self._module_name

    @property
    def module_type(self):
        return self._module_type

    def add(self, node):
        if isinstance(node, ModuleTreeNode):
            if self._root:
                if self.branches:
                    raise ValueError("A root node may not have more than one branches")
            self.branches.add(node)
        else:
            raise NotImplementedError(
                "add is not implemented for non ModuleTreeNode objects"
            )

    def discard(self, node):
        if isinstance(node, ModuleTreeNode):
            self.branches.discard(node)
        else:
            raise NotImplementedError(
                "discard is not implemented for non ModuleTreeNode objects"
            )

    def all_nodes(self):
        result = set()
        for mtn in self.branches:
            result.update(mtn.all_nodes())
        result.update(self._immediate_nodes)
        if result:
            return frozenset(result)
        else:
            return frozenset()

    def has_node(self):
        if self._immediate_nodes:
            return True
        for branch in self.branches:
            if branch.has_node():
                return True

    def has_subnode(self):
        for branch in self.branches:
            if branch.has_node():
                return True

    def modules_dict(self):
        if self._root:
            return next(iter(self.branches)).modules_dict()
        else:
            return self._modules_dict("")

    def _modules_dict(self, hierarchy_string):
        if hierarchy_string:
            hierarchy_string = hierarchy_string + "+" + self.module_name
        else:
            hierarchy_string = self.module_name
        modules_dict = {}
        if self.has_node():
            modules_dict[hierarchy_string] = self.module_type
            if self.has_subnode():
                modules_dict[INCLUDING_SUBMODULES_PREFIX_CHAR + hierarchy_string] = (
                    INCLUDING_SUBMODULES_PREFIX_CHAR + self.module_type
                )
        for branch in self.branches:
            modules_dict.update(branch._modules_dict(hierarchy_string))
        return modules_dict

    def node_hierarchy(self):
        if self._root:
            return next(iter(self.branches)).node_hierarchy()
        else:
            return self._node_hierarchy("")

    def _node_hierarchy(self, hierarchy_string):
        if hierarchy_string:
            hierarchy_string = hierarchy_string + "+" + self.module_name
        else:
            hierarchy_string = self.module_name
        hierarchy = {}
        self_all_nodes = self.all_nodes()
        if self_all_nodes:
            if self_all_nodes > self._immediate_nodes:
                hierarchy[
                    INCLUDING_SUBMODULES_PREFIX_CHAR + hierarchy_string
                ] = self_all_nodes
            if self._immediate_nodes:
                hierarchy[hierarchy_string] = frozenset(self._immediate_nodes)
            else:
                glogger.warning("No cells match module {} itself. This may not be an error (for example only the submodules may have matches). Please check the hierarchy for plausability.".format(hierarchy_string))
            for branch in self.branches:
                hierarchy.update(branch._node_hierarchy(hierarchy_string))
        else:
            glogger.warning(
                "No cells match module {} or its submodules. This may not be an error. Please check the hierarchy for plausability.".format(hierarchy_string)
            )
        return hierarchy

    def net_hierarchy_names_DFS_postorder_dict(self, hierarchy_separation_char='_'):
        # CAREFUL: implementation must be DFS postorder for net identification to work!
        if not self._root:
            raise ValueError(
                "net_hierarchy_names does only make sense for the tree root."
            )
        net_hierarchy_names = OrderedDict()
        top_module = next(iter(self.branches))
        for submodule in top_module.branches:
            net_hierarchy_names.update(
                submodule._net_hierarchy_names_DFS_postorder(None, hierarchy_separation_char)
            )
        return net_hierarchy_names

    def _net_hierarchy_names_DFS_postorder(self, current_prefix, hierarchy_separation_char):
        if current_prefix is None:
            new_prefix = re.escape(self._module_name)
        else:
            new_prefix = f"{current_prefix}{hierarchy_separation_char}{re.escape(self._module_name)}"
        net_hierarchy_names = OrderedDict()
        for submodule in self.branches:
            net_hierarchy_names.update(
                submodule._net_hierarchy_names_DFS_postorder(new_prefix, hierarchy_separation_char)
            )
        net_hierarchy_names[new_prefix] = self
        return net_hierarchy_names

    def find_prev(self, module_name_string):
        return self.find(module_name_string, level=-1)

    def find_name(self, name):
        for module in self.branches:
            if module._module_name == name:
                return module
        return None

    def find_type_recr(self, module_type):
        modules = []
        for module in self.branches:
            if module._module_type == module_type:
                modules.append(module)
            modules.extend(module.find_type_recr(module_type))
        return modules

    def find(self, module_name_string, level=None):
        module_hierarchy = module_name_string.split("+")[:level]
        cur = self
        for module in module_hierarchy:
            next_cur = cur.find_name(module)
            if next_cur is not None:
                cur = next_cur
            else:
                return None
        return cur

    @classmethod
    def from_modules(cls, modules, node_dict):
        tree_root = cls(frozenset(), "tree_root", "tree_root", root=True)

        modules_dict_sorted = sorted(modules, key=lambda item: item[0])

        for module_hier_name, module_type in modules_dict_sorted:

            add_root = tree_root.find_prev(module_hier_name)
            if add_root is None:
                raise ValueError(
                    "{} is unknown. There is an error in the module hierarchy. Tree root is: {}".format(
                        module_hier_name, tree_root
                    )
                )
            module_name = module_hier_name.split("+")[-1]
            try:
                add_root.add(
                    cls(
                        frozenset(node_dict[module_hier_name]), module_name, module_type
                    )
                )
            except KeyError:
                add_root.add(cls(frozenset(), module_name, module_type))
        return tree_root

    def __str__(self):
        if self._root:
            ret = ""
        else:
            ret = "{}\n".format(self.module_name)
        for branch in self.branches:
            ret += branch._to_str(0)
        return ret

    def _to_str(self, level=0):
        ret = "{}{}\n".format(
            "     " * (level - 1) + "  +--" * (level > 0), self.module_name
        )
        for branch in self.branches:
            ret += branch._to_str(level + 1)
        return ret

