#!usr/bin/ipython3
# func.py


"""
Pool Helpers
============

Helper functions for running long loops and multiprocessed loops. There is one
version that does not produce a progress bar, as that might cause trouble.

Typical usage as follows:

.. code-block::
    :caption: HowTo multiprocess

    from tueisec_myparsing.pool_wrapper import run_in_pool_with_progress_iter

    # init function for every process. very_large_data (given as 42 below) has to be copied
    # across memories of the main and worker process only once.
    def init_huge_data(very_large_data):
        global G_very_large_data
        G_very_large_data = very_large_data

    # the function that gets run by the workers
    def runner(args):
        global G_very_large_data
        x, y, z = *args
        return x*y + z*G_very_large_data

    mult = []
    # input some values in the list of params
    for x, y, z in zip(range(100), range(100,1,-1), range(0,200,2)):
        mult.append((x, y, z))

    # Start the loop of execution
    rval = run_in_pool_with_progress_iter(
        runner,
        mult,
        processes=None,
        abort_on_kint=False,
        initializer=init_huge_data,
        initargs=(42, )
    )

    # this will asynchronously print the return values as soon as they get available
    for v in rval:
        print("I received {}".format(v))

"""


import multiprocessing
import signal
import sys
import logging

import enlighten

glogger = logging.getLogger(__name__)


class PoolOverride:
    """Override the pool and directly execute the function on the main process

    This overrides the pool and diretly executes loop_function and
    initializer on the main process.
    """

    def __init__(self, processes=None, initializer=None, initargs=None):
        """Init the Pool

        :param processes: Ignored, defaults to None
        :type processes: Any, optional
        :param initializer: If not ``None``, this function is executed during init
            with ``*initargs``, defaults to None
        :type initializer: Callable[[Any, ...], None], optional
        :param initargs: Arguments to initializer, defaults to None
        :type initargs: tuple[Any], optional
        """
        if initializer is not None:
            initializer(*initargs)
        pass

    def imap_unordered(self, func=None, iterable=None, chunksize=1):
        """Execute func with args

        :param func: loop function to execute, defaults to None
        :type func: Callable[[tuple[Any]], Any], optional
        :param iterable: List of function parameters as tuples. each call to
            ``loop_function`` receives vone element of this list., defaults to None
        :type iterable: list[tuple[Any]], optional
        :param chunksize: This param is ignored, defaults to 1
        :type chunksize: int, optional
        """
        for args in iterable:
            yield func(args)

    def close(self):
        """Implement the needed pool API
        """
        pass

    def join(self):
        """Implement the needed pool API
        """
        pass

    def terminate(self):
        """Implement the needed pool API
        """
        pass

def unhandle_sigint_and_exec(initializer):
    def wrapped(*args, **kwargs):
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        if initializer is not None:
            initializer(*args, **kwargs)
    return wrapped

def run_in_pool_with_progress_iter(
    loop_function,
    loop_parameters,
    desc="Processing:",
    unit="designs",
    processes=7,
    abort_on_kint=True,
    initializer=None,
    initargs=(),
    total=None,
    no_signal_mod=False,
):
    """Run a loop function on a process pool with given input data and return an interator.

    This helper function initializes a multiprocessing pool, displays a progress bar via
    enlighten, catches the Keyboard interrupt so that the runners are terminated as well,
    and breaks everything down on completion.

    This function returns an iterator that yields the return values of the loop function.

    :param loop_function: Function to loop through via multiprocessing. shall accept one
        single parameter: a tuple that contains all loop-step parameters
    :type loop_function: Callable[[tuple[Any]], Any]
    :param loop_parameters: List of function parameters as tuples. each call to
        ``loop_function`` receives one element of this list.
    :type loop_parameters: list[tuple[Any]]
    :param desc: Description to be displayed at the progress bar, defaults to "Processing:"
    :type desc: str, optional
    :param unit: Unit to be displayed at the progress bar, defaults to "designs"
    :type unit: str, optional
    :param processes: Number of processes, i.e. the number of workers, to start with
        multiprocessing, defaults to 7. If ``None`` is given, all CPUs-1 will be used.
    :type processes: int, optional
    :param abort_on_kint: Specify if on Ctrl+C, this function throws a
        :py:exc:`KeyboardInterrupt`, or catches it and only aborts the loop, defaults to True
    :type abort_on_kint: bool, optional
    :param initializer: function to be executed once at the initialization of the
        worker processes. Especially, this can be used to init global variables per worker
        process, that are then accessed in the loop_function each time, but only needs
        to be transferred to the worker one, at the init. defaults to None
    :type initializer: Callable[[Any, ...], None], optional
    :param initargs: Tuple of arguments to the ``initializer`` function, the tuple will
        be unpacked and given param by param to the initializer function, defaults to None
    :type initargs: tuple[Any], optional
    :raises KeyboardInterrupt: This function raises an :py:exc:`KeyboardInterrupt`
        exception only if ``abort_on_kiint`` is ``True`` and Ctrl+C is pressed.
    :return: This function returns an Iterator that yields the return values of the
        ``loop_function`` unordered.
    :rtype: iterator
    """

    Pool = multiprocessing.Pool

    if processes is None:
        processes = multiprocessing.cpu_count() - 1

    if processes < 2:
        Pool = PoolOverride

    manager = enlighten.get_manager()

    if total is not None:
        progress_bar = manager.counter(total=total, desc=desc, unit=unit)
    else:
        try:
            progress_bar = manager.counter(total=len(loop_parameters), desc=desc, unit=unit)
        except TypeError:
            # loop_parameters has no length.
            progress_bar = manager.counter(desc=desc, unit=unit)
    progress_bar.update(0, True)

    try:
        # original_sigint_handler = signal.signal(signal.SIGINT, signal.SIG_IGN)
        if no_signal_mod:
            process_pool = Pool(
                processes=processes, initializer=initializer, initargs=initargs
            )
        else:
            process_pool = Pool(
                processes=processes, initializer=unhandle_sigint_and_exec(initializer), initargs=initargs
            )
        # signal.signal(signal.SIGINT, original_sigint_handler)
        glogger.info("Preparing {} runners.".format(processes))

        # supply data to runner
        result_iter = process_pool.imap_unordered(
            func=loop_function, iterable=loop_parameters, chunksize=1
        )
        process_pool.close()
        glogger.info(
            "{} subprocess runners started. Waiting for results...".format(processes)
        )

        for item in result_iter:
            progress_bar.update()
            yield item
    except KeyboardInterrupt:
        process_pool.terminate()
        if abort_on_kint:
            raise KeyboardInterrupt()
    finally:
        progress_bar.close()
        process_pool.close()
        process_pool.join()
        manager.stop()


def run_in_pool_with_progress(
    loop_function,
    loop_parameters,
    desc="Processing:",
    unit="designs",
    processes=7,
    abort_on_kint=True,
    initializer=None,
    initargs=None,
):

    """Run a loop function on a process pool with given input data and return aggregated.

    This helper function initializes a multiprocessing pool, displays a progress bar via
    enlighten, catches the Keyboard interrupt so that the runners are terminated as well,
    and breaks everything down on completion.

    This function returns an list containing the return values of the loop function.

    :param loop_function: Function to loop through via multiprocessing. shall accept one
        single parameter: a tuple that contains all loop-step parameters
    :type loop_function: Callable[[tuple[Any]], Any]
    :param loop_parameters: List of function parameters as tuples. each call to
        ``loop_function`` receives one element of this list.
    :type loop_parameters: list[tuple[Any]]
    :param desc: Description to be displayed at the progress bar, defaults to "Processing:"
    :type desc: str, optional
    :param unit: Unit to be displayed at the progress bar, defaults to "designs"
    :type unit: str, optional
    :param processes: Number of processes, i.e. the number of workers, to start with
        multiprocessing, defaults to 7. If ``None`` is given, all CPUs-1 will be used.
    :type processes: int, optional
    :param abort_on_kint: Specify if on Ctrl+C, this function throws a
        :py:exc:`KeyboardInterrupt`, or catches it and only aborts the loop, defaults to True
    :type abort_on_kint: bool, optional
    :param initializer: function to be executed once at the initialization of the
        worker processes, defaults to None
    :type initializer: Callable[[Any, ...], None], optional
    :param initargs: Tuple of arguments to the ``initializer`` function, this will
        be unpacked and given param by param to the initializer function, defaults to None
    :type initargs: tuple[Any], optional
    :raises KeyboardInterrupt: This function raises an :py:exc:`KeyboardInterrupt`
        exception only if ``abort_on_kiint`` is ``True`` and Ctrl+C is pressed.
    :return: This function returns a list containing the return values of the
        ``loop_function`` unordered.
    :rtype: list
    """

    Pool = multiprocessing.Pool

    if processes is None:
        processes = multiprocessing.cpu_count() - 1

    if processes < 2:
        Pool = PoolOverride

    manager = enlighten.get_manager()

    progress_bar = manager.counter(total=len(loop_parameters), desc=desc, unit=unit)

    result = []

    try:
        original_sigint_handler = signal.signal(signal.SIGINT, signal.SIG_IGN)
        process_pool = Pool(
            processes=processes, initializer=initializer, initargs=initargs
        )
        signal.signal(signal.SIGINT, original_sigint_handler)
        glogger.info("Preparing {} runners.".format(processes))

        # supply data to runner
        result_iter = process_pool.imap_unordered(
            func=loop_function, iterable=loop_parameters, chunksize=1
        )
        process_pool.close()
        glogger.info(
            "{} subprocess runners started. Waiting for results...".format(processes)
        )

        for item in result_iter:
            result.append(item)
            progress_bar.update()
    except KeyboardInterrupt:
        process_pool.terminate()
        if abort_on_kint:
            raise KeyboardInterrupt()
    finally:
        progress_bar.close()
        process_pool.close()
        process_pool.join()
        manager.stop()
    return result


def run_in_pool_iter(
    loop_function,
    loop_parameters,
    processes=7,
    abort_on_kint=True,
    initializer=None,
    initargs=(),
    no_signal_mod=False,
):
    """Run a loop function on a process pool with given input data and return an interator.

    This helper function initializes a multiprocessing pool,
    catches the Keyboard interrupt so that the runners are terminated as well,
    and breaks everything down on completion.

    This function returns an iterator that yields the return values of the loop function.

    :param loop_function: Function to loop through via multiprocessing. shall accept one
        single parameter: a tuple that contains all loop-step parameters
    :type loop_function: Callable[[tuple[Any]], Any]
    :param loop_parameters: List of function parameters as tuples. each call to
        ``loop_function`` receives one element of this list.
    :type loop_parameters: list[tuple[Any]]
    :param processes: Number of processes, i.e. the number of workers, to start with
        multiprocessing, defaults to 7. If ``None`` is given, all CPUs-1 will be used.
    :type processes: int, optional
    :param abort_on_kint: Specify if on Ctrl+C, this function throws a
        :py:exc:`KeyboardInterrupt`, or catches it and only aborts the loop, defaults to True
    :type abort_on_kint: bool, optional
    :param initializer: function to be executed once at the initialization of the
        worker processes. Especially, this can be used to init global variables per worker
        process, that are then accessed in the loop_function each time, but only needs
        to be transferred to the worker one, at the init. defaults to None
    :type initializer: Callable[[Any, ...], None], optional
    :param initargs: Tuple of arguments to the ``initializer`` function, the tuple will
        be unpacked and given param by param to the initializer function, defaults to None
    :type initargs: tuple[Any], optional
    :raises KeyboardInterrupt: This function raises an :py:exc:`KeyboardInterrupt`
        exception only if ``abort_on_kiint`` is ``True`` and Ctrl+C is pressed.
    :return: This function returns an Iterator that yields the return values of the
        ``loop_function`` unordered.
    :rtype: iterator
    """

    Pool = multiprocessing.Pool

    if processes is None:
        processes = multiprocessing.cpu_count() - 1

    if processes < 2:
        Pool = PoolOverride

    try:
        # original_sigint_handler = signal.signal(signal.SIGINT, signal.SIG_IGN)
        if no_signal_mod:
            process_pool = Pool(
                processes=processes, initializer=initializer, initargs=initargs
            )
        else:
            process_pool = Pool(
                processes=processes, initializer=unhandle_sigint_and_exec(initializer), initargs=initargs
            )
        # signal.signal(signal.SIGINT, original_sigint_handler)
        glogger.info("Preparing {} runners.".format(processes))

        # supply data to runner
        result_iter = process_pool.imap_unordered(
            func=loop_function, iterable=loop_parameters, chunksize=1
        )
        process_pool.close()
        glogger.info(
            "{} subprocess runners started. Waiting for results...".format(processes)
        )

        for item in result_iter:
            yield item
    except KeyboardInterrupt:
        process_pool.terminate()
        if abort_on_kint:
            raise KeyboardInterrupt()
    finally:
        process_pool.close()
        process_pool.join()


def draw_progress_bar(percent, barLen=60):
    """Function draws simple progress bar. This function overwrites the current terminal line.

    :param percent: Ration of completion to draw the progress bar for.
    :type percent: float
    :param barLen: length of progress bar in characters
    :type barLen: int, optional

    """
    sys.stdout.write("\r")
    progress = ""
    for i in range(barLen):
        if i < int(barLen * percent):
            progress += "="
        else:
            progress += " "
    sys.stdout.write("[ %s ] %.2f%%" % (progress, percent * 100))
    sys.stdout.flush()
