import ply.lex as lex
import re
import ply.yacc as yacc

########################################################################
# partly based on PLY documentations, partly based on pydotlib.py file
########################################################################

reserved = {
    "library": "LIBRARY",
    "cell": "CELL",
    "test_cell": "TESTCELL",
    "pin": "PIN",
    "direction": "DIRECTION",
    "input": "INPUT",
    "output": "OUTPUT",
    "inout": "INOUT",
    "internal": "INTERNAL",
    "function": "FUNCTION",
    "state_function": "STATE_FUNCTION",
    "ff": "FF",
    "latch": "LATCH",
    "clocked_on": "CLOCKED_ON",
    "next_state": "NEXT_STATE",
    "enable": "ENABLE",
    "data_in": "DATA_IN",
    "clear": "CLEAR",
    "preset": "PRESET",
    "clear_preset_var1": "CLEAR_PRESET_VAR1",
    "clear_preset_var2": "CLEAR_PRESET_VAR2",
    "three_state": "THREE_STATE",
}

# List of token names.   This is always required
tokens = [
    "NUMBER",
    "LRB",
    "RRB",
    "LCB",
    "RCB",
    "COLON",
    "COMMA",
    "COMMADOT",
    "STRING",
    "WORDS",
] + list(reserved.values())


def create_lexer():

    # Regular expression rules for simple tokens
    t_LRB = r"\("
    t_RRB = r"\)"
    t_LCB = r"\{"
    t_RCB = r"\}"
    t_COLON = r":"
    t_COMMA = r","
    t_COMMADOT = r";"
    t_NUMBER = (
        r"[-+]?([0-9]+\.?[0-9]*([Ee][-+]?[0-9]+)?|[0-9]*\.[0-9]*([Ee][-+]?[0-9]+)?)"
    )

    # Find all strings und cut off ""
    def t_STRING(t):
        r'"[^"]*"'
        t.value = t.value[1:-1]
        return t

        # Find rest of words and check for reserved ones

    def t_WORDS(t):
        r"[a-zA-Z_][0-9a-zA-Z_\-$]*"
        t.type = reserved.get(t.value, "WORDS")
        return t

        # Ignore comments

    def t_COMMENT(t):
        # ~ r'/\*[^(\*/)]*\*/'
        r"/\*(.|\n)*?\*/"
        t.lexer.lineno += t.value.count("\n")
        pass

        # Define a rule so we can track line numbers

    def t_newline(t):
        r"\n+|\\\n+"
        t.lexer.lineno += t.value.count("\n")

        # A string containing ignored characters (spaces and tabs)

    t_ignore = " \t"

    # Error handling rule
    def t_error(t):
        print("Illegal character '%s'" % t.value[0])
        t.lexer.skip(1)

        # Build the lexer

    return lex.lex(
        reflags=re.DOTALL | re.VERBOSE, debug=1
    )  # debug kann auch entfert werden


def create_parser():
    def p_library(t):
        "library : LIBRARY LRB wordorstring RRB LCB attributes RCB"
        wholeLib = {}
        wholeLib[t[1]] = {}
        wholeLib[t[1]][t[3]] = t[6]
        t[0] = wholeLib
        # ~ print(t)

    def p_wordorstring(t):
        """wordorstring : WORDS 
            | STRING"""
        t[0] = t[1]

    def p_attributes(t):
        "attributes : oneattribute attributes"
        att = []
        att.append(t[1])
        att.extend(t[2])
        t[0] = att
        # ~ print(t)

    def p_attributes_c(t):
        "attributesC : oneattributeC attributesC"
        att = []
        att.append(t[1])
        att.extend(t[2])
        t[0] = att

    def p_attributes_empty(t):
        "attributes :"
        t[0] = []
        # ~ print(t)

    def p_attributes_c_empty(t):
        "attributesC :"
        t[0] = []

    def p_oneattribute(t):
        """oneattribute : oneitemA
			| moreitemA
			| specialitem"""
        t[0] = t[1]
        # ~ print(t)

    def p_oneattribute_c(t):
        """oneattributeC : oneitemA
			| moreitemA
			| specialitemC"""
        t[0] = t[1]

    def p_oneitemA(t):
        "oneitemA : WORDS COLON argEnd"
        attsingle = {}
        attsingle[t[1]] = t[3]
        t[0] = attsingle
        # ~ print(t)

    def p_arg(t):
        "arg : argwo"
        t[0] = t[1]
        # ~ print(t)

    def p_argEnd(t):
        "argEnd : argwo COMMADOT"
        t[0] = t[1]
        # ~ print(t)

    def p_argwo(t):
        """argwo : NUMBER
			| STRING
			| WORDS
			| NUMBER WORDS
			| fixset
            | reserved"""
        t[0] = t[1]
        # nicht so super prezise: falls man die Einheiten bei NUMBER WORDS will, muss man noch was ändern....
        # ~ print(t)

    def p_fixset(t):
        """fixset : CLEAR
			| PRESET"""
        t[0] = t[1]
        # ~ print(t)

    def p_reserved(t):
        """reserved : LIBRARY
            | CELL
            | PIN
            | DIRECTION
            | INPUT
            | OUTPUT
            | INOUT
            | INTERNAL
            | FUNCTION
            | STATE_FUNCTION
            | FF
            | LATCH
            | CLOCKED_ON
            | NEXT_STATE
            | ENABLE
            | DATA_IN
            | CLEAR
            | PRESET
            | CLEAR_PRESET_VAR1
            | CLEAR_PRESET_VAR2
            | THREE_STATE"""
        t[0] = t[1]

    def p_moreitemA(t):
        "moreitemA : WORDS LRB arg args RRB child"
        attpl = {}
        argpl = []
        if t[3] != None:
            argpl.append(t[3])
            if t[4] != None:
                argpl.extend(t[4])
        attpl[t[1]] = {}
        attpl[t[1]]["args"] = argpl
        if t[6] != None:
            attpl[t[1]]["child"] = t[6]
        t[0] = attpl
        # ~ print(t)

    def p_child(t):
        "child : LCB attributes RCB"
        t[0] = t[2]
        # ~ print(t)

    def p_child_dummy(t):
        "child : COMMADOT"
        t[0] = t[1]
        # ~ print(t)

    def p_arg_empty(t):
        "arg :"
        t[0] = None
        # ~ print(t)

    def p_args_empty(t):
        "args :"
        t[0] = None
        # ~ print(t)

    def p_args(t):
        "args : COMMA arg args"
        argex = []
        argex.append(t[2])
        if t[3] != None:
            argex.extend(t[3])
        t[0] = argex
        # ~ print(t)

    def p_pins(t):
        "specialitemC : PIN LRB wordorstring RRB LCB attributes RCB"
        wholePin = {}
        wholePin[t[1]] = {}
        wholePin[t[1]]["name"] = t[3]
        wholePin[t[1]]["pinAttr"] = t[6]
        t[0] = wholePin
        # ~ print(t)

    def p_direction(t):
        "specialitem : DIRECTION COLON DirDef COMMADOT"
        direction = {}
        direction[t[1]] = t[3]
        t[0] = direction
        # ~ print(t)

    def p_DirDef(t):
        """DirDef : INPUT
			| OUTPUT
			| INOUT
			| INTERNAL
			| STRING"""
        t[0] = t[1]
        # ~ print(t)

    def p_cell(t):
        "specialitem : CELL LRB wordorstring RRB LCB attributesC RCB"
        wholeCell = {}
        wholeCell["cell"] = {}
        wholeCell["cell"][t[3]] = t[6]
        t[0] = wholeCell
        # ~ print(t)

    def p_function(t):
        "specialitem : FUNCTION COLON STRING COMMADOT"
        fun = {}
        fun[t[1]] = t[3]
        t[0] = fun
        # ~ print(t)

    def p_statefunction(t):
        "specialitem : STATE_FUNCTION COLON STRING COMMADOT"
        fun = {}
        fun[t[1]] = t[3]
        t[0] = fun
        # ~ print(t)

    def p_ffA(t):
        "specialitemC : FF LRB arg args RRB LCB attributes RCB"
        ffs = {}
        ffs[t[1]] = {}
        if t[3] != None:
            ffs[t[1]]["arguments"] = [t[3]]
            if t[4] != None:
                ffs[t[1]]["arguments"].extend(t[4])
        ffs[t[1]]["attributes"] = t[7]
        t[0] = ffs
        # ~ print(t)

    def p_nextstateA(t):
        "specialitem : NEXT_STATE COLON argEnd"
        attnext = {}
        attnext[t[1]] = t[3]
        t[0] = attnext
        # ~ print(t)

    def p_clockedonA(t):
        "specialitem : CLOCKED_ON COLON argEnd"
        attclock = {}
        attclock[t[1]] = t[3]
        t[0] = attclock
        # ~ print(t)

    def p_clearA(t):
        "specialitem : CLEAR COLON argEnd"
        attclear = {}
        attclear[t[1]] = t[3]
        t[0] = attclear
        # ~ print(t)

    def p_presetA(t):
        "specialitem : PRESET COLON argEnd"
        attpreset = {}
        attpreset[t[1]] = t[3]
        t[0] = attpreset
        # ~ print(t)

    def p_clearpresetvar1A(t):
        "specialitem : CLEAR_PRESET_VAR1 COLON argEnd"
        attclear1 = {}
        attclear1[t[1]] = t[3]
        t[0] = attclear1
        # ~ print(t)

    def p_clearpresetvar2A(t):
        "specialitem : CLEAR_PRESET_VAR2 COLON argEnd"
        attclear2 = {}
        attclear2[t[1]] = t[3]
        t[0] = attclear2
        # ~ print(t)

    def p_threestateA(t):
        "specialitem : THREE_STATE COLON argEnd"
        attthree = {}
        attthree[t[1]] = t[3]
        t[0] = attthree
        # ~ print(t)

    def p_latchA(t):
        "specialitemC : LATCH LRB arg args RRB LCB attributes RCB"
        latch = {}
        latch[t[1]] = {}
        if t[3] != None:
            latch[t[1]]["arguments"] = [t[3]]
            if t[4] != None:
                latch[t[1]]["arguments"].extend(t[4])
        latch[t[1]]["attributes"] = t[7]
        t[0] = latch
        # ~ print(t)

    def p_datainA(t):
        "specialitem : DATA_IN COLON argEnd"
        attdat = {}
        attdat[t[1]] = t[3]
        t[0] = attdat
        # ~ print(t)

    def p_enableA(t):
        "specialitem : ENABLE COLON argEnd"
        attenab = {}
        attenab[t[1]] = t[3]
        t[0] = attenab
        # ~ print(t)

        # Error rule for syntax errors

    def p_testCell(t):
        "specialitemC : TESTCELL LRB RRB LCB attributesC RCB"
        wholeCell = {}
        wholeCell["test_cell"] = {}
        wholeCell["test_cell"][t[3]] = t[6]
        t[0] = wholeCell

    def p_error(t):
        if t:
            print("Syntax error at '{}' parsed as type '{}' in line {}".format(t.value, t.type, t.lexer.lineno))
        else:
            print("Syntax error at end of input. Probably a closing brace is missing...")
        import pdb

        pdb.set_trace()
        yacc.errok()

        # Build the parser

    return yacc.yacc()

