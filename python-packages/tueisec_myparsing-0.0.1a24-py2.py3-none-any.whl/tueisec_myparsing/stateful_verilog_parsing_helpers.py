import re
import logging

glogger = logging.getLogger(__name__)


class VerilogCommentRemover(object):
    """Remove verilog comments while parsing line-by-line.

    After initialization, supply each line of a verilog file to `handle_comments(...)` before parsing it. You can reuse this class for multiple files, just reset before the next file.
    """

    def __init__(self):
        """Initialize the Verilog Comment Remover."""
        self._in_comment = False
        self.strippable_comments_re = re.compile(
            r"[/][*][^*]*[*]+(?:[^*/][^*]*[*]+)*[/]"
        )  #: Regex to find multiline comments in a single line
        self.line_ends_with_comment_re = re.compile(
            r"[/][*][^*]*(?:[*](?:[^/]|$)[^*]*)*\n$"
        )  #: Regex to find a comment section in a line that ends with a comment
        self.line_starts_with_comment_re = re.compile(
            r"^[^*]*(?:[*](?:[^/])[^*]*)*[*][/]"
        )  #: Regex to find a comment section in a line that starts with a comment
        self.line_has_inline_comment_re = re.compile(
            r"[/][/].*\n$"
        )  #: Regex to find inline comments in a line
        self.accumulated_comments = ""

    def handle_comments(self, line):
        """Handle a line of verilog source code.

        This function removes all comments from a verilog source code line. It tracks begin and end of multiline comments and returns `""` until the end of these.

        Args:
            line (:obj:`str`): The line to remove comments from

        Returns:
            A line of verilog source code without inline and multiline comments. If the current line does not contain enything else but comments, returns `""`.

        """
        if self._in_comment:
            line_starts_with_comment_comment = " ".join(
                self.line_starts_with_comment_re.findall(line)
            )
            rest, line_starts_with_comment = self.line_starts_with_comment_re.subn(
                "", line
            )

            if line_starts_with_comment:
                self._in_comment = False
                self.accumulated_comments += line_starts_with_comment_comment
                return self.handle_comments(rest)

            self.accumulated_comments += rest
            if not self.accumulated_comments.endswith("\n"):
                self.accumulated_comments += "\n"
            return ""
        else:
            while True:
                inline_loc = self.line_has_inline_comment_re.search(line)
                strippable_loc = self.strippable_comments_re.search(line)
                endswith_loc = self.line_ends_with_comment_re.search(line)

                todo = {
                    self.line_has_inline_comment_re: inline_loc,
                    self.strippable_comments_re: strippable_loc,
                    self.line_ends_with_comment_re: endswith_loc,
                }
                firstmatch = sorted(
                    todo.items(), key=lambda x: x[1].start() if x[1] is not None else 4
                )[0]
                if firstmatch[1] is not None:
                    self.accumulated_comments += firstmatch[1][0] + (
                        " " if not self.accumulated_comments.endswith("\n") else ""
                    )
                    line, line_ends_with_comment = firstmatch[0].subn("", line, count=1)
                    if firstmatch[0] is self.line_ends_with_comment_re:
                        if line_ends_with_comment:
                            self._in_comment = True
                            break
                    if firstmatch[0] is self.line_has_inline_comment_re:
                        if line_ends_with_comment:
                            break
                else:
                    break
            if not self.accumulated_comments.endswith("\n"):
                self.accumulated_comments += "\n"
            return line.strip()

    def reset(self):
        """Reset the remover to handle a new file."""
        self._in_comment = False


class VerilogMultilineJoiner(object):
    """Parse multiline verilog statements into one line.

    After initialization, supply verilog sourcecode lines to `handle_line()`.
    """

    def __init__(self, filename):
        """Initialize the Verilog Multiline Joiner."""
        self.filename = filename
        self.aquired_line = ""

    def handle_line(self, line):
        """Handle a multiline statement while parsing line-by-line.

        As soon as the line is complete, the line will be returned, else None is returned.

        Args:
            line (:obj:`str`): A line of verilog code containing part of a instantiation statement.

        Returns:
            The line if the line is complete, else None.

        """
        # there could be coming empty lines due to comments, do not accumulate spaces due to this.
        if not line:
            return None
        if self.aquired_line:
            self.aquired_line += " " + line
        else:
            self.aquired_line = line
        semipos = self.aquired_line.find(";")
        if semipos >= 0:
            ret = self.aquired_line[: semipos + 1]
            self.aquired_line = self.aquired_line[semipos + 1 :]
            return ret
        return None
