
########################################################################
# derived from JB, partly changed by MB, refactored by AD
########################################################################


# stdlib imports
import os.path
import logging

# local imports
from .parsed_verilog import ParsedVerilog
from .liberty_parsing import own_parseLibertyToDataStruct, parse_liberty_file

cell_lib = None
node_lookup = None
nets_to_nodes = None


def parse_to_obj(netlist_file, liberty_file, pickle_folder=os.getcwd(), exprvar=False, space_is_and=None):
    """Main entry point for parsing a verilog file using a refined API.

    Specify the verilog file to parse and the liberty file to use.

    :param netlist_file: Filepath of the verilog file to parse
    :type netlist_file: str
    :param liberty_file: Filepath of the liberty file to use
    :type liberty_file: str
    :param pickle_folder: Folderpath, where the parsed liberty file can be found, defaults to os.getcwd()
    :type pickle_folder: [type], str
    :param exprvar: If set to true, cell functions are returned as pyeda expressions, defaults to False
    :type exprvar: bool, optional
    :param space_is_and: Deprecated option kept for compatibility. Do not use.
        Defaults to :pycode:`None`.
    :type space_is_and: bool, optional
    :return: Returns a ParsedVerilog object.
    :rtype: tuple
    """

    if space_is_and is not None:
        logging.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")

    # check if lib was already parsed
    lib = parse_liberty_file(liberty_file, pickle_folder)

    # parse liberty file to the cell_lib data structure
    cell_lib = own_parseLibertyToDataStruct(lib, exprvar)

    # parse the verilog file using the cell_lib
    parsed_verilog = ParsedVerilog(
        netlist_file, cell_lib
    )

    return parsed_verilog


def parse_it(
    netlist_file, liberty_file, pickle_folder=os.getcwd(), exprvar=False, space_is_and=None
):
    """Main entry point for parsing a verilog file.

    Specify the verilog file to parse and the liberty file to use.

    :param netlist_file: Filepath of the verilog file to parse
    :type netlist_file: str
    :param liberty_file: Filepath of the liberty file to use
    :type liberty_file: str
    :param pickle_folder: Folderpath, where the parsed liberty file can be found, defaults to os.getcwd()
    :type pickle_folder: [type], str
    :param exprvar: If set to true, cell functions are returned as pyeda expressions, defaults to False
    :type exprvar: bool, optional
    :param space_is_and: Deprecated option kept for compatibility. Do not use.
        Defaults to :pycode:`None`.
    :type space_is_and: bool, optional
    :return: Returns a tuple consisting of a dict graph structure, a dict of nets, a tuple containing dicts of nodes, a dict mapping cell instances to node types, the parsed cell lib and a dict mapping nets to their driving nodes.
    :rtype: tuple
    """

    if space_is_and is not None:
        logging.error("Space is and is deprecated, as the root cause was fixed. Ignoring it!")

    # check if lib was already parsed
    lib = parse_liberty_file(liberty_file, pickle_folder)

    global cell_lib
    global node_lookup
    global nets_to_nodes

    # parse liberty file to the cell_lib data structure
    cell_lib = own_parseLibertyToDataStruct(lib, exprvar)

    # parse the verilog file using the cell_lib
    graph, nets, nodes, node_types, _ = ParsedVerilog.parseVerilogToData(
        netlist_file, cell_lib
    )  # FIXME: Better return names for global lookup

    node_lookup = nodes[1]

    nets_to_nodes = ParsedVerilog.rev_lookup(node_lookup)

    return graph, nets, nodes, node_types, cell_lib, nets_to_nodes
