"""Module holding various constant definitions used while parsing.

.. py:data:: BUFFER_PREFIXES:

    Documents buffer prefixes for the various libraries

.. py:data:: BUFFER_.*_PIN:

    Documents buffer pin names for the various libraries

.. py:data:: .*RE.*:

    Regexes for parsing verilog files with the old parser.
"""

import re

BUFFER_PREFIXES = {
    "nangate": "BUF",
    "osu035": "BUF",
    "osu018": "BUF",
    "osu050": "BUF",
}

BUFFER_OUT_PIN = {
    "nangate": "Z",
    "osu035": "Y",
    "osu018": "Y",
    "osu050": "Y",
}

BUFFER_IN_PIN = {
    "nangate": "A",
    "osu035": "A",
    "osu018": "A",
    "osu050": "A",
}


IDENTIFIER_RE_STR = r"(?:(?:[a-zA-Z_][a-zA-Z0-9_$]*)|(?:\\\S+\s))"
IDENTIFIER_RE = re.compile(IDENTIFIER_RE_STR)
CONST_EXPRESSION_RE_STR = r"(?:1\'[sS]?[bBhHoOdD][0-9a-fA-FxXzZ][0-9a-fA-FxXzZ_]*)"
CONST_EXPRESSION_RE = re.compile(CONST_EXPRESSION_RE_STR)

MODULE_NAME_RE = re.compile(
    r"^module\s+(" + IDENTIFIER_RE_STR + r")\s*\("
)  #: Regex to find module name
PRESYN_MODULE_NAME_RE = re.compile(
    r"^module\s+(?P<module_name>" 
    + IDENTIFIER_RE_STR 
    + r")\s*(?:(?:#\s*\([^)]*\)\s*\(?)|(?:#\s*\([^)]*)|(?:#)|)"
)  #: Regex to find module name pre synthesis
MODULE_INSTANTIATION_LINE_RE = re.compile(
    r"^(?P<cell_name>"
    + IDENTIFIER_RE_STR
    + r")\s+(?P<inst_name>"
    + IDENTIFIER_RE_STR
    + r")\s+\(\s*(?P<connections>(?:\."  # Within the connections, 
    # we have .<pin_name>(<net_name>), ..., .<pin_name>(<net_name>), but
    # we do not want to identify them as groups here, because they will overwrite each other.
    # so just receive a complete list of port connections for later separation. 
    + IDENTIFIER_RE_STR  # first port identifiers
    + r"\s*\(\s*(?:"  # begin of port expression
    + IDENTIFIER_RE_STR   # port expression (in this case only other identifier or const allowed)
    + r"|"                #
    + CONST_EXPRESSION_RE_STR #
    + r")?\s*\)\s*,\s*)*(?:\."  # end of first port identifiers, begin of last port identifier
    + IDENTIFIER_RE_STR   # last port identifier
    + r"\s*\(\s*(?:"  # begin of port expression
    + IDENTIFIER_RE_STR   # port expression (in this case only other identifier or const allowed)
    + r"|"                #
    + CONST_EXPRESSION_RE_STR #
    + r")?\s*\))?)\s*\);$" # end of the instantiation statement.
)  #: Regex to split a instantiation line into module instance name and the connections block
MODULE_INSTANTIATION_LINE_NODOT_RE = re.compile(
    r"^(?P<cell_name>"
    + IDENTIFIER_RE_STR
    + r")\s+(?P<inst_name>"
    + IDENTIFIER_RE_STR
    + r")\s+\(\s*(?P<connections>(?:"  # Within the connections,
    # we have <net_name>, ..., <net_name>, but
    # we do not want to identify them as groups here, because they will overwrite each other.
    # so just receive a complete list of port connections for later separation.
    + r"\s*(?:"  # begin of port expression
    + IDENTIFIER_RE_STR   # port expression (in this case only other identifier or const allowed)
    + r"(?:\[\d+\])?|"         # we may have a port statement here
    + CONST_EXPRESSION_RE_STR #
    + r")?\s*,\s*)*(?:"  # end of first port identifiers, begin of last port identifier
    + r"\s*(?:"  # begin of port expression
    + IDENTIFIER_RE_STR   # port expression (in this case only other identifier or const allowed)
    + r"(?:\[\d+\])?|"                #
    + CONST_EXPRESSION_RE_STR #
    + r")?)?)\s*\);$"  # end of the instantiation statement.
)  #: Regex to split a instantiation line into module instance name and the connections block
CONNECTIONS_RE = re.compile(
    r"\.(?P<pin_name>"
    + IDENTIFIER_RE_STR
    + r")\s*\(\s*(?P<net_name>"
    + IDENTIFIER_RE_STR   # port expression (in this case only other identifier or const allowed)
    + r"|"                #
    + CONST_EXPRESSION_RE_STR #
    + r")\s*\)"
)  #: Regex used with findall to match all connection statements in a verilog instantiation statement
CONNECTIONS_NODOT_RE = re.compile(
    r"(?P<net_name>"
    + IDENTIFIER_RE_STR   # port expression (in this case only other identifier or const allowed)
    + r"(?:\[\d+\])?|"                #
    + CONST_EXPRESSION_RE_STR #
    + r")"
)  #: Regex used with findall to match all connection statements in a verilog instantiation stmt
PARSE_ASSIGN_RE = re.compile(
    r"\s*assign\s+(?P<a_dest>"
    + IDENTIFIER_RE_STR
    + r")\s+=\s+(?P<a_src>"
    + IDENTIFIER_RE_STR
    + r"|"
    + CONST_EXPRESSION_RE_STR
    + r")\s*;"
)  # Regex to parse assign statements

IO_PORT_LINE_RE = re.compile(
    r"^(?P<ioro>input|output)\s+"
    + r"(?P<width>\[\d+:\d+\](?=\s))?\s*"
    + r"(?P<portname>"
    + IDENTIFIER_RE_STR
    + r"),?$"
)
