# -----------------------------------------------------------------------------
# netreplace.py
#
# Replaces net names based on a given dict
#
# Based on IdentifierReplace by Shinya Takamaeda-Yamazaki
# -----------------------------------------------------------------------------

from .synthed_verilog_ast import Wire

def replace_nets(node, replace_dict):
    v = NetReplacer(replace_dict)
    return v.visit(node)


class NetReplacer(object):
    def __init__(self, replace_dict):
        self.replace_dict = replace_dict
        self.known_wires = set()

    def visit(self, node):
        method = 'visit_' + node.__class__.__name__
        visitor = getattr(self, method, self.generic_visit)
        ret = visitor(node)
        if ret is None:
            return node
        return ret

    def generic_visit(self, node):
        try:
            del_list = set()
            for c in node.children():
                ret = self.visit(c)
                if ret == "remove":
                    # return is a False, so it is coming through from
                    # visit_Wire, ergo c shall be deleted
                    del_list.add(c.name)
        except AttributeError:
            pass
        # now remove all duplicate wires (i.e. wires where the names are an empty tuple)
        try:
            items = node.items
            new_items = []
            for wire in node.items:
                if isinstance(wire, Wire):
                    if wire.names:
                        new_items.append(wire)
                else:
                    new_items.append(wire)
            node.items = tuple(new_items)
        except AttributeError:
            pass

    def visit_Identifier(self, node):
        if node.name in self.replace_dict:
            node.name = self.replace_dict[node.name]

    def visit_Wire(self, node):
        new_names = []
        for name in node.names:
            new_name = self.replace_dict.get(name, name)
            if new_name in self.known_wires:
                # if due to replace this becomes a duplicate,
                # do not add it to the wire names list.
                pass
            else:
                self.known_wires.add(new_name)
                new_names.append(new_name)
        node.names = tuple(new_names)
