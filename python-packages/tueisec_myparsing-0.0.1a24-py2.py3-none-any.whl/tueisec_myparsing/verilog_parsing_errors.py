"""Module for errors specific to reverse engineering"""

from tueisec_myparsing.synthed_verilog_ast import Node

class VerilogParsingError(Exception):
    """Exception raised for errors in the verilog-to-AST-parsing.

    Attributes:
        coord -- input line in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, coord, message):
        self.coord = coord
        self.message = message

    def __str__(self):
        return "Syntax error in {}: {}".format(self.coord, self.message)


class ASTParsingError(Exception):
    """Exception raised for errors in the AST-to-parsed_verilog parsing.
    """

    def __init__(self, filename, node, message):
        """Initialize the exeption
        
        :param filename: Filename of the file that is currently processed
        :type filename: str
        :param node: AST Node that is erroneous
        :type node: parsed_verilog_ast.Node
        :param message: explanation of the error
        :type message: str
        """
        self.filename = filename
        if isinstance(node, Node):
            try:
                self.line = str(node)
                self.lineno = node.lineno
            except BaseException:
                self.line = "<Unknown>"
                self.lineno = "N/A"
        else:
            self.line = str(node)
            self.lineno = "N/A"
        self.message = message

    @classmethod
    def old_api(cls, filename, line, lineno, message):
        class Temp(object):
            def __str__(self):
                return line
            def __init__(self):
                self.lineno = lineno
        return cls(filename, Temp(), message)


    def __str__(self):
        return "Parsing error in {}:{}: `{}`: {}".format(
            self.filename, self.lineno, self.line, self.message
        )
