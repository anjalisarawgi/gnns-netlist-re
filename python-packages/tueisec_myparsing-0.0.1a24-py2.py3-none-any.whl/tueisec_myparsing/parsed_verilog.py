import sys
from pprint import pprint

from .stateful_verilog_parsing_helpers import (
    VerilogMultilineJoiner,
    VerilogCommentRemover,
)
from .verilog_parsing_errors import ASTParsingError
from .defines import (
    MODULE_NAME_RE,
    PARSE_ASSIGN_RE,
    MODULE_INSTANTIATION_LINE_RE,
    CONNECTIONS_RE,
    CONST_EXPRESSION_RE,
)

import logging

glogger = logging.getLogger(__name__)


class ParsedVerilog(object):
    """Object representing a verilog file.
    """

    def __init__(self, netlist_file, cell_lib):
        """Initialize the ParsedVerilog by parsing a source file

        :param netlist_file: Path to a verilog file
        :type netlist_file: str
        :param cell_lib: parsed cell library
        :type cell_lib: object
        :return: A new ParsedVerilog file
        :rtype: parsed_verilog.ParsedVerilog

        :ivar netlist_file_path: The netlist file this object was parsed from
        :ivar cell_lib: The cell library this object was parsed with.
        :ivar graph: 
        """
        self.netlist_file_path = netlist_file
        self.cell_lib = cell_lib
        self.graph, self.nets, self.nodes, self.node_types, self.module_name = self.parseVerilogToData(
            netlist_file, cell_lib
        )  # FIXME: Better return names for global lookup

        self.nets_to_nodes = self.rev_lookup(self.nodes[1])

    @staticmethod
    def get_graph_with_types_in_names(graph, node_types):
        """Prepend node types for all non I/O nodes that do not have that name already

        This operation is quite expensive. Consider
        using :py:func:`get_networkx_graph` with the `node_types` option set.

        :param graph: graph to operate on
        :type graph: dict
        :param node_types: node_types dict for graph
        :type graph: dict
        :return: returns a dict adjlist graph where anonymous nodes are prepended with their node types
        :rtype: dict
        """

        old_node_new_node = {}

        import copy
        new_graph = copy.deepcopy(graph)

        for node in graph:
            if node.startswith("INPUT_") or node.startswith("OUTPUT_"):
                continue
            if node_types[node] in node:
                continue
            old_node_new_node[node] = node_types[node] + node

        for old_node, new_node in old_node_new_node.items():
            new_graph[new_node] = new_graph.pop(old_node)

        for _, adjlist in new_graph.items():
            adjlist[:] = [old_node_new_node[old_node] if old_node in old_node_new_node else old_node for old_node in adjlist]

        return new_graph

    @staticmethod
    def get_networkx_graph(graph, node_types=None, node_celltype_attr_name="node_type"):
        """Convert the adjlist-dict to a networkx graph

        .. note::

            This imports networkx!
        
        :param graph: adjlist as returned from parseVerilogToData()
        :type graph: dict[str, list[str]]
        :param node_types: Dictionary of nodes and their cell types, as returned from parseVerilogToData(), defaults to None
        :type node_types: dict[str, str], optional
        :param node_celltype_attr_name: Name of the attribute added to the nx graph, defaults to "node_type"
        :type node_celltype_attr_name: str, optional
        :return: returns a :py:class:`networkx.DiGraph` representing the netlist
        :rtype: networkx.DiGraph
        """

        import networkx as nx

        if node_types is not None:
            G = nx.DiGraph(graph)
            nx.set_node_attributes(G, node_types, name=node_celltype_attr_name)
            return G
        else:
            return nx.DiGraph(graph)


    @staticmethod
    def rev_lookup(nodes_lookup):
        """Generate a dictionary of driving nodes for nets by reversing the nodes dictionary.

        :param nodes_lookup: dictionary of nodes
        :type nodes_lookup: dict
        :return: dictionary mapping nets to driving nodes
        :rtype: dict
        """
        ###FIXME: gnd and vdd nodes?
        net_to_node_lookup = {}
        # fixme
        output = 0  # only one output per node

        for inst in nodes_lookup:

            net = nodes_lookup[inst]["dest"][output][1]

            net_to_node_lookup[net] = inst
        return net_to_node_lookup

    @staticmethod
    def parseVerilogToData(verilog_file, cell_lib):
        """parses the verilog file two times:

        1) all nets and thier destination are retrieved
        2) all nodes are scanned for thier connections

        returns:
            graph: Dct {Node_name: [List of Destinations]
            nets: Dict {netname : [List of Destinations]
            nodes: Dict {Node_name : [List of outputs]
        """

        # first build nets
        module_name, in_nodes, out_nodes, nodes, nets, net_drivers = ParsedVerilog.build_nets(verilog_file, cell_lib)

        # then build nodes
        graph, node_types = ParsedVerilog.build_nodes(verilog_file, nodes, nets, cell_lib, in_nodes, net_drivers, out_nodes)

        return graph, nets, (in_nodes, nodes, out_nodes), node_types, module_name

    @staticmethod
    def build_nets(verilog_file_path, cell_lib):

        in_nodes = {}
        out_nodes = {}
        nodes = {}
        nets = {}
        net_drivers = {}

        module_name = None
        comment_remover = VerilogCommentRemover()
        multiline_joiner = VerilogMultilineJoiner(verilog_file_path)
        # node_joiner = VerilogInstanceStatementJoiner(verilog_file_path, ParsedVerilog.AddNet_helper)
        assign_later = []

        with open(verilog_file_path, "r") as v_file:

            for i, line in enumerate(v_file):
                line = line.strip()
                line = comment_remover.handle_comments(line)
                line = multiline_joiner.handle_line(line)
                if not line:
                    continue
                elif line.startswith("module"):
                    if module_name is not None:
                        raise ASTParsingError.old_api(
                            verilog_file_path,
                            line,
                            i,
                            "Multiple Modules in one file."
                        )
                    module_name_match = MODULE_NAME_RE.match(line)
                    if not module_name_match:
                        raise ASTParsingError.old_api(
                            verilog_file_path,
                            line,
                            i,
                            "Module line without a module name."
                        )
                    module_name = module_name_match[1]
                elif line.startswith("endmodule"):
                    continue
                elif line.startswith("input "):
                    net, node = ParsedVerilog.create_nets_expl(
                        line,
                        "input ",
                        net_drivers,
                        verilog_file_path,
                        i
                    )
                    nets.update(net)

                    in_nodes.update(node)

                elif line.startswith("output "):
                    net, node = ParsedVerilog.create_nets_expl(
                        line,
                        "output ",
                        net_drivers,
                        verilog_file_path,
                        i
                    )
                    nets.update(net)

                    out_nodes.update(node)
                elif line.startswith("wire "):
                    # net, node = create_nets_expl(line, "wire ")
                    # nets.update(net)
                    # nodes.update(node)
                    continue
                elif line.startswith("inout"):
                    raise ASTParsingError.old_api(
                        verilog_file_path,
                        line,
                        i,
                        "inouts are not supported"
                    )
                elif line.startswith("assign"):
                    # fixme: horrible horrible horrible hack
                    # basically, just a wire between inst and net name
                    matches = PARSE_ASSIGN_RE.match(line)
                    if not matches:
                        raise ASTParsingError.old_api(
                            verilog_file_path,
                            line,
                            i,
                            "Assign statement not parseable."
                        )
                    a_dest_name = matches.group("a_dest")
                    a_src_name = matches.group("a_src")
                    if not CONST_EXPRESSION_RE.fullmatch(a_src_name):
                        # Postpone this assignment after everything else has been parsed:
                        assign_later.append((line, i, a_dest_name, a_src_name))
                    else:
                        glogger.warning(
                            "Constant assignments not supported by parsing. "
                            "This is not a problem, if the assignment only "
                            "handles the `gnd` and `vdd` wires, as you can "
                            "later identify these nets by yourself. "
                            "Assignment '{}' in '{}':{} will be ignored!".format(
                                str(line).strip(),
                                verilog_file_path,
                                i
                            )
                        )

                else:
                    # else we have an instantiation statement:
                    ParsedVerilog.AddNet_helper(line, verilog_file_path, i, nets, nodes, cell_lib, net_drivers)

        for line, i, a_dest_name, a_src_name in assign_later:
            o_name = "OUTPUT_" + a_dest_name
            if o_name in out_nodes:
                if a_src_name not in nets:
                    nets[a_src_name] = [o_name]
                else:
                    nets[a_src_name].append(o_name)
                # important: update out_nodes here, else the net names don't match up
                pin_name = out_nodes[o_name]["src"][0][0]
                out_nodes[o_name]["src"].remove((pin_name, a_dest_name))
                out_nodes[o_name]["src"].append((pin_name, a_src_name))
            else:
                # a_dest_name is not an Output. Treat a_dest_name as an alias of a_src_name.
                # Thus, the driver of a_src_name shall be the driver of a_dest_name.
                # And anything driven by a_dest_name is now driven by a_src_name.
                #
                # In this stage, we only have the nets and the individual nodes, so
                # we only have to update the src of all nodes driven by a_dest_name,
                # and check if any node already drives a_dest_name
                if a_dest_name in net_drivers:
                    raise ASTParsingError.old_api(verilog_file_path, line, i, "Assignment invalid. Assigning a net to an already driven net.")
                # get nodes driven by a_dest_name
                nodes_list = nets.get(a_dest_name, [])
                for node in nodes_list:
                    info = nodes[node]
                    for pin, src in info["src"]:
                        if src == a_dest_name:
                            # this node is driven by a_dest_name. Shall now be driven by a_src_name
                            info["src"].remove((pin, src))
                            info["src"].append((pin, a_src_name))
                # alias a_dest_name and a_src_name by merging their driven nodes:
                new_driven_nodes = [node for node in nodes_list if node not in nets[a_src_name]]
                new_driven_nodes.extend(nets.get(a_src_name, []))
                # do not modify self.nets[a_dest_name] here, we need to know which nodes are
                # driven by a_dest_name
                nets[a_src_name] = new_driven_nodes

        return module_name, in_nodes, out_nodes, nodes, nets, net_drivers

    @staticmethod
    def build_nodes(verilog_file, nodes, nets, cell_lib, in_nodes, net_divers, out_nodes):
        node_types = {}
        graph = {}

        comment_remover = VerilogCommentRemover()
        multiline_joiner = VerilogMultilineJoiner(verilog_file)
        # node_joiner = VerilogInstanceStatementJoiner(verilog_file, ParsedVerilog.AddNode_helper)
        assign_later = []

        with open(verilog_file, "r") as v_file:

            for i, line in enumerate(v_file):
                line = line.strip()
                line = comment_remover.handle_comments(line)
                line = multiline_joiner.handle_line(line)
                if not line:
                    continue
                elif line.startswith("module") or line.startswith("endmodule"):
                    continue
                elif line.startswith("input "):
                    try:
                        graph = ParsedVerilog.AddInput(graph, line, nets, cell_lib)
                    except ValueError as e:
                        if e.args[0].endswith("not connected in the graph."):
                            # input is not connected => delete from nets and nodes:
                            net_name = e.args[1]
                            node_name = e.args[2]
                            nets.pop(net_name)
                            in_nodes.pop(node_name)
                        else:
                            raise e

                elif line.startswith("output "):
                    graph = ParsedVerilog.AddOutput(graph, line, nets, cell_lib)
                elif line.startswith("wire "):
                    continue
                elif line.startswith("assign "):
                    # if assign, update graph:
                    matches = PARSE_ASSIGN_RE.match(line)
                    if not matches:
                        raise ASTParsingError.old_api(
                            verilog_file_path,
                            line,
                            i,
                            "Assign statement not parseable."
                        )
                    a_dest_name = matches.group("a_dest")
                    a_src_name = matches.group("a_src")
                    if not CONST_EXPRESSION_RE.fullmatch(a_src_name):
                        # Postpone this assignment after everything else has been parsed:
                        assign_later.append((line, i, a_dest_name, a_src_name))
                else:
                    graph = ParsedVerilog.AddNode_helper(
                        line, verilog_file, i, graph, nets, cell_lib, node_types
                    )

        for line, i, a_dest_name, a_src_name in assign_later:
            # we now have to build the graph for all nodes that are driven by
            # a_dest_name, because they are actually driven by a_src_name's driver
            nodes_list = nets.get(a_dest_name, [])
            for node in nodes_list:
                try:
                    info = nodes[node]
                except KeyError:
                    info = out_nodes[node]
                driver_node = net_drivers[a_src_name]
                # build path from a_src_name's driver to node
                graph.setdefault(driver_node, []).append(node)

        return graph, node_types

    @staticmethod
    def create_nets_expl(line, prefix, net_drivers, verilog_file, lineno):
        """parses all nodes for explicitly declared wires/nets.
        That are "wire", "inputs" and "outputs". "inouts" are not supported"""
        if prefix.startswith("inout"):
            sys.exit("Inouts are not supported")

        nets = {}
        nodes = {}

        c_line = line[len(prefix):]
        c_line = c_line.rstrip(";\n")
        c_line = c_line.split(",")
        for c in c_line:
            if c.startswith("["):
                lh, rh = c.split(":")
                lh = lh.split("[")[1]
                rh, name = rh.split("]")

                name = name.strip()

                lh = int(lh)
                rh = int(rh)

                if lh < rh:
                    for x in range(lh, rh + 1):
                        net_name = name + "[" + str(x) + "]"
                        if prefix == "output ":
                            node_name = "OUTPUT_" + net_name
                            node_type = "PO"
                            node_dest = [("Y", None)]
                            node_src = [("A", net_name)]
                            nets.setdefault(net_name, []).append(node_name)
                        elif prefix == "input ":
                            node_name = "INPUT_" + net_name
                            node_type = "PI"
                            node_dest = [("Y", net_name)]
                            node_src = [("A", None)]
                            nets.setdefault(net_name, [])
                            if net_name in net_drivers:
                                raise ASTParsingError.old_api(
                                    verilog_file,
                                    line,
                                    lineno,
                                    "This instance drives a net ({}) that is already driven!".format(
                                        net_name
                                    )
                                )
                            net_drivers[net_name] = node_name
                        else:
                            nets.setdefault(net_name, [])
                        nodes.update(
                            {
                                node_name: {
                                    "cell_type": node_type,
                                    "dest": node_dest,
                                    "src": node_src,
                                }
                            }
                        )
                else:
                    for x in range(rh, lh + 1):
                        net_name = name + "[" + str(x) + "]"
                        if prefix == "output ":
                            node_name = "OUTPUT_" + net_name
                            node_type = "PO"
                            node_dest = [("Y", None)]
                            node_src = [("A", net_name)]
                            nets.setdefault(net_name, []).append(node_name)
                        elif prefix == "input ":
                            node_name = "INPUT_" + net_name
                            node_type = "PI"
                            node_dest = [("Y", net_name)]
                            node_src = [("A", None)]
                            nets.setdefault(net_name, [])
                        else:
                            nets.setdefault(net_name, [])
                        nodes.update(
                            {
                                node_name: {
                                    "cell_type": node_type,
                                    "dest": node_dest,
                                    "src": node_src,
                                }
                            }
                        )
            else:
                net_name = c.strip()  # JB
                if prefix == "output ":
                    node_name = "OUTPUT_" + net_name
                    node_type = "PO"
                    node_dest = [("Y", None)]
                    node_src = [("A", net_name)]
                    nets.setdefault(net_name, []).append(node_name)
                elif prefix == "input ":
                    node_name = "INPUT_" + net_name
                    node_type = "PI"
                    node_dest = [("Y", net_name)]
                    node_src = [("A", None)]
                    nets.setdefault(net_name, [])
                else:
                    nets.setdefault(net_name, [])

                nodes.update(
                    {
                        node_name: {
                            "cell_type": node_type,
                            "dest": node_dest,
                            "src": node_src,
                        }
                    }
                )
            ## careful, return in for loop #return is now no longer in for loop - don't know why this was originally done.
        return nets, nodes

    @staticmethod
    def create_nets_impl(line, cell_lib, net_drivers):
        """parses all nodes for implicitly declared wires/nets"""
        nets = {}
        nodes = {}

        line = line.strip()
        matches = MODULE_INSTANTIATION_LINE_RE.match(line)
        cell_name = matches.group("cell_name")
        inst_name = matches.group("inst_name")
        connections = matches.group("connections")
        matches = CONNECTIONS_RE.finditer(connections)

        node_src = []
        node_dest = []

        for match in matches:
            pin_name = match.group("pin_name")
            net_name = match.group("net_name")
            # ~ input()
            if cell_lib[cell_name][pin_name]["direction"] == "input":
                nets.setdefault(net_name, []).append(inst_name)
                node_src.append((pin_name, net_name))
            elif cell_lib[cell_name][pin_name]["direction"] == "output":
                node_dest.append((pin_name, net_name))
                if net_name in net_drivers:
                    raise ASTParsingError.old_api(
                        "",
                        line,
                        "",
                        "This instance drives a node that is already driven!"
                    )
                net_drivers[net_name] = inst_name

            else:
                raise ASTParsingError.old_api(
                    "",
                    line,
                    "",
                    "Cell lib for instance {} of type {} has other direction than input or output for pin {}".format(
                        inst_name,
                        cell_name,
                        pin_name,
                    ))
                pass

        nodes = {
            inst_name: {"cell_type": cell_name, "dest": node_dest, "src": node_src}
        }
        return nets, nodes

    @staticmethod
    def AddNode(graph, line, net_dict, cell_lib):
        """Helper function to add a node to the graph"""
        line = line.strip()
        matches = MODULE_INSTANTIATION_LINE_RE.match(line)
        cell_name = matches.group("cell_name")
        inst_name = matches.group("inst_name")
        connections = matches.group("connections")
        matches = CONNECTIONS_RE.finditer(connections)

        for match in matches:
            pin_name = match.group("pin_name")
            net_name = match.group("net_name")
            if (
                cell_lib[cell_name][pin_name]["direction"] == "output"
                and not net_name.find("UNCONNECTED") >= 0
            ):
                try:
                    for dest in net_dict[net_name]:
                        graph.setdefault(inst_name, []).append(dest)
                except KeyError:
                    net_dict.setdefault(net_name, [])
                    graph.setdefault(inst_name, [])
                    glogger.warning(
                        "The pin {} of cell {} is connected to an unknown net {}. Added that net. Probably this pin is dangling!".format(
                            pin_name, inst_name, net_name
                        )
                    )

        return graph, {inst_name: cell_name}

    def AddInput(graph, line, net_dict, cell_lib):
        """Helper function to add primary inputs to the graph"""
        prefix = "input "
        c_line = line[len(prefix):]
        c_line = c_line.rstrip(";\n")
        c_line = c_line.split(",")
        for c in c_line:
            if c.startswith("["):
                lh, rh = c.split(":")
                lh = lh.split("[")[1]
                rh, name = rh.split("]")

                name = name.strip()

                lh = int(lh)
                rh = int(rh)
                if lh < rh:
                    for x in range(lh, rh + 1):
                        net_name = name + "[" + str(x) + "]"
                        node_name = "INPUT_" + net_name
                        for dest in net_dict[net_name]:
                            graph.setdefault(node_name, []).append(dest)

                else:
                    for x in range(rh, lh + 1):
                        net_name = name + "[" + str(x) + "]"
                        node_name = "INPUT_" + net_name
                        for dest in net_dict[net_name]:
                            graph.setdefault(node_name, []).append(dest)

            else:
                net_name = c.strip(" ")
                node_name = "INPUT_" + net_name
                destinations = net_dict[net_name]
                if destinations:
                    for dest in net_dict[net_name]:
                        graph.setdefault(node_name, []).append(dest)
                else:
                    # this is a dead, nonconnected input
                    raise ValueError(
                        "Error: input {} is not connected in the graph.".format(
                            net_name
                        ),
                        net_name,
                        node_name,
                    )
                    pass

        return graph

    def AddOutput(graph, line, net_dict, cell_lib):
        """ Helper function to add extra nodes for the primary outputs"""
        prefix = "output "
        c_line = line[len(prefix):]
        c_line = c_line.rstrip(";\n")
        c_line = c_line.split(",")
        for c in c_line:
            if c.startswith("["):
                lh, rh = c.split(":")
                lh = lh.split("[")[1]
                rh, name = rh.split("]")

                name = name.strip()

                lh = int(lh)
                rh = int(rh)

                if lh < rh:
                    for x in range(lh, rh + 1):
                        net_name = name + "[" + str(x) + "]"
                        node_name = "OUTPUT_" + net_name
                        graph.setdefault(node_name, [])

                else:
                    for x in range(rh, lh + 1):
                        net_name = name + "[" + str(x) + "]"
                        node_name = "OUTPUT_" + net_name
                        graph.setdefault(node_name, [])

            else:
                net_name = c.strip()  # JB
                node_name = "OUTPUT_" + net_name
                graph.setdefault(node_name, [])

        return graph

    @staticmethod
    def AddNet_helper(line, filename, lineno, nets, nodes, cell_lib, net_drivers):
        """Add the found net line to the nets and nodes dict"""
        try:
            net, node = ParsedVerilog.create_nets_impl(line, cell_lib, net_drivers)
        except BaseException as e:
            raise ASTParsingError.old_api(filename, line, lineno, e)
        for k, v in net.items():
            if k in nets:
                nets[k].extend(v)
            else:
                nets[k] = v
        nodes.update(node)

    @staticmethod
    def AddNode_helper(line, filename, lineno, graph, nets, cell_lib, node_types):
        """Add the found net line to the nets and nodes dict"""
        try:
            graph, node_type = ParsedVerilog.AddNode(graph, line, nets, cell_lib)
            node_types.update(node_type)
        except BaseException as e:
            raise ASTParsingError.old_api(filename, line, lineno, e)
        return graph
