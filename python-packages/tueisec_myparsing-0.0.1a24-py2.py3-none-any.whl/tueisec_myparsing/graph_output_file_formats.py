"""Module for graph output format specific functions

Allowed graph formats, output and input helpers.
"""

from enum import Enum
import itertools

import pandas as pd
import networkx as nx
import json
import os.path

import logging
import ast

glogger = logging.getLogger(__name__)

NODE_DATA_EXTENSION = ".npq"


class GraphOutputFormat(Enum):
    adjlist = ("txt", False)
    gexf = ("gexf", True)
    gml = ("gml", True)
    graphml = ("graphml", True)
    json = ("json", False)
    parquet = ("epq", False)
    simpleParquet = ("pq", False)
    gpickle = ("gpickle", False)


    def __new__(cls, ext, can_be_gzipped):
        """Create a new GraphOutputFormat enum value

        :param ext: Extension string
        :type ext: str
        :param can_be_gzipped: Can this format be gzipped (nx supports .gz?)
        :type can_be_gzipped: bool
        :return: A new Enum instance
        :rtype: GraphOutputFormat
        """
        obj = object.__new__(cls)
        obj._value_ = ext
        obj.can_be_gzipped = can_be_gzipped
        return obj

    def __str__(self):
        """String representation is file extension

        :return: extension string
        :rtype: str
        """
        return self.value

    def get_filename(self, filename, do_not_zip=False):
        """Get a complete filename with extension

        :param filename: filename without extension
        :type filename: str
        :param do_not_zip: if true, do not append .gz, thus networkx will not
            zip the output, defaults to False
        :type do_not_zip: bool, optional
        :return: filename with extension depending on enum value
        :rtype: str
        """
        if self.can_be_gzipped and not do_not_zip:
            return "{}.{}.gz".format(filename, self.value)
        else:
            return "{}.{}".format(filename, self.value)

    @classmethod
    def format_from_filename(cls, filename):
        """Create a appropriate Enum depending on a filename

        :param filename: filename or filepath with extension
        :type filename: str
        :raises ValueError: if filename ends with .gz but format does not support
            gzipping.
        :return: Enum with value depending on extension
        :rtype: GraphOutputFormat
        """
        first_ext_split = os.path.splitext(os.path.basename(filename))
        if first_ext_split[-1] != ".gz":
            return cls(first_ext_split[-1][1:])  # noqa: E1120
        else:
            second_ext_split = os.path.splitext(first_ext_split[0])
            potential_enum = cls(second_ext_split[-1][1:])
            if potential_enum.can_be_gzipped is False:
                raise ValueError(
                    "The graph format {} cannot be gzipped.".format(potential_enum)
                )
            return potential_enum

    def write_graph(self, graph, path, filename, do_not_zip=False):
        """Write a networkx graph in the right format

        :param graph: networkx graph
        :type graph: networkx.Graph
        :param path: foldername to store the graph
        :type path: str
        :param filename: filename without extension for the graph
        :type filename: str
        :param do_not_zip: if true, do not add .gz to the filename and thus do
            not allow networkx to gzip the output, defaults to False
        :type do_not_zip: bool, optional
        """
        output_filepath = os.path.join(path, self.get_filename(filename, do_not_zip))
        if self is GraphOutputFormat.simpleParquet:
            nx.to_pandas_edgelist(graph).to_parquet(
                output_filepath, engine="pyarrow", compression="snappy",
            )
        elif self is GraphOutputFormat.parquet:
            e = nx.to_pandas_edgelist(graph)
            e["function"] = e["function"].astype("str")
            e.to_parquet(
                output_filepath, engine="pyarrow", compression="snappy",
            )
            n = pd.DataFrame.from_records(
                [{"__id": id, **nodedata} for id, nodedata in graph.nodes(data=True)],
                index="__id",
            )
            n["nodeFunctions"] = n["nodeFunctions"].astype("str")
            n.to_parquet(
                os.path.splitext(output_filepath)[0] + NODE_DATA_EXTENSION,
                engine="pyarrow",
                compression="snappy",
            )
        elif self is GraphOutputFormat.json:
            with open(output_filepath, "w") as f:
                json.dump(nx.node_link_data(graph), f)
        elif self is GraphOutputFormat.gexf:
            nx.write_gexf(graph, output_filepath)
        elif self is GraphOutputFormat.gml:
            nx.write_gml(graph, output_filepath, stringizer=nx.readwrite.gml.literal_stringizer)
        elif self is GraphOutputFormat.graphml:
            nx.write_graphml(graph, output_filepath)
        elif self is GraphOutputFormat.adjlist:
            nx.write_adjlist(graph, output_filepath)
        elif self is GraphOutputFormat.gpickle:
            from packaging.version import Version
            if Version(nx.__version__) > Version("3.0"):
                import pickle
                with open(output_filepath, 'wb') as f:
                    pickle.dump(graph, f, pickle.HIGHEST_PROTOCOL)
            else:
                nx.write_gpickle(graph, output_filepath)

    def __read_graph(self, filepath):
        """Internal method to read a graph in the format of this enum

        :param filepath: path of the file. This enum shall already have the
            appropriate value corresponding to the extension of the filepath
        :type filepath: str
        :return: networkx graph as read from filepath
        :rtype: networkx.Graph
        """
        if self is GraphOutputFormat.simpleParquet:
            return nx.from_pandas_edgelist(
                pd.read_parquet(filepath, engine="pyarrow"), create_using=nx.DiGraph()
            )
        elif self is GraphOutputFormat.parquet:
            def f(x):
                try:
                    return ast.literal_eval(x)   
                except BaseException as e:
                    return x
            e = pd.read_parquet(filepath, engine="pyarrow")
            e["function"] = e["function"].apply(f)
            
            graph = nx.from_pandas_edgelist(
                e, create_using=nx.DiGraph()
            )
            node_data_filepath = os.path.splitext(filepath)[0] + NODE_DATA_EXTENSION
            if os.path.exists(node_data_filepath):
                n = pd.read_parquet(
                    node_data_filepath, engine="pyarrow"
                )
                n["nodeFunctions"] = n["nodeFunctions"].apply(f)
                node_data = n.to_dict("index")
                nx.set_node_attributes(graph, node_data)
            else:
                glogger.warning("No node_data found for file {}!".format(filepath))
            return graph
        elif self is GraphOutputFormat.json:
            with open(filepath, "r") as f:
                return nx.node_link_graph(json.load(f), directed=True)
        elif self is GraphOutputFormat.gexf:
            return nx.read_gexf(filepath)
        elif self is GraphOutputFormat.gml:
            return nx.read_gml(filepath, destringizer=nx.readwrite.gml.literal_destringizer)
        elif self is GraphOutputFormat.graphml:
            return nx.read_graphml(filepath)
        elif self is GraphOutputFormat.adjlist:
            return nx.read_adjlist(filepath, create_using=nx.DiGraph)
        elif self is GraphOutputFormat.gpickle:
            from packaging.version import Version
            if Version(nx.__version__) > Version("3.0"):
                import pickle
                with open(filepath, 'rb') as f:
                    G = pickle.load(f)
                return G
            else:
                return nx.read_gpickle(filepath)

    @staticmethod
    def read_graph_from_filepath(filepath):
        """Public method to read a nx graph from file.

        This will first determine an appropriate enum value and then read the
        file into a networkx graph.

        :param filepath: filepath to read the graph from
        :type filepath: str
        :return: networkx graph as read from filepath
        :rtype: networkx.Graph
        """
        form = GraphOutputFormat.format_from_filename(filepath)
        return form.__read_graph(filepath)

    @staticmethod
    def known_extensions_globs():
        """Return globs for files with all known extensions as a generator

        :return: generator of all known extensions in the form "*.<ext>"
        :rtype: Generator
        """
        zippables = ("*.{}.gz".format(v) for v in GraphOutputFormat if v.can_be_gzipped)
        all_extensions = ("*.{}".format(v) for v in GraphOutputFormat)
        return itertools.chain(all_extensions, zippables)
