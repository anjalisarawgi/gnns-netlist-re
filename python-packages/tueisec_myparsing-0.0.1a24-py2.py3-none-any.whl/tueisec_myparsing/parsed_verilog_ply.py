import logging

import copy

from tueisec_myparsing import synthed_verilog_parser
from tueisec_myparsing.pool_wrapper import draw_progress_bar
from tueisec_myparsing.synthed_verilog_ast import (
    Assign,
    Decl,
    Identifier,
    Input,
    Instance,
    IntConst,
    ModuleDef,
    Output,
    Partselect,
    Wire,
    Lvalue,
    Rvalue,
)

import networkx as nx

from .verilog_parsing_errors import ASTParsingError

glogger = logging.getLogger(__name__)


class ParsedVerilog(object):
    """Object representing a verilog file.

    :ivar module_name: Name of the parsed module
    :ivar nets: Dict containing a list of driven nodes for each net:
        :pycode:`["net_a": ["AND2X1", "DFFPOSX1" ...], "net_b": ...]`
    :ivar nets_to_nodes: Dict mapping net names to the net driver, generated at end.
    :ivar netlist_file_path: Path of the parsed file
    :ivar cell_lib: cell_lib object corresponding to this netlist
    :ivar nodes: Tuple of node information:
        :pycode:`(in_nodes, nodes, out_nodes)`, where each is a list of nodes.
        each node is a dict of::

            inst_name: {
                "cell_type": cell_name,
                "dest": node_dest,
                "src": node_src
            }

        and dest and src are lists of pin tuples like::

            (pin_name, net_name)

    :ivar node_types: Simplified nodes dict only containing node-to-cell_type mapping
    :ivar graph: Netlist graph as a dictionary adjacency list.
        For each node, there is a list of destination nodes.

    """

    def __init__(
        self,
        netlist_file,
        cell_lib,
        debug_ply=False,
        add_const_as_input=False,
        show_all_const_warnings=False,
        delete_unconnected_inputs=True,
    ):
        """Initialize the ParsedVerilog by parsing a source file

        :param netlist_file: Path to a verilog file
        :type netlist_file: str
        :param cell_lib: parsed cell library
        :type cell_lib: object
        :param debug_ply: Enable debug output from ply parsing, defaults to False
        :type debug_ply: bool, optional
        :param show_all_const_warnings: Enable all warnings for constants which are not added as an input
        :type show_all_const_warnings: bool, optional, default=false
        :param add_const_as_input: If enabled, phantom inputs :term:`INPUT_CONSTANT_0` and
            :term:`INPUT_CONSTANT_1` will be added to the netlist inputs. Any 1-bit
            constants in standard cell ports or in rhs of assign statements will
            be replaced by the respective phantom input, so that an additional
            wire goes from the input to the standard cell or assignment lhs.
            Defaults to ``False``, which triggers warnings if constant assignments
            are found. You can hide these warnings with a :py:class:`logging.Filter`,
            see :doc:`../../usage`.

            .. note::

                CLI: At the moment, this is only supported in the cli tool
                :py:mod:`verilog2graph <tueisec_myparsing.cli.verilog2graph>`,
                if you specify ``--output_info complete_data``.
        :type add_const_as_input: bool, optional
        :param delete_unconnected_inputs: If enabled, any inputs that are not
            connected to a cell will be deleted, i.e. even the `INPUT_` dummy cell
            is thrown away.
        :return: A new ParsedVerilog object
        :rtype: tueisec_myparsing.parsed_verilog_ply.ParsedVerilog
        """

        self._add_const_as_input = add_const_as_input    
        self._show_all_const_warnings = show_all_const_warnings
        self._const_warning_occured = False
        self.delete_unconnected_inputs = delete_unconnected_inputs

        self._graph_with_types_in_names = None

        self.netlist_file = netlist_file
        self.cell_lib = cell_lib

        self.ast, self.directives = synthed_verilog_parser.parse(
            netlist_file, debug=debug_ply
        )
        glogger.info("AST-Parsed '{}'".format(netlist_file))

        try:
            self.parse_ast_to_self(self.ast)
        except ASTParsingError:
            raise
        except BaseException as e:
            raise ASTParsingError(self.netlist_file, None, e)

        glogger.info("obj-Parsed '{}'".format(netlist_file))

        self.nets_to_nodes = self.rev_lookup(self.nodes[1])

    def get_graph_with_types_in_names(self, cached=True):
        """Prepend node types for all non I/O nodes that do not have that name already

        This operation is quite expensive, that's why this calculation is cached. Consider
        using :py:func:`get_networkx_graph` with the `node_types` option set.

        :param cached: Use the cached graph if available, defaults to True
        :type cached: bool, optional
        :return: returns a dict adjlist graph where anonymous nodes are prepended
            with their node types
        :rtype: dict
        """
        if self._graph_with_types_in_names is not None and cached:
            return self._graph_with_types_in_names

        old_node_new_node = {}

        import copy

        new_graph = copy.deepcopy(self.graph)

        for node in self.graph:
            if node.startswith("INPUT_") or node.startswith("OUTPUT_"):
                continue
            if self.node_types[node] in node:
                continue
            old_node_new_node[node] = self.node_types[node] + node

        for old_node, new_node in old_node_new_node.items():
            new_graph[new_node] = new_graph.pop(old_node)

        for _, adjlist in new_graph.items():
            adjlist[:] = [
                old_node_new_node[old_node]
                if old_node in old_node_new_node
                else old_node
                for old_node in adjlist
            ]

        self._graph_with_types_in_names = new_graph
        return new_graph

    def find_inpins(self, edge, net):
        if edge[1].startswith("OUTPUT"):
            # assumption: output only has one inpin
            inpin = self.nodes[2][edge[1]]["src"][0][0]
            innum = 1

        else:
            inpin = []
            for pin in self.nodes[1][edge[1]]["src"]:
                if pin[1] == net:
                    inpin.append(pin[0])
            if len(inpin) == 0:
                raise ASTParsingError(
                    self.netlist_file,
                    edge,
                    "Could not find inpin for this edge, as no in pin of "
                    "the destination node is connected to the net this "
                    "edge belongs to.",
                )
            innum = len(self.nodes[1][edge[1]]["src"])
        return inpin, innum

    def add_edge_data_multi(self, G, graph_attribute_names=None):
        """For each edge in the graph, add attributes such as begin and end ports,
            output port function, etc. The graph must be a multiedge_graph.

        :param G: graph to add data to
        :type G: nx.DiGraph
        :return: returns changed graph
        :rtype: nx.DiGraph
        """

        if graph_attribute_names is None:
            graph_attribute_names = {
                "edge_inpin": "inpin",
                "edge_outpin": "outpin",
                "edge_net": "net",
                "edge_function": "function",
                "edge_fffunction": "fffunction",
                "edge_innum": "innum",
                "edge_outnum": "outnum",
            }

        initedges = [(edge[0], edge[1]) for edge in G.edges()]
        doneedges = set()

        for edge in initedges:
            if edge in doneedges:
                continue
            doneedges.add(edge)
            nets = []
            # find outpin
            if edge[0].startswith("INPUT"):
                outpin = self.nodes[0][edge[0]]["dest"][0][0]
                net = self.nodes[0][edge[0]]["dest"][0][1]
                outnum = 1
                function = ""
                inpin, innum = self.find_inpins(edge, net)
                nets.append(
                    {
                        graph_attribute_names["edge_net"]: net,
                        graph_attribute_names["edge_outpin"]: outpin,
                        graph_attribute_names["edge_outnum"]: outnum,
                        graph_attribute_names["edge_function"]: function,
                        graph_attribute_names["edge_inpin"]: inpin,
                        graph_attribute_names["edge_innum"]: innum,
                    }
                )
            else:
                outpin_found = False
                for pin in self.nodes[1][edge[0]]["dest"]:
                    driven_net = pin[1]
                    if driven_net.find("UNCONNECTED") >= 0:
                        continue
                    try:
                        if edge[1] in self.nets[driven_net]:
                            outpin_found = True
                            outpin = pin[0]
                            net = pin[1]
                            outnum = len(self.nodes[1][edge[0]]["dest"])
                            # edge function should be something useful for DFFs
                            if (
                                self.cell_lib[self.node_types[edge[0]]].get("ff")
                                is not None
                            ):
                                # the edge starts at a flipflop.
                                function = {
                                    graph_attribute_names[
                                        "edge_fffunction"
                                    ]: self.cell_lib[self.node_types[edge[0]]][outpin][
                                        "function"
                                    ],
                                    **self.cell_lib[self.node_types[edge[0]]]["ff"],
                                }
                            elif (
                                self.cell_lib[self.node_types[edge[0]]].get("latch")
                                is not None
                            ):
                                function = {
                                    graph_attribute_names[
                                        "edge_latchfunction"
                                    ]: self.cell_lib[self.node_types[edge[0]]][outpin][
                                        "function"
                                    ],
                                    **self.cell_lib[self.node_types[edge[0]]]["latch"],
                                }
                            else:
                                function = self.cell_lib[self.node_types[edge[0]]][
                                    outpin
                                ]["function"]
                            inpin, innum = self.find_inpins(edge, net)
                            nets.append(
                                {
                                    graph_attribute_names["edge_net"]: net,
                                    graph_attribute_names["edge_outpin"]: outpin,
                                    graph_attribute_names["edge_outnum"]: outnum,
                                    graph_attribute_names["edge_function"]: function,
                                    graph_attribute_names["edge_inpin"]: inpin,
                                    graph_attribute_names["edge_innum"]: innum,
                                }
                            )
                    except KeyError:
                        raise ASTParsingError(
                            self.netlist_file,
                            edge,
                            "Could not find outpin for this edge, as net {} not known.".format(
                                driven_net
                            ),
                        )
                if not outpin_found:
                    raise ASTParsingError(
                        self.netlist_file,
                        edge,
                        "Could not find outpin for this edge, as no net belongs to "
                        "this edge.",
                    )

            # for each edge in nets, add data to the edge or create a new one.
            # the first edge always exists

            c = len(G[edge[0]][edge[1]]) - len(nets)
            for i in range(c):
                G.remove_edge(edge[0], edge[1])

            for net, g_net_id in zip(nets, G[edge[0]][edge[1]]):
                G.add_edge(edge[0], edge[1], key=g_net_id, **net)

        return G

    def add_edge_data(self, G, graph_attribute_names=None):
        """For each edge in the graph, add attributes such as begin and end ports,
            output port function, etc.

        :param G: graph to add data to
        :type G: nx.DiGraph
        :return: returns changed graph
        :rtype: nx.DiGraph
        """

        if graph_attribute_names is None:
            graph_attribute_names = {
                "edge_inpin": "inpin",
                "edge_outpin": "outpin",
                "edge_net": "net",
                "edge_function": "function",
                "edge_fffunction": "fffunction",
                "edge_latchfunction": "latchfunction",
                "edge_innum": "innum",
                "edge_outnum": "outnum",
            }

        for edge in G.edges():
            # find outpin
            if edge[0].startswith("INPUT"):
                outpin = self.nodes[0][edge[0]]["dest"][0][0]
                net = self.nodes[0][edge[0]]["dest"][0][1]
                outnum = 1
                function = ""
            else:
                outpin = None
                for pin in self.nodes[1][edge[0]]["dest"]:
                    driven_net = pin[1]
                    if driven_net.find("UNCONNECTED") >= 0:
                        continue
                    try:
                        if edge[1] in self.nets[driven_net]:
                            outpin = pin[0]
                            net = pin[1]
                            break
                    except KeyError:
                        raise ASTParsingError(
                            self.netlist_file,
                            edge,
                            "Could not find outpin for this edge, as net {} not known.".format(
                                driven_net
                            ),
                        )
                if outpin is None:
                    raise ASTParsingError(
                        self.netlist_file,
                        edge,
                        "Could not find outpin for this edge, as no net belongs to "
                        "this edge.",
                    )
                outnum = len(self.nodes[1][edge[0]]["dest"])
                # edge function should be something useful for DFFs
                if self.cell_lib[self.node_types[edge[0]]].get("ff") is not None:
                    # the edge starts at a flipflop.
                    function = {
                        graph_attribute_names["edge_fffunction"]: self.cell_lib[
                            self.node_types[edge[0]]
                        ][outpin]["function"],
                        **self.cell_lib[self.node_types[edge[0]]]["ff"],
                    }
                elif self.cell_lib[self.node_types[edge[0]]].get("latch") is not None:
                    function = {
                        graph_attribute_names["edge_latchfunction"]: self.cell_lib[
                            self.node_types[edge[0]]
                        ][outpin]["function"],
                        **self.cell_lib[self.node_types[edge[0]]]["latch"],
                    }
                else:
                    function = self.cell_lib[self.node_types[edge[0]]][outpin].get(
                        "function",
                        ""
                    )

            # find inpin of desitantion node
            inpin, innum = self.find_inpins(edge, net)

            G.edges[edge[0], edge[1]][graph_attribute_names["edge_inpin"]] = list(inpin)
            G.edges[edge[0], edge[1]][graph_attribute_names["edge_outpin"]] = outpin
            G.edges[edge[0], edge[1]][graph_attribute_names["edge_net"]] = net
            G.edges[edge[0], edge[1]][graph_attribute_names["edge_function"]] = function
            G.edges[edge[0], edge[1]][graph_attribute_names["edge_innum"]] = innum
            G.edges[edge[0], edge[1]][graph_attribute_names["edge_outnum"]] = outnum
        return G

    def generate_node_functions_dict(self):
        return {
            **{node: "INPUT" for node in self.nodes[0]},
            **{node: "OUTPUT" for node in self.nodes[2]},
            **{
                node: str(
                    [
                        (
                            pin,
                            {
                                "fffunction": self.cell_lib[self.node_types[node]][pin][
                                    "function"
                                ],
                                **self.cell_lib[self.node_types[node]]["ff"],
                            },
                        )
                        if self.cell_lib[self.node_types[node]].get("ff") is not None
                        else (
                            pin,
                            {
                                "latchfunction": self.cell_lib[self.node_types[node]][
                                    pin
                                ]["function"],
                                **self.cell_lib[self.node_types[node]]["latch"],
                            },
                        )
                        if self.cell_lib[self.node_types[node]].get("latch") is not None
                        else (
                            pin,
                            self.cell_lib[self.node_types[node]][pin].get("function", ""),
                        )
                        for pin, _ in self.nodes[1][node]["dest"]
                    ]
                )
                for node in self.nodes[1]
            },
        }

    def get_networkx_graph(
        self,
        node_types=None,
        complete=None,
        node_celltype_attr_name="node_type",
        graph_attribute_names=None,
        multidigraph=False,
    ):
        """Convert the adjlist-dict to a networkx graph

        .. note::

            This imports networkx!

        :param node_types: Set to anything that is not None to add a node attribute
            representing node type to each node in graph, defaults to None
        :type node_types: Any, optional
        :param complete: Set to anything that is not None to add as much info as
            possible to the graph, defaults to None
        :type complete: Any, optional
        :param node_celltype_attr_name: Name of the attribute added to the nx
            graph, defaults to "node_type"
        :type node_celltype_attr_name: str, optional
        :param graph_attribute_names: Dict of names of graph attributes to set.
            Replaces `node_celltype_attr_name`.
        :type graph_attribute_names: dict, optional
        :param multidigraph: If true, return a multidigraph and allow multiple
            output pins to drive the same cell. This attribute is only allowed
            if `complete is not None`. Defaults to False.
        :type multidigraph: bool, optional
        :return: returns a :py:class:`networkx.DiGraph` representing the netlist.
            May return a :py:class:`networkx.MultiDiGraph`, if `multidigraph == True`.
        :rtype: networkx.DiGraph or networkx.MultiDiGraph
        """

        import networkx as nx

        if graph_attribute_names is None:
            graph_attribute_names = {
                "node_type": "nodeType",
                "node_functions": "nodeFunctions",
                "edge_inpin": "inpin",
                "edge_outpin": "outpin",
                "edge_net": "net",
                "edge_function": "function",
                "edge_fffunction": "fffunction",
                "edge_latchfunction": "latchfunction",
                "edge_innum": "innum",
                "edge_outnum": "outnum",
            }

        if multidigraph and complete is None:
            raise ValueError(
                "`multidigraph` can only be `True` if `complete is not None`"
            )

        if node_celltype_attr_name != "node_type":
            raise ValueError(
                "node_celltype_attr_name is not supported any more."
                "Plese specify attr names with the graph_attribute_names"
                "dict."
            )
        if node_types is not None:
            G = nx.DiGraph(self.graph)
            nx.set_node_attributes(
                G, self.node_types, name=graph_attribute_names["node_type"]
            )
            return G
        elif complete is not None:
            if multidigraph:
                G = nx.MultiDiGraph(self.graph)
                self.add_edge_data_multi(G, graph_attribute_names)
            else:
                G = nx.DiGraph(self.graph)
                self.add_edge_data(G, graph_attribute_names)
            nx.set_node_attributes(
                G, self.node_types, name=graph_attribute_names["node_type"]
            )
            node_functions = self.generate_node_functions_dict()
            nx.set_node_attributes(
                G, node_functions, name=graph_attribute_names["node_functions"]
            )
            return G
        else:
            return nx.DiGraph(self.graph)

    def parse_ast_to_self(self, ast):
        """Parses the verilog ast 2 times to get the dictionaries

        1. all nets and their destination are retrieved
        2. all nodes are scanned for their connections

        :param ast: the ast to parse
        :type ast: synthed_verilog_ast.Source
        """
        for definition in ast.description.definitions:
            if isinstance(definition, ModuleDef):
                module = definition
                # first build nets
                self.build_nets(module)

                # then build nodes
                self.build_nodes(module)

            else:
                glogger.warning(
                    "Skipping the following pragma definition: {}".format(definition)
                )

    # def parse_ast_to_data(self, ast, netlist_file, cell_lib):
    #     """ parses the verilog file two times:
    #         1) all nets and their destination are retrieved
    #         2) all nodes are scanned for their connections
    #         returns:
    #             graph: Dict {Node_name: [List of Destinations]
    #             nets: Dict {netname : [List of Destinations]
    #             nodes: Dict {Node_name : [List of outputs]
    #         """
    #     for definition in ast.description.definitions:
    #         if isinstance(definition, ModuleDef):
    #             module = definition
    #             # first build nets
    #             module_name, in_nodes, out_nodes, nodes, nets = ParsedVerilog.build_nets(
    #                 module, netlist_file, cell_lib
    #             )

    #             # then build nodes
    #             graph, node_types = ParsedVerilog.build_nodes(
    #                 module, nets, in_nodes, netlist_file, cell_lib
    #             )

    #             return (
    #                 graph,
    #                 nets,
    #                 (in_nodes, nodes, out_nodes),
    #                 node_types,
    #                 module_name,
    #             )
    #         else:
    #             glogger.warning(
    #                 "Skipping the following pragma definition: {}".format(definition)
    #             )

    def build_nets(self, module):
        self.in_nodes = {}
        self.out_nodes = {}
        self.other_nodes = {}
        self.nets = {}
        self.bus_nets = {}
        self.net_drivers = {}

        self.module_name = module.name
        assign_later = []

        item_len = len(module.items)
        glogger.debug("Processing nets for {}".format(self.netlist_file))

        for i, item in enumerate(module.items):
            if glogger.getEffectiveLevel() == logging.DEBUG:
                draw_progress_bar(i / item_len)
            if isinstance(item, Decl):
                for decl in item.list:
                    try:
                        self.create_nets_expl(decl)
                    except ASTParsingError:
                        raise
                    except BaseException as e:
                        raise ASTParsingError(self.netlist_file, decl, e)
            elif isinstance(item, Assign):
                # basically, just a wire between inst and net name
                if isinstance(item.right.var, Partselect):
                    if item.right.var.msb != item.right.var.lsb:
                        raise ASTParsingError(
                            self.netlist_file,
                            item,
                            "Multi-bit assignments of buses are not supported. Please "
                            "file an issue if you need that.",
                        )
                elif isinstance(item.right.var, Identifier):
                    pass
                elif isinstance(item.right.var, IntConst):
                    if item.right.var.bits() > 1:
                        raise ASTParsingError(
                            self.netlist_file,
                            item,
                            "Assignments larger than one bit are not supported.",
                        )
                    else:
                        if not self._add_const_as_input:
                            if self._show_all_const_warnings:
                                glogger.warning(
                                    "Constant one bit assignments not supported by "
                                    "parsing if you do not enable 'add_const_as_input'. "
                                    "This is not a problem, if the assignment only "
                                    "handles the `gnd` and `vdd` wires, "
                                    "as cell functions should be parsed anyways. "
                                    "Assignment '{}' in '{}':{} will be ignored!".format(
                                        item, self.netlist_file, item.lineno
                                    )
                                )
                                continue
                            elif not self._const_warning_occured:
                                self._const_warning_occured = True
                                glogger.warning(
                                    "Constant one bit assignments not supported by "
                                    "parsing if you do not enable 'add_const_as_input'. "
                                    "This is not a problem, if the assignment only "
                                    "handles the `gnd` and `vdd` wires, "
                                    "as cell functions should be parsed anyways. "
                                    "ATTENTION: This type of warning will be suppressed"
                                    "from now on. If you want to show all warnings of this type"
                                    "you need to set 'show_all_const_warnings' to True. "
                                    "Assignment '{}' in '{}':{} will be ignored!".format(
                                        item, self.netlist_file, item.lineno
                                    )
                                )
                                continue
                if isinstance(item.left.var, Partselect):
                    if item.left.var.msb != item.left.var.lsb:
                        raise ASTParsingError(
                            self.netlist_file,
                            item,
                            "Assignments to multi-bit buses are not supported. Please "
                            "file an issue if you need that.",
                        )
                assign_later.append(item)
            elif isinstance(item, Instance):
                # else we have an instantiation statement:
                self.AddNet_helper(item)

        if glogger.getEffectiveLevel() == logging.DEBUG:
            draw_progress_bar(1)
            print()

        glogger.debug("Processing assigns@nets for {}".format(self.netlist_file))

        self.build_final_assign_chain(assign_later)

        glogger.debug("handling replace dict@nets for {}".format(self.netlist_file))

        self._handle_replace_dict_at_nets()

        if glogger.getEffectiveLevel() == logging.DEBUG:
            draw_progress_bar(1)
            print()

        self.nodes = (self.in_nodes, self.other_nodes, self.out_nodes)

    def build_final_assign_chain(self, assign_later):

        assign_len = len(assign_later)
        i = 0

        sig_replace = []
        self.assign_items_dict = {}

        for item in assign_later:
            i += 1
            if glogger.getEffectiveLevel() == logging.DEBUG:
                draw_progress_bar(i / assign_len)
            try:
                res = self._handle_assigns_at_nets(item)
                if res is not None:
                    sig_replace.append(res[0])
                    self.assign_items_dict[res[0][0]] = res[1]
            except BaseException as e:
                raise ASTParsingError(self.netlist_file, item, e)

        graph = nx.from_edgelist(sig_replace, create_using=nx.DiGraph)

        self.final_assign_chain = {}

        replace_origin = [node for node in graph.nodes() if graph.in_degree(node) == 0]
        replace_dest = [node for node in graph.nodes() if graph.in_degree(node) > 0]

        has_path_cache = dict(nx.all_pairs_shortest_path(graph))
        def has_path_cached(origin, dest):
            try:
                has_path_cache[origin][dest]
            except KeyError:
                return False
            else:
                return True

        for origin in replace_origin:
            all_d = [dest for dest in replace_dest if has_path_cached(origin, dest)]
            self.final_assign_chain[origin] = all_d

    def _handle_assigns_at_nets(self, item):
        a_dest_name = str(item.left.var)
        a_src_name = str(item.right.var)
        if isinstance(item.right.var, Partselect):
            o_name = "OUTPUT_" + a_dest_name
            i_name = "INPUT_" + a_src_name
            if o_name not in self.out_nodes or i_name not in self.in_nodes:
                # if assign does not connect input and output, we can enlist the
                # assign in the assign chain.
                return (a_src_name, a_dest_name), item
            else:
                # input and output are directly connected via assign. Handle that directly here.
                if a_src_name not in self.nets:
                    self.nets[a_src_name] = [o_name]
                else:
                    self.nets[a_src_name].append(o_name)
                # important: update out_nodes here, else the net names don't match up
                pin_name = self.out_nodes[o_name]["src"][0][0]
                self.out_nodes[o_name]["src"].remove((pin_name, a_dest_name))
                self.out_nodes[o_name]["src"].append((pin_name, a_src_name))
                return None
        elif isinstance(item.right.var, Identifier):
            o_name = "OUTPUT_" + a_dest_name
            i_name = "INPUT_" + a_src_name
            if o_name not in self.out_nodes or i_name not in self.in_nodes:
                # if assign does not connect input and output, we can enlist the
                # assign in the assign chain.
                return (a_src_name, a_dest_name), item
            else:
                # input and output are directly connected via assign. Handle that directly here.
                if a_src_name not in self.nets:
                    self.nets[a_src_name] = [o_name]
                else:
                    self.nets[a_src_name].append(o_name)
                # important: update out_nodes here, else the net names don't match up
                pin_name = self.out_nodes[o_name]["src"][0][0]
                self.out_nodes[o_name]["src"].remove((pin_name, a_dest_name))
                self.out_nodes[o_name]["src"].append((pin_name, a_src_name))
                return None
        elif isinstance(item.right.var, IntConst):
            if item.right.var.bits() > 1:
                raise ASTParsingError(
                    self.netlist_file,
                    item,
                    "Assignments larger than one bit are not supported. Also, "
                    "this error should have been catched before (I'm in "
                    "_handle_assigns_at_nets now!)",
                )
            else:
                a_src_name = str(int(item.right.var))
                net_name = "CONSTANT_" + a_src_name
                node_name = "INPUT_" + net_name
                if node_name not in self.in_nodes:
                    # constant input does not yet exist.
                    node_type = "PI"
                    node_dest = [("Y", net_name)]
                    node_src = [("A", None)]
                    self.nets.setdefault(net_name, [])
                    if not net_name in self.net_drivers:
                        self.net_drivers[net_name] = node_name
                    self.in_nodes.update(
                        {
                            node_name: {
                                "cell_type": node_type,
                                "dest": node_dest,
                                "src": node_src,
                            }
                        }
                    )
                return (net_name, a_dest_name), item

    def _handle_replace_dict_at_nets(self):

        for origin, dests in self.final_assign_chain.items():
            for dest in dests:
                a_dest_names = self.bus_nets.get(dest, [dest])
                a_src_names = self.bus_nets.get(origin, [origin])
                if len(a_dest_names) != len(a_src_names):
                    raise ASTParsingError(
                        self.netlist_file,
                        self.assign_items_dict[origin],
                        "Assignment chain invalid. The assign chain started by this "
                        "statement will assign two buses with different widths.",
                    )
                # check if any node already drives a_dest_name
                if any(a_dest_name in self.net_drivers for a_dest_name in a_dest_names):
                    # this might happen for inouts. Treat this
                    o_names = set("OUTPUT_" + a_src_name for a_src_name in a_src_names)
                    i_names = set("INPUT_" + a_src_name for a_src_name in a_src_names)
                    if o_names <= set(self.out_nodes) and i_names <= set(self.in_nodes):
                        # all a_src_names are both inputs and outputs
                        # hence, this assignment will be just ignored, because we only
                        # care for one direction, structurally...
                        # ToDo: this CANNOT be output again...
                        continue
                    raise ASTParsingError(
                        self.netlist_file,
                        self.assign_items_dict[origin],
                        "Assignment invalid. The assign chain started by this statement"
                        " will assign a net to an already driven net.",
                    )
                o_names = ["OUTPUT_" + a_dest_name for a_dest_name in a_dest_names]
                # a_dest_names and a_src_names shall only be the same nets but different bits
                # thus if everything's allright, ALL dest names will need to be outputs.
                if all(o_name in self.out_nodes for o_name in o_names):
                    for a_src_name, o_name, a_dest_name in zip(a_src_names, o_names, a_dest_names):
                        if a_src_name not in self.nets:
                            self.nets[a_src_name] = [o_name]
                        else:
                            self.nets[a_src_name].append(o_name)
                        # important: update out_nodes here, else the net names don't match up
                        pin_name = self.out_nodes[o_name]["src"][0][0]
                        self.out_nodes[o_name]["src"].remove((pin_name, a_dest_name))
                        self.out_nodes[o_name]["src"].append((pin_name, a_src_name))
                else:
                    # a_dest_names are not bits of an Output. Treat each
                    # a_dest_name as an alias of the respective a_src_name.
                    # Thus, the driver of each a_src_name shall be the driver
                    # of each a_dest_name.
                    # And anything driven by each a_dest_name is now driven by
                    # each a_src_name.
                    #
                    # In this stage, we only have the nets and the individual
                    # nodes, so we only have to update the src of all nodes
                    # driven by each a_dest_name.

                    # get nodes driven by a_dest_name
                    for a_dest_name, a_src_name in zip(a_dest_names, a_src_names):
                        nodes_list = self.nets.get(a_dest_name, [])
                        for node in nodes_list:
                            try:
                                info = self.other_nodes[node]
                            except KeyError:
                                info = self.out_nodes[node]
                            for pin, src in info["src"]:
                                if src == a_dest_name:
                                    # this node is driven by a_dest_name. Shall now be driven by a_src_name
                                    info["src"].remove((pin, src))
                                    info["src"].append((pin, a_src_name))
                        # alias a_dest_name and a_src_name by merging their driven nodes:
                        new_driven_nodes = set(node for node in nodes_list)
                        new_driven_nodes.update(self.nets.get(a_src_name, []))
                        # do not modify self.nets[a_dest_name] here, we need to know which nodes are
                        # driven by a_dest_name
                        self.nets[a_src_name] = list(new_driven_nodes)
                        # now update net drivers:
                        a_src_name_driver = self.net_drivers.get(a_src_name, None)
                        self.net_drivers[a_dest_name] = a_src_name_driver

    def build_nodes(self, module):
        self.node_types = {}
        self.graph = {}

        item_len = len(module.items)
        glogger.debug("Processing nodes for {}".format(self.netlist_file))

        for i, item in enumerate(module.items):
            if glogger.level == logging.DEBUG:
                draw_progress_bar(i / item_len)
            if isinstance(item, Decl):
                for decl in item.list:
                    if isinstance(decl, Input):
                        try:
                            dead_inputs = self.AddInput(decl)
                        except BaseException as e:
                            raise ASTParsingError(self.netlist_file, decl, e)
                        for di in dead_inputs:
                            net_name = di[0]
                            node_name = di[1]
                            if self.delete_unconnected_inputs:
                                self.nets.pop(net_name)
                                self.in_nodes.pop(node_name)
                            else:
                                self.graph.setdefault(node_name, [])
                    elif isinstance(decl, Output):
                        try:
                            self.AddOutput(decl)
                        except BaseException as e:
                            raise ASTParsingError(self.netlist_file, decl, e)
            elif isinstance(item, Instance):
                self.AddNode_helper(item)

        if glogger.getEffectiveLevel() == logging.DEBUG:
            draw_progress_bar(1)
            print()

        glogger.debug("Processing assigns@nodes for {}".format(self.netlist_file))

        self._handle_replace_dict_at_nodes()

        if glogger.getEffectiveLevel() == logging.DEBUG:
            draw_progress_bar(1)
            print()

    def _handle_replace_dict_at_nodes(self):
        for origin, dests in self.final_assign_chain.items():
            for dest in dests:
                a_dest_names = self.bus_nets.get(dest, [dest])
                a_src_names = self.bus_nets.get(origin, [origin])
                # it was alread checked that the lengths are equal in
                # _handle_replace_dict_at_nets.
                for a_dest_name, a_src_name in zip(a_dest_names, a_src_names):
                    nodes_list = self.nets.get(a_dest_name, [])
                    for node in nodes_list:
                        # Todo: Think of some idea how to update the info dicts...
                        # try:
                        #     info = self.other_nodes[node]
                        # except KeyError:
                        #     info = self.out_nodes[node]
                        try:
                            driver_node = self.net_drivers[a_src_name]
                            # build path from a_src_name's driver to node
                            self.graph.setdefault(driver_node, []).append(node)
                        except KeyError:
                            raise ASTParsingError(
                                self.netlist_file,
                                self.assign_items_dict[origin],
                                "I don't know what is the driver of this a_src_name: {}".format(
                                    a_src_name
                                ),
                            )

    # Todo: Handle constant assignments as a input of vdd or something!
    # def handle_const_assign(self, assign):
    #     """Handle constant assignments during build_nets"""
    #     # first check, if the assignment is a single-bit one.
    #     if int(assign.right.var.value[0]) > 1:
    #         raise ASTParsingError(
    #             self.netlist_file,
    #             assign,
    #             "Assignments larger than one bit are not supported.",
    #         )
    #     else:
    #         net_name = assign.left.var.name
    #         # if the last digit is 1, this is a pullup assignment, else an pulldown assignment:
    #         node_name = "INPUT_" + net_name
    #         node_type = "PI"
    #         node_dest = [("Y", net_name)]
    #         node_src = [("A", None)]
    #         self.nets.setdefault(net_name, [])

    #         self.in_nodes.update(
    #             {
    #                 node_name: {
    #                     "cell_type": node_type,
    #                     "dest": node_dest,
    #                     "src": node_src,
    #                 }
    #             }
    #         )

    def create_nets_expl(self, declaration):
        """parses all nodes for explicitly declared wires/nets.
        That are "wire", "inputs" and "outputs". "inouts" are not supported"""

        # if isinstance(declaration, Wire):
        #     return

        net_names = self.generate_net_names_for_decls(declaration)
        if len(net_names) > 1:
            # the declaration is a bus net
            # save the net name and it's corresponding nets
            self.bus_nets[declaration.name] = net_names

        for net_name in net_names:
            if isinstance(declaration, Output):
                node_name = "OUTPUT_" + net_name
                node_type = "PO"
                node_dest = [("Y", None)]
                node_src = [("A", net_name)]
                self.nets.setdefault(net_name, []).append(node_name)
                self.out_nodes.update(
                    {
                        node_name: {
                            "cell_type": node_type,
                            "dest": node_dest,
                            "src": node_src,
                        }
                    }
                )
            elif isinstance(declaration, Input):
                node_name = "INPUT_" + net_name
                node_type = "PI"
                node_dest = [("Y", net_name)]
                node_src = [("A", None)]
                self.nets.setdefault(net_name, [])
                if net_name in self.net_drivers:
                    raise ASTParsingError(
                        self.netlist_file,
                        declaration,
                        "This instance drives a net ({}) that is already driven!".format(
                            net_name
                        ),
                    )
                self.net_drivers[net_name] = node_name
                self.in_nodes.update(
                    {
                        node_name: {
                            "cell_type": node_type,
                            "dest": node_dest,
                            "src": node_src,
                        }
                    }
                )
            elif isinstance(declaration, Wire):
                self.nets.setdefault(net_name, [])
            else:
                raise ASTParsingError(
                    "",
                    declaration,
                    "Serious error, this function receives only ins and outs and wires!",
                )

    def create_nets_impl(self, instance):
        """parses all nodes for implicitly declared wires/nets"""

        node_src = []
        node_dest = []

        cell_name = instance.module
        inst_name = instance.name

        for port in instance.portlist:
            pin_name = port.portname
            net_name = self.generate_net_names_for_ports(port, instance)
            if self.cell_lib[cell_name][pin_name]["direction"] == "input":
                self.nets.setdefault(net_name, []).append(inst_name)
                node_src.append((pin_name, net_name))
            elif self.cell_lib[cell_name][pin_name]["direction"] == "output":
                node_dest.append((pin_name, net_name))
                if net_name == "None":
                    continue
                if net_name in self.net_drivers:
                    # check for inout
                    o_name = "OUTPUT_" + net_name
                    i_name = "INPUT_" + net_name
                    if o_name in self.out_nodes and i_name in self.in_nodes:
                        # all net_name is both input and output, i.e. a INOUT
                        # hence, this port connection will be just ignored, because we only
                        # care for one direction, structurally...
                        # ToDo: this CANNOT be output again...
                        continue
                    raise ASTParsingError(
                        self.netlist_file,
                        instance,
                        "This instance drives a net ({}) that is already driven!".format(
                            net_name
                        ),
                    )
                self.net_drivers[net_name] = inst_name

            else:
                glogger.warning(
                    "A pin of {} in line {} has other direction than input or output".format(
                        instance, instance.lineno
                    )
                )
                # print("zuerst", nets)
                # nets.setdefault(net_name,[])
                # print("dannach", nets)
                # FIXME kann man das weglassen? Falls ja gut.
                # Falls nein, werden einträge gelöscht
                pass

        self.other_nodes.update(
            {inst_name: {"cell_type": cell_name, "dest": node_dest, "src": node_src}}
        )

    def AddNode(self, instance):
        """Helper function to add a node to the graph"""
        cell_name = instance.module
        inst_name = instance.name

        for port in instance.portlist:
            pin_name = port.portname
            net_name = self.generate_net_names_for_ports(port, instance)
            if (
                self.cell_lib[cell_name][pin_name]["direction"] == "output"
                and not net_name.find("UNCONNECTED") >= 0
            ):
                try:
                    for dest in self.nets[net_name]:
                        self.graph.setdefault(inst_name, []).append(dest)
                except KeyError:
                    self.nets.setdefault(net_name, [])
                    self.graph.setdefault(inst_name, [])
                    glogger.warning(
                        "The pin {} of cell {} is connected to an unknown net {}. "
                        "Added that net. Probably this pin is dangling!".format(
                            pin_name, inst_name, net_name
                        )
                    )
            if self.cell_lib[cell_name][pin_name][
                "direction"
            ] == "input" and isinstance(port.argname, IntConst):
                node_name = "INPUT_" + net_name
                destinations = self.nets[net_name]
                if destinations:
                    if not node_name in self.graph:
                        for dest in self.nets[net_name]:
                            self.graph.setdefault(node_name, []).append(dest)
                    # else const input already done, ignore.
                else:
                    # this is a dead, nonconnected input
                    dead_inputs.append((net_name, node_name))
                    pass

        self.node_types[inst_name] = cell_name

    def AddInput(self, declaration):
        """Helper function to add primary inputs to the graph"""

        dead_inputs = []

        net_names = self.generate_net_names_for_decls(declaration)

        for net_name in net_names:
            node_name = "INPUT_" + net_name
            destinations = self.nets[net_name]
            if destinations:
                for dest in self.nets[net_name]:
                    self.graph.setdefault(node_name, []).append(dest)
            else:
                # this is a dead, nonconnected input
                dead_inputs.append((net_name, node_name))
                pass

        return dead_inputs

    def AddOutput(self, declaration):
        """Helper function to add extra nodes for the primary outputs"""
        net_names = self.generate_net_names_for_decls(declaration)

        for net_name in net_names:
            node_name = "OUTPUT_" + net_name
            self.graph.setdefault(node_name, [])

    def AddNet_helper(self, instance):
        """Add the found net line to the nets and nodes dict"""
        try:
            self.create_nets_impl(instance)
        except ASTParsingError:
            raise
        except BaseException as e:
            raise ASTParsingError(self.netlist_file, instance, e)

    def AddNode_helper(self, instance):
        """Add the found net line to the nets and nodes dict"""
        try:
            self.AddNode(instance)
        except ASTParsingError:
            raise
        except BaseException as e:
            raise ASTParsingError(self.netlist_file, instance, e)

    def generate_net_names_for_decls(self, declaration):
        if declaration.width is None:
            net_names = [str(declaration.name)]
        else:
            if declaration.width.msb == declaration.width.lsb:
                net_names = [str(declaration.name)]
            else:
                if str(declaration.name).find("pad_cfg_o") >= 0:
                    print(f"'decls: {declaration.name}, str: {declaration}'")
                if declaration.width.msb < declaration.width.lsb:
                    net_bits = range(
                        declaration.width.msb, declaration.width.lsb + 1, 1
                    )
                else:
                    net_bits = range(
                        declaration.width.msb, declaration.width.lsb - 1, -1
                    )
                net_names = [
                    str(Partselect(declaration.name, bit, bit)) for bit in net_bits
                ]
        return net_names

    def generate_net_names_for_ports(self, port, instance):
        if isinstance(port.argname, Identifier):
            net_name = str(port.argname)
            # if str(port.argname).find("data_tPoUt") >= 0:
            #     print(f"'ports: {port.argname}'")
        elif isinstance(port.argname, Partselect):
            if port.argname.msb != port.argname.lsb:
                raise ASTParsingError(
                    self.netlist_file,
                    instance,
                    "How did you do that? Bus port connections should not even parse!",
                )
            net_name = str(port.argname)
            # if (
            #     str(port.argname.var).find("pad_cfg_o") >= 0
            #     or str(port.argname.var).find("data_tPiN") >= 0
            # ):
            #     print(f"'ports: {port.argname.var}'")
        elif isinstance(port.argname, IntConst):
            if self.cell_lib[instance.module][port.portname]["direction"] != "input":
                raise ASTParsingError(
                    self.netlist_file,
                    port.argname,
                    "You can not assign a constant to an output pin of a cell!.",
                )
            if port.argname.bits() > 1:
                raise ASTParsingError(
                    self.netlist_file,
                    port.argname,
                    "Pin assignments larger than one bit are not supported.",
                )
            else:
                if not self._add_const_as_input:
                    if self._show_all_const_warnings:
                        glogger.warning(
                            "Constant one bit assignments not supported by "
                            "parsing if you do not enable 'add_const_as_input'. "
                            "This is not a problem, if the assignment only "
                            "handles the `gnd` and `vdd` wires, "
                            "as cell functions should be parsed anyways. "
                            "Assignment '{}' in '{}':{} will be ignored!".format(
                                instance, self.netlist_file, instance.lineno
                            )
                        )
                    elif not self._const_warning_occured:
                        self._const_warning_occured = True
                        glogger.warning(
                            "Constant one bit assignments not supported by "
                            "parsing if you do not enable 'add_const_as_input'. "
                            "This is not a problem, if the assignment only "
                            "handles the `gnd` and `vdd` wires, "
                            "as cell functions should be parsed anyways. "
                            "ATTENTION: This type of warning will be suppressed "
                            "from now on. If you want to show all warnings of this type "
                            "you need to set 'show_all_const_warnings' to True. "
                            "Assignment '{}' in '{}':{} will be ignored!".format(
                                instance, self.netlist_file, instance.lineno
                            )
                        )
                    net_name = port.argname.value
                else:
                    net_name = "CONSTANT_" + str(int(port.argname))
                    node_name = "INPUT_" + net_name
                    if node_name not in self.in_nodes:
                        # constant input does not yet exist.
                        node_type = "PI"
                        node_dest = [("Y", net_name)]
                        node_src = [("A", None)]
                        self.nets.setdefault(net_name, [])
                        if not net_name in self.net_drivers:
                            self.net_drivers[net_name] = node_name
                        self.in_nodes.update(
                            {
                                node_name: {
                                    "cell_type": node_type,
                                    "dest": node_dest,
                                    "src": node_src,
                                }
                            }
                        )
        else:
            net_name = str(port.argname)
        return net_name

    @staticmethod
    def rev_lookup(nodes_lookup):
        """Generate a dictionary of driving nodes for nets by reversing the nodes dictionary.

        :param nodes_lookup: dictionary of nodes
        :type nodes_lookup: dict
        :return: dictionary mapping nets to driving nodes
        :rtype: dict
        """
        # FIXME: gnd and vdd nodes?
        net_to_node_lookup = {}

        for inst in nodes_lookup:
            for output in nodes_lookup[inst]["dest"]:
                net = output[1]
                if net == "None":
                    continue
                newinst = net_to_node_lookup.setdefault(net, inst)
                if newinst != inst:
                    raise ValueError(
                        f"MultipleDrivenNet: for net {net} there was already an inst {newinst} driving it. "
                        f"But I just found that {inst} is driving it, as well."
                    )
        return net_to_node_lookup
