#!usr/bin/python3

########################################################################
# derived from JB, partly changed by MB, refactored by AD
########################################################################

# stdlib imports
import sys
import os.path
import pickle

# local imports
from . import plylibparser
from .liberty_parsing import own_parseLibertyToDataStruct
from .parsed_verilog import ParsedVerilog

cell_lib = None
node_lookup = None
nets_to_nodes = None


def create_nets_expl_bench(line, prefix):
    """parses all nodes for explicitly declared wires/nets.
    That are "wire", "inputs" and "outputs". "inouts" are not supported"""
    if prefix.startswith("inout"):
        sys.exit("Inouts are not supported")
    nets = {}
    nodes = {}
    c_line = line[len(prefix) :]
    c_line = c_line.rstrip(";\n")
    c_line = c_line.split(",")
    for c in c_line:
        if c.startswith("["):
            lh, rh = c.split(":")
            lh = lh.split("[")[1]
            rh, name = rh.split("]")

            name = name.strip()

            lh = int(lh)
            rh = int(rh)

            if lh < rh:
                for x in range(lh, rh + 1):
                    net_name = name + "[" + str(x) + "]"
                    if prefix == "OUTPUT(":
                        node_name = "OUTPUT_" + net_name
                        node_type = "PO"
                        node_dest = [("Y", None)]
                        node_src = [("A", net_name)]
                        nets.setdefault(net_name, []).append(node_name)
                    elif prefix == "INPUT(":
                        node_name = "INPUT_" + net_name
                        node_type = "PI"
                        node_dest = [("Y", net_name)]
                        node_src = [("A", None)]
                        nets.setdefault(net_name, [])
                    else:
                        nets.setdefault(net_name, [])
                    nodes.update(
                        {
                            node_name: {
                                "cell_type": node_type,
                                "dest": node_dest,
                                "src": node_src,
                            }
                        }
                    )
            else:
                for x in range(rh, lh + 1):
                    net_name = name + "[" + str(x) + "]"
                    if prefix == "OUTPUT(":
                        node_name = "OUTPUT_" + net_name
                        node_type = "PO"
                        node_dest = [("Y", None)]
                        node_src = [("A", net_name)]
                        nets.setdefault(net_name, []).append(node_name)
                    elif prefix == "INPUT(":
                        node_name = "INPUT_" + net_name
                        node_type = "PI"
                        node_dest = [("Y", net_name)]
                        node_src = [("A", None)]
                        nets.setdefault(net_name, [])
                    else:
                        nets.setdefault(net_name, [])
                    nodes.update(
                        {
                            node_name: {
                                "cell_type": node_type,
                                "dest": node_dest,
                                "src": node_src,
                            }
                        }
                    )
        else:
            net_name = c.strip()  # JB
            if prefix == "OUTPUT(":
                node_name = "OUTPUT_" + net_name
                node_type = "PO"
                node_dest = [("Y", None)]
                node_src = [("A", net_name)]
                nets.setdefault(net_name, []).append(node_name)

            elif prefix == "INPUT(":
                node_name = "INPUT_" + net_name
                node_type = "PI"
                node_dest = [("Y", net_name)]
                node_src = [("A", None)]
                nets.setdefault(net_name, [])
            else:
                nets.setdefault(net_name, [])

            nodes.update(
                {
                    node_name: {
                        "cell_type": node_type,
                        "dest": node_dest,
                        "src": node_src,
                    }
                }
            )
        return nets, nodes

def create_nets_impl_bench(line, cell_lib):
    """parses all nodes for implicitly declared wires/nets"""
    nets = {}
    nodes = {}

    line = line.replace(", ", ",")
    s_line = line.split()
    cell_type = s_line[2].split("(")[0]

    dest = s_line[0]

    node_src = []
    node_dest = []

    if cell_type != "NOT":
        inputs = s_line[2].split("(")[1].split(",")
    else:

        inputs = [s_line[2].split("(")[1]]
        cell_type = "INV"

    if cell_type != "DFF":
        counter = 1
        cell_name = ""
        while counter < 5:
            # for osu
            if len(inputs) == 1:
                name = cell_type.upper() + "X" + str(counter)
            else:
                name = cell_type.upper() + str(len(inputs)) + "X" + str(counter)
            if name in cell_lib:
                cell_name = name
                break
            # for nangate
            if len(inputs) == 1:
                name = cell_type.upper() + "_X" + str(counter)
            else:
                name = cell_type.upper() + str(len(inputs)) + "_X" + str(counter)
            if name in cell_lib:
                cell_name = name
                break
            counter = counter + 1

        inst_name = cell_name + "_" + dest

        input_pins = []
        for k in cell_lib[cell_name]:
            if type(cell_lib[cell_name][k]) is dict:
                if "direction" in cell_lib[cell_name][k]:
                    if cell_lib[cell_name][k]["direction"] == "input":
                        input_pins.append(k)
                    else:
                        output_pin = k

        for x in range(len(inputs)):
            net_name = inputs[x]
            pin_name = input_pins[x]
            nets.setdefault(net_name, []).append(inst_name)
            node_src.append((pin_name, net_name))

        node_dest.append((output_pin, dest))

        nodes = {
            inst_name: {"cell_type": cell_name, "dest": node_dest, "src": node_src}
        }

    else:
        # fixme...
        cell_name = "DFF"
        inst_name = cell_name + "_" + dest
        net_name = s_line[2].split("(")[1].split(",")[0]
        nets.setdefault(net_name, []).append(inst_name)
        node_src.append(("D", net_name))
        node_dest.append(("", dest))
        nodes = {
            inst_name: {"cell_type": cell_name, "dest": node_dest, "src": node_src}
        }

    return nets, nodes

def AddNode_bench(graph, line, net_dict, cell_lib):
    """Helper function to add a node to the graph"""

    line = line.replace(", ", ",")
    s_line = line.split()
    cell_type = s_line[2].split("(")[0]

    dest = s_line[0]

    node_src = []
    node_dest = []

    if cell_type != "NOT":
        inputs = s_line[2].split("(")[1].split(",")
    else:

        inputs = [s_line[2].split("(")[1]]
        cell_type = "INV"

    if cell_type != "DFF":
        counter = 1
        cell_name = ""
        while counter < 5:
            # for osu
            if len(inputs) == 1:
                name = cell_type.upper() + "X" + str(counter)
            else:
                name = cell_type.upper() + str(len(inputs)) + "X" + str(counter)
            if name in cell_lib:
                cell_name = name
                break
            # for nangate
            if len(inputs) == 1:
                name = cell_type.upper() + "_X" + str(counter)
            else:
                name = cell_type.upper() + str(len(inputs)) + "_X" + str(counter)
            if name in cell_lib:
                cell_name = name
                break
            counter = counter + 1

        inst_name = cell_name + "_" + dest

        input_pins = []
        for k in cell_lib[cell_name]:
            if type(cell_lib[cell_name][k]) is dict:
                if "direction" in cell_lib[cell_name][k]:
                    if cell_lib[cell_name][k]["direction"] == "output":
                        for d in net_dict[dest]:

                            graph.setdefault(inst_name, []).append(d)

        nodes = {
            inst_name: {"cell_type": cell_name, "dest": node_dest, "src": node_src}
        }

    else:
        # fixme...
        cell_name = "DFF"
        inst_name = cell_name + "_" + dest
        for d in net_dict[dest]:
            graph.setdefault(inst_name, []).append(d)

    return graph, {inst_name: cell_name}

def AddInput_bench(graph, line, net_dict, cell_lib):
    """Helper function to add primary inputs to the graph"""
    prefix = "INPUT("
    c_line = line[len(prefix) :]
    # ~ c_line = c_line.rstrip(";\n")
    # ~ c_line = c_line.split(',')
    c_line = [c_line]
    for c in c_line:
        if c.startswith("["):
            lh, rh = c.split(":")
            lh = lh.split("[")[1]
            rh, name = rh.split("]")

            name = name.strip()

            lh = int(lh)
            rh = int(rh)
            if lh < rh:
                for x in range(lh, rh + 1):
                    net_name = name + "[" + str(x) + "]"
                    node_name = "INPUT_" + net_name
                    for dest in net_dict[net_name]:
                        graph.setdefault(node_name, []).append(dest)

            else:
                for x in range(rh, lh + 1):
                    net_name = name + "[" + str(x) + "]"
                    node_name = "INPUT_" + net_name
                    for dest in net_dict[net_name]:
                        graph.setdefault(node_name, []).append(dest)

        else:

            net_name = c.strip()
            node_name = "INPUT_" + net_name

            for dest in net_dict[net_name]:
                graph.setdefault(node_name, []).append(dest)

    return graph

def AddOutput_bench(graph, line, net_dict, cell_lib):
    """ Helper function to add extra nodes for the primary outputs"""
    prefix = "OUTPUT("
    c_line = line[len(prefix) :]
    # ~ c_line = c_line.rstrip(";\n")
    # ~ c_line = c_line.split(',')
    for c in [c_line]:
        if c.startswith("["):
            lh, rh = c.split(":")
            lh = lh.split("[")[1]
            rh, name = rh.split("]")

            name = name.strip()

            lh = int(lh)
            rh = int(rh)

            if lh < rh:
                for x in range(lh, rh + 1):
                    net_name = name + "[" + str(x) + "]"
                    node_name = "OUTPUT_" + net_name
                    graph.setdefault(node_name, [])

            else:
                for x in range(rh, lh + 1):
                    net_name = name + "[" + str(x) + "]"
                    node_name = "OUTPUT_" + net_name
                    graph.setdefault(node_name, [])

        else:
            net_name = c.strip()
            node_name = "OUTPUT_" + net_name
            graph.setdefault(node_name, [])

    return graph


def parseBenchToData(bench_file, cell_lib):

    in_nodes = {}
    out_nodes = {}
    nodes = {}
    node_types = {}
    nets = {}
    graph = {}

    file = open(bench_file, "r")

    # first build nets

    for line in file:

        line = line.strip()
        line = line.strip(")")
        if line.startswith("/*"):
            sys.exit("FIXME: Comments are not supportet")

        # ~ elif line.startswith("module") or line.startswith("endmodule"):
        # ~ continue
        elif line == "":
            continue
        elif line.startswith("#"):
            continue

        elif line.startswith("INPUT"):

            net, node = create_nets_expl_bench(line, "INPUT(")
            nets.update(net)
            in_nodes.update(node)

        elif line.startswith("OUTPUT"):
            net, node = create_nets_expl_bench(line, "OUTPUT(")
            nets.update(net)
            out_nodes.update(node)
        elif line.startswith("wire "):
            # net, node = create_nets_expl(line, "wire ")
            # nets.update(net)
            # nodes.update(node)
            continue
        elif line.startswith("INOUT"):
            sys.exit("inouts are not supported")
        else:
            net, node = create_nets_impl_bench(line, cell_lib)

            for k, v in net.items():
                if k in nets:
                    nets[k].extend(v)
                else:
                    nets[k] = v

            nodes.update(node)
            # print("DEBUG:",line, nets)
            # print("DEBUG:",line, nets)
            # print ("ToDo", line)
    file.close()

    # second    build nodes

    file = open(bench_file, "r")

    for line in file:
        line = line.strip()
        line = line.strip(")")
        if line.startswith("/*"):
            sys.exit("FIXME: Comments are not supportet")
        elif line == "":
            continue
        elif line.startswith("#"):
            continue
        # ~ elif line.startswith("module") or line.startswith("endmodule"):
        # ~ continue
        elif line.startswith("INPUT("):
            graph = AddInput_bench(graph, line, nets, cell_lib)
        elif line.startswith("OUTPUT("):
            graph = AddOutput_bench(graph, line, nets, cell_lib)
        elif line.startswith("wire "):
            continue
        else:
            graph, node_type = AddNode_bench(graph, line, nets, cell_lib)
            node_types.update(node_type)

    return graph, nets, (in_nodes, nodes, out_nodes), node_types

def parse_it_bench(netlist_file, liberty_file):
    # parsing
    # ~ lib=dotlib.PLYPair()
    # ~ lib.set_lexer(dotlib.create_lexer())
    # ~ lib.set_parser(dotlib.create_parser())
    # ~ lib.parse_file(liberty_file)

    lib_file_name = liberty_file.split("/")[-1].split(".lib")[0] + "_lib.txt"
    if os.path.isfile(lib_file_name) == True:
        with open(lib_file_name, "rb") as handle:
            lib = pickle.loads(handle.read())
    else:
        # own parsing
        f = open(liberty_file, "r")
        lib_raw = f.read()
        f.close()

        own_lexer = plylibparser.create_lexer()
        own_parser = plylibparser.create_parser()
        lib = own_parser.parse(
            lib_raw, lexer=own_lexer, debug=False
        )  # debug kann auch entfert werden

        with open(lib_file_name, "wb") as handle:
            pickle.dump(lib, handle)

    global cell_lib
    global node_lookup
    global nets_to_nodes

    # my parsing
    # ~ cell_lib = parseLibertyToDataStruct(lib)
    cell_lib = own_parseLibertyToDataStruct(lib)
    graph, nets, nodes, node_types = parseBenchToData(
        netlist_file, cell_lib
    )  # FIXME: Better return names for global lookup
    # FIXME: nodetuple....
    # global lookup

    nets_to_nodes = ParsedVerilog.rev_lookup(nodes[1])

    node_lookup = nodes[1]

    return graph, nets, nodes, node_types, cell_lib, nets_to_nodes

