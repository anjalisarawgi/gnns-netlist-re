#!usr/bin/ipython3
from pyeda.inter import exprvar
import pyeda.boolalg.expr
from pyeda.parsing.boolexpr import BoolExprLexer
import pyeda.parsing.boolexpr

LEVEL_REPL_DICT = {
    "VSS": "0",
    "Gnd": "0",
    "gnd": "0",
    "Vcc": "1",
    "1'b1": "1",
    "1'b0": "0",
}


class LibertyBoolExprLexer(BoolExprLexer):
    RULES = {
        'root': [
            (r"\s+", BoolExprLexer.ignore),

            (r"\bOr\b", BoolExprLexer.keyword),
            (r"\bAnd\b", BoolExprLexer.keyword),
            (r"\bXor\b", BoolExprLexer.keyword),
            (r"\bXnor\b", BoolExprLexer.keyword),
            (r"\bEqual\b", BoolExprLexer.keyword),
            (r"\bUnequal\b", BoolExprLexer.keyword),
            (r"\bNor\b", BoolExprLexer.keyword),
            (r"\bNand\b", BoolExprLexer.keyword),
            (r"\bOneHot0\b", BoolExprLexer.keyword),
            (r"\bOneHot\b", BoolExprLexer.keyword),
            (r"\bMajority\b", BoolExprLexer.keyword),
            (r"\bAchillesHeel\b", BoolExprLexer.keyword),

            (r"\bITE\b", BoolExprLexer.keyword),
            (r"\bImplies\b", BoolExprLexer.keyword),
            (r"\bNot\b", BoolExprLexer.keyword),

            (r"[a-zA-Z_][a-zA-Z0-9_]*", BoolExprLexer.name),
            (r"\d+", BoolExprLexer.integer),

            (r"=>", BoolExprLexer.operator),
            (r"<=>", BoolExprLexer.operator),
            (r"\?", BoolExprLexer.operator),
            (r":", BoolExprLexer.operator),
            (r"\~", BoolExprLexer.operator),
            (r"!", BoolExprLexer.operator),
            (r"\|", BoolExprLexer.operator),
            (r"\+", BoolExprLexer.operator),
            (r"\^", BoolExprLexer.operator),
            (r"\&", BoolExprLexer.operator),
            (r"\*", BoolExprLexer.operator),

            (r"\(", BoolExprLexer.punct),
            (r"\)", BoolExprLexer.punct),
            (r"\[", BoolExprLexer.punct),
            (r"\]", BoolExprLexer.punct),
            (r",", BoolExprLexer.punct),
            (r"\.", BoolExprLexer.punct),
        ],
    }
    OPERATORS = {
        '=>'  : pyeda.parsing.boolexpr.OP_rarrow,
        '<=>' : pyeda.parsing.boolexpr.OP_lrarrow,
        '?'   : pyeda.parsing.boolexpr.OP_question,
        ':'   : pyeda.parsing.boolexpr.OP_colon,
        '~'   : pyeda.parsing.boolexpr.OP_not,
        '!'   : pyeda.parsing.boolexpr.OP_not,
        '|'   : pyeda.parsing.boolexpr.OP_or,
        '+'   : pyeda.parsing.boolexpr.OP_or,
        '&'   : pyeda.parsing.boolexpr.OP_and,
        '*'   : pyeda.parsing.boolexpr.OP_and,
        '^'   : pyeda.parsing.boolexpr.OP_xor,
    }


def _prodterm_prime(lexer):
    """Return a product term' expression, eliminates left recursion."""
    tok = next(lexer)
    # '&' FACTOR PRODTERM'
    if isinstance(tok, pyeda.parsing.boolexpr.OP_and):
        factor = pyeda.parsing.boolexpr._factor(lexer)
        prodterm_prime = _prodterm_prime(lexer)
        if prodterm_prime is None:
            return factor
        else:
            return ('and', factor, prodterm_prime)
    # FACTOR PRODTERM'
    else:
        lexer.unpop_token(tok)
        try:
            factor = pyeda.parsing.boolexpr._factor(lexer)
        except BaseException:
            lexer.unpop_token(tok)
            return None
        else:
            prodterm_prime = _prodterm_prime(lexer)
            if prodterm_prime is None:
                return factor
            else:
                return ('and', factor, prodterm_prime)


def stringToPyeda(function_s):


    function_s = function_s.replace("VSS", "0")
    function_s = function_s.replace("Gnd", "0")
    function_s = function_s.replace("gnd", "0")
    function_s = function_s.replace("Vcc", "1")
    function_s = function_s.replace("INPUT_1'b1", "1")
    function_s = function_s.replace("INPUT_1'b0", "0")
    function_s = function_s.replace("\\", "")

    # monkey-patch the prodterm function and the lexer
    oldprodterm = pyeda.parsing.boolexpr._prodterm_prime
    oldlexer = pyeda.parsing.boolexpr.BoolExprLexer
    pyeda.parsing.boolexpr.BoolExprLexer = LibertyBoolExprLexer
    pyeda.parsing.boolexpr._prodterm_prime = _prodterm_prime

    function_p = pyeda.parsing.boolexpr.parse(function_s)
    # restore
    pyeda.parsing.boolexpr._prodterm_prime = oldprodterm
    pyeda.parsing.boolexpr.BoolExprLexer = oldlexer
    
    function_a = pyeda.boolalg.expr.ast2expr(function_p)
    function_e = function_a.simplify()

    return function_e


def pyedaToSymbol(function_b):
    function_s = function_b.__str__()
    # FIXME
    function_s = function_s.replace("And", "and_s")
    function_s = function_s.replace("Xor", "xor_s")

    return function_s


def vectorToList(name, size, offset=0):
    signal = []
    for n in range(size):
        signal.append(name + "[" + str(n + offset) + "]")
    return signal


def get_boolean_function_exprvar(node, node_info, lib):

    if not node.startswith("DFF"):

        element = node_info
        cell_type = element.get("cell_type")
        dest = element.get("dest")

        b_function = lib[cell_type][dest[0][0]]["function"]
    else:
        b_function = exprvar("D")
    return b_function


def get_pin_destination_exprvar(node, node_info):
    element = node_info
    # cell_type = element.get("cell_type")
    dest = element.get("dest")
    src = element.get("src")

    return src, dest


def get_function_exprvar(start_node, node_info, cell_lib, nets_to_nodes, POs):

    cell_func = get_boolean_function_exprvar(start_node, node_info, cell_lib)
    src_pin_to_net, dest_pin_to_net = get_pin_destination_exprvar(start_node, node_info)

    # ### create template and substitution dictionary
    subsDict = {}
    for pin, net in src_pin_to_net:
        if net in LEVEL_REPL_DICT:
            subsDict[exprvar(pin)] = LEVEL_REPL_DICT[net]
        else:
            if str("OUTPUT_" + net) in POs:  # net is a PO
                full_net = str("OUTPUT_" + net.lstrip("\\"))
                subsDict[exprvar(pin)] = pyeda_escape(full_net)
            elif net in nets_to_nodes:  # net corresponds to a driving node
                full_node = nets_to_nodes[net]
                subsDict[exprvar(pin)] = pyeda_escape(full_node)
            else:  # net is neither node nor PO, it must be PI.
                full_net = str("INPUT_" + net.lstrip("\\"))
                subsDict[exprvar(pin)] = pyeda_escape(full_net)

                ## substitute template with substitution dict
    return cell_func.compose(subsDict)


PYEDA_UNALLOWED_CHARS = {
    "\\": "_BackslasH_",
    ".": "_DoT_",
    "[": "_LbrackeT_",
    "]": "_RbrackeT_",
}

PYEDA_UNALLOWED_CHARS_REV = {value: key for key, value in PYEDA_UNALLOWED_CHARS.items()}


def pyeda_escape(full_node):

    # use ugly escape sequences
    for find, replace in PYEDA_UNALLOWED_CHARS.items():
        full_node = full_node.replace(find, replace)
    full_node = full_node.lstrip(
        "_"
    )  # should there be a dot or backslash in the beginning, dont put a _ in the beginning
    return exprvar(full_node)


def rev_pyeda_escape(function_input):
    node_name = function_input
    for find, replace in PYEDA_UNALLOWED_CHARS_REV.items():
        node_name = node_name.replace(find, replace)
        if node_name.startswith(find[1:]):
            node_name = node_name.replace(find[1:], replace)
    return node_name
