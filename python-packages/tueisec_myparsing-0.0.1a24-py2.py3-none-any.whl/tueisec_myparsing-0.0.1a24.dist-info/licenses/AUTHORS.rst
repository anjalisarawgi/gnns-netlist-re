
Authors
=======

* Johanna Baehr - http://www.sec.ei.tum.de/en/staff/johanna-baehr/
* Michaela Brunner - http://www.sec.ei.tum.de/en/staff/michaela-brunner/
* Alexander Hepp - http://www.sec.ei.tum.de/en/staff/alexander-hepp/
