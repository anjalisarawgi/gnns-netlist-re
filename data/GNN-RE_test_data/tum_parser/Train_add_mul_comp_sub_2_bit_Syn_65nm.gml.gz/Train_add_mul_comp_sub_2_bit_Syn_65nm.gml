graph [
  directed 1
  node [
    id 0
    label "INPUT_a[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_a[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_b[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "INPUT_b[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 4
    label "OUTPUT_Result[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 5
    label "OUTPUT_Result[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 6
    label "OUTPUT_Result[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 7
    label "OUTPUT_Result[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 8
    label "U16"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 9
    label "U17"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 10
    label "U18"
    nodeType "AOI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 11
    label "U19"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 12
    label "U20"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 13
    label "U21"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 14
    label "U22"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 15
    label "U23"
    nodeType "OAI221_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) (B0+B1)))')]"
  ]
  node [
    id 16
    label "U24"
    nodeType "AO21B_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0N))')]"
  ]
  node [
    id 17
    label "U25"
    nodeType "AO21B_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0N))')]"
  ]
  node [
    id 18
    label "U26"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 19
    label "U27"
    nodeType "OAI221_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) (B0+B1)))')]"
  ]
  node [
    id 20
    label "U28"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 21
    label "U29"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 22
    label "U30"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 23
    label "\subtractor_1/U7"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 24
    label "\subtractor_1/U6"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 25
    label "\subtractor_1/U5"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 26
    label "\subtractor_1/U4"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 27
    label "\subtractor_1/U3"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 28
    label "\subtractor_1/U2"
    nodeType "AO21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 29
    label "\subtractor_1/U1"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 30
    label "\comparator_1/U7"
    nodeType "AOI221_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 31
    label "\comparator_1/U6"
    nodeType "OAI22_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) (B0+B1)))')]"
  ]
  node [
    id 32
    label "\comparator_1/U5"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 33
    label "\comparator_1/U4"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 34
    label "\comparator_1/U3"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 35
    label "\comparator_1/U2"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 36
    label "\comparator_1/U1"
    nodeType "OAI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) (B0+B1)))')]"
  ]
  node [
    id 37
    label "\subtractor_2/U6"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 38
    label "\subtractor_2/U5"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 39
    label "\subtractor_2/U4"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 40
    label "\subtractor_2/U3"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 41
    label "\subtractor_2/U2"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 42
    label "\subtractor_2/U1"
    nodeType "OAI21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 43
    label "\adder_1/U4"
    nodeType "XNOR3_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 44
    label "\adder_1/U3"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 45
    label "\adder_1/U2"
    nodeType "OA21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 46
    label "\multiplier_1/U6"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 47
    label "\multiplier_1/U5"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 48
    label "\multiplier_1/U4"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 49
    label "\multiplier_1/U3"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 50
    label "\multiplier_1/U2"
    nodeType "AND3_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 51
    label "\multiplier_1/U1"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  edge [
    source 0
    target 29
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 0
    target 32
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 0
    target 40
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 0
    target 43
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 46
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 0
    target 47
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 0
    target 50
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 27
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 28
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 30
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "a[1]"
    function ""
    innum 5
    outnum 1
  ]
  edge [
    source 1
    target 35
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 36
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "a[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 1
    target 41
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 42
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 44
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 45
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 46
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "a[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 1
    target 48
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 23
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 30
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[0]"
    function ""
    innum 5
    outnum 1
  ]
  edge [
    source 2
    target 31
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "b[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 2
    target 34
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 36
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 2
    target 37
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 43
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 46
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "b[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 2
    target 47
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 50
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 3
    target 26
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 3
    target 33
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 3
    target 39
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 3
    target 44
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 45
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 3
    target 46
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 3
    target 48
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 14
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n24"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 15
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n24"
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 8
    target 19
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n24"
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 9
    target 13
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n23"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 14
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n23"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 15
    inpin "_networkx_list_start"
    inpin "C0"
    outpin "Y"
    net "n23"
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 9
    target 19
    inpin "_networkx_list_start"
    inpin "C0"
    outpin "Y"
    net "n23"
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 9
    target 20
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n23"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 10
    target 16
    inpin "_networkx_list_start"
    inpin "B0N"
    outpin "Y"
    net "n20"
    function "(!((A0 A1)+B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 10
    target 17
    inpin "_networkx_list_start"
    inpin "B0N"
    outpin "Y"
    net "n20"
    function "(!((A0 A1)+B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 11
    target 21
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n17"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 12
    target 22
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n26"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 13
    target 18
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n18"
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 14
    target 11
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n21"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 14
    target 12
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n21"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 14
    target 16
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "n21"
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 14
    target 17
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "n21"
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 15
    target 21
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n16"
    function "(!((A0+A1) (B0+B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 16
    target 4
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[0]"
    function "(!((A0 A1)+B0N))"
    innum 1
    outnum 1
  ]
  edge [
    source 17
    target 5
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[1]"
    function "(!((A0 A1)+B0N))"
    innum 1
    outnum 1
  ]
  edge [
    source 18
    target 10
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n19"
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 19
    target 22
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n25"
    function "(!((A0+A1) (B0+B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 20
    target 10
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n22"
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 20
    target 11
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n22"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 20
    target 12
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n22"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 21
    target 7
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[3]"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 22
    target 6
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[2]"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 23
    target 24
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\subtractor_1/n1 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 23
    target 25
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\subtractor_1/n4 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 24
    target 18
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_sub1[0]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 25
    target 19
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_sub1[2]"
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 26
    target 27
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\subtractor_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 26
    target 28
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\subtractor_1/n6 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 27
    target 23
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "Y"
    net "\subtractor_1/n5 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 27
    target 28
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\subtractor_1/n5 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 28
    target 15
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_sub1[3]"
    function "(!((A0 A1)+B0))"
    innum 5
    outnum 1
  ]
  edge [
    source 29
    target 23
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\subtractor_1/n3 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 30
    target 8
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[1]"
    function "(!((A0 A1)+(B0 B1)))"
    innum 1
    outnum 1
  ]
  edge [
    source 30
    target 13
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[1]"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 30
    target 15
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "operation[1]"
    function "(!((A0 A1)+(B0 B1)))"
    innum 5
    outnum 1
  ]
  edge [
    source 30
    target 19
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "operation[1]"
    function "(!((A0 A1)+(B0 B1)))"
    innum 5
    outnum 1
  ]
  edge [
    source 30
    target 20
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[1]"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 31
    target 9
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[0]"
    function "(!((A0+A1) (B0+B1)))"
    innum 1
    outnum 1
  ]
  edge [
    source 32
    target 30
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\comparator_1/n5 "
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 32
    target 31
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\comparator_1/n5 "
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 32
    target 34
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\comparator_1/n5 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 32
    target 36
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\comparator_1/n5 "
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 33
    target 30
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "\comparator_1/n4 "
    function "(!A)"
    innum 5
    outnum 1
  ]
  edge [
    source 33
    target 35
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\comparator_1/n4 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 33
    target 36
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\comparator_1/n4 "
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 34
    target 31
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\comparator_1/n2 "
    function "(A B)"
    innum 4
    outnum 1
  ]
  edge [
    source 35
    target 31
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "\comparator_1/n1 "
    function "(!(A B))"
    innum 4
    outnum 1
  ]
  edge [
    source 36
    target 30
    inpin "_networkx_list_start"
    inpin "C0"
    outpin "Y"
    net "\comparator_1/n3 "
    function "(!((A0+A1) (B0+B1)))"
    innum 5
    outnum 1
  ]
  edge [
    source 37
    target 38
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\subtractor_2/n1 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 37
    target 12
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub2[2]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 38
    target 10
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "Result_sub2[0]"
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 39
    target 41
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\subtractor_2/n2 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 39
    target 42
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\subtractor_2/n2 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 40
    target 37
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_2/n4 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 41
    target 37
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "Y"
    net "\subtractor_2/n3 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 41
    target 42
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\subtractor_2/n3 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 42
    target 11
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "Result_sub2[3]"
    function "(!((A0+A1) B0))"
    innum 4
    outnum 1
  ]
  edge [
    source 43
    target 19
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "Result_add[2]"
    function "(!(A^B))"
    innum 5
    outnum 1
  ]
  edge [
    source 44
    target 43
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 44
    target 45
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 45
    target 15
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "Result_add[3]"
    function "(!((A0+A1) B0))"
    innum 5
    outnum 1
  ]
  edge [
    source 46
    target 51
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 47
    target 49
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 48
    target 11
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 4
    outnum 1
  ]
  edge [
    source 48
    target 49
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 48
    target 50
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 49
    target 17
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "Result_mul[1]"
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 50
    target 16
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "Result_mul[0]"
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 50
    target 51
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[0]"
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 51
    target 12
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_mul[2]"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
]
