graph [
  directed 1
  node [
    id 0
    label "INPUT_a[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_a[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_a[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "INPUT_a[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 4
    label "INPUT_b[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 5
    label "INPUT_b[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 6
    label "INPUT_b[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 7
    label "INPUT_b[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 8
    label "OUTPUT_Result_mul[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 9
    label "OUTPUT_Result_mul[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 10
    label "OUTPUT_Result_mul[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 11
    label "OUTPUT_Result_mul[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 12
    label "OUTPUT_Result_mul[4]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 13
    label "OUTPUT_Result_mul[5]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 14
    label "OUTPUT_Result_mul[6]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 15
    label "OUTPUT_Result_mul[7]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 16
    label "OUTPUT_Result_add[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 17
    label "OUTPUT_Result_add[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 18
    label "OUTPUT_Result_add[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 19
    label "OUTPUT_Result_add[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 20
    label "\adder_1/U6"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 21
    label "\adder_1/U5"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 22
    label "\adder_1/U4"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 23
    label "\adder_1/U3"
    nodeType "XOR3_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 24
    label "\adder_1/U2"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 25
    label "\adder_1/U1"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 26
    label "\multiplier_1/U61"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 27
    label "\multiplier_1/U60"
    nodeType "OR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A+B)')]"
  ]
  node [
    id 28
    label "\multiplier_1/U59"
    nodeType "AO21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 29
    label "\multiplier_1/U58"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 30
    label "\multiplier_1/U57"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 31
    label "\multiplier_1/U56"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 32
    label "\multiplier_1/U55"
    nodeType "OAI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 33
    label "\multiplier_1/U54"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 34
    label "\multiplier_1/U53"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 35
    label "\multiplier_1/U52"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 36
    label "\multiplier_1/U51"
    nodeType "ADDH_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 37
    label "\multiplier_1/U50"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 38
    label "\multiplier_1/U49"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 39
    label "\multiplier_1/U48"
    nodeType "AOI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 40
    label "\multiplier_1/U47"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 41
    label "\multiplier_1/U46"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 42
    label "\multiplier_1/U45"
    nodeType "ADDH_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 43
    label "\multiplier_1/U44"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 44
    label "\multiplier_1/U43"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 45
    label "\multiplier_1/U42"
    nodeType "ADDH_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 46
    label "\multiplier_1/U41"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 47
    label "\multiplier_1/U40"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 48
    label "\multiplier_1/U39"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 49
    label "\multiplier_1/U38"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 50
    label "\multiplier_1/U37"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 51
    label "\multiplier_1/U36"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 52
    label "\multiplier_1/U35"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 53
    label "\multiplier_1/U34"
    nodeType "OR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A+B)')]"
  ]
  node [
    id 54
    label "\multiplier_1/U33"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 55
    label "\multiplier_1/U32"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 56
    label "\multiplier_1/U31"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 57
    label "\multiplier_1/U30"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 58
    label "\multiplier_1/U29"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 59
    label "\multiplier_1/U28"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 60
    label "\multiplier_1/U27"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 61
    label "\multiplier_1/U26"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 62
    label "\multiplier_1/U25"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 63
    label "\multiplier_1/U24"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 64
    label "\multiplier_1/U23"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 65
    label "\multiplier_1/U22"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 66
    label "\multiplier_1/U21"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 67
    label "\multiplier_1/U20"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 68
    label "\multiplier_1/U19"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 69
    label "\multiplier_1/U18"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 70
    label "\multiplier_1/U17"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 71
    label "\multiplier_1/U16"
    nodeType "OA21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 72
    label "\multiplier_1/U15"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 73
    label "\multiplier_1/U14"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 74
    label "\multiplier_1/U13"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 75
    label "\multiplier_1/U12"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 76
    label "\multiplier_1/U11"
    nodeType "OAI21_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 77
    label "\multiplier_1/U10"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 78
    label "\multiplier_1/U9"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 79
    label "\multiplier_1/U8"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 80
    label "\multiplier_1/U7"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 81
    label "\multiplier_1/U6"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 82
    label "\multiplier_1/U5"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 83
    label "\multiplier_1/U4"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 84
    label "\multiplier_1/U3"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 85
    label "\multiplier_1/U2"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 86
    label "\multiplier_1/U1"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  edge [
    source 0
    target 23
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 57
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 1
    target 20
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 79
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 2
    target 21
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[2]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 86
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 3
    target 24
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 25
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 72
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 4
    target 23
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 4
    target 81
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 5
    target 20
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 5
    target 80
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 6
    target 21
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 6
    target 82
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 7
    target 24
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 25
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 73
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[3]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 20
    target 23
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\adder_1/n1 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 20
    target 17
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "Result_add[1]"
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 21
    target 20
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\adder_1/n4 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 21
    target 18
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "Result_add[2]"
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 22
    target 19
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[3]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 23
    target 16
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[0]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 24
    target 22
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 25
    target 21
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "Y"
    net "\adder_1/n3 "
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 25
    target 22
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n3 "
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 26
    target 14
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[6]"
    function "(A B)"
    innum 1
    outnum 1
  ]
  edge [
    source 27
    target 26
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n59 "
    function "(A+B)"
    innum 2
    outnum 1
  ]
  edge [
    source 28
    target 8
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[0]"
    function "(!((A0 A1)+B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 29
    target 9
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[1]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 30
    target 75
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n53 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 31
    target 28
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "CO"
    net "\multiplier_1/n51 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 31
    target 30
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\multiplier_1/n51 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 31
    target 34
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n40 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 31
    target 64
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n40 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 32
    target 28
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n55 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 32
    target 29
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n55 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 33
    target 10
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[2]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 34
    target 32
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n43 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 34
    target 78
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n43 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 35
    target 34
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n39 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 35
    target 64
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n39 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 35
    target 53
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n24 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 35
    target 63
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n24 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 36
    target 31
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\multiplier_1/n48 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 36
    target 35
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "S"
    net "\multiplier_1/n36 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 37
    target 31
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n49 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 38
    target 31
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n50 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 39
    target 32
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n45 "
    function "(!((A0 A1)+B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 39
    target 33
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n45 "
    function "(!((A0 A1)+B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 40
    target 11
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[3]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 41
    target 53
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n23 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 41
    target 63
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n23 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 41
    target 62
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n11 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 41
    target 85
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n11 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 42
    target 35
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n37 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 42
    target 62
    inpin "_networkx_list_start"
    inpin "B"
    outpin "S"
    net "\multiplier_1/n10 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 42
    target 85
    inpin "_networkx_list_start"
    inpin "B"
    outpin "S"
    net "\multiplier_1/n10 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 43
    target 35
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n38 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 44
    target 12
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[4]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 45
    target 41
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\multiplier_1/n20 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 45
    target 61
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n3 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 45
    target 70
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n3 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 46
    target 41
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n21 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 47
    target 41
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n22 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 48
    target 13
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[5]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 49
    target 45
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n7 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 50
    target 45
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n8 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 51
    target 15
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[7]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 52
    target 77
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n4 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 53
    target 39
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(A+B)"
    innum 3
    outnum 1
  ]
  edge [
    source 53
    target 65
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(A+B)"
    innum 2
    outnum 1
  ]
  edge [
    source 54
    target 78
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n41 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 55
    target 66
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n12 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 56
    target 39
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n30 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 57
    target 37
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 57
    target 58
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 57
    target 67
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 57
    target 74
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 58
    target 36
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n35 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 59
    target 36
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n34 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 60
    target 26
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 60
    target 48
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 60
    target 71
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 61
    target 71
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n13 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 61
    target 77
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n13 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 62
    target 66
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n25 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 62
    target 76
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n25 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 63
    target 56
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n29 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 63
    target 65
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n29 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 64
    target 32
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n44 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 64
    target 54
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n44 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 65
    target 40
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n28 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 66
    target 44
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n15 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 67
    target 28
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n54 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 67
    target 75
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n54 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 68
    target 27
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n57 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 68
    target 60
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n57 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 69
    target 61
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 69
    target 70
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 70
    target 52
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n14 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 70
    target 71
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n14 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 71
    target 44
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n26 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 71
    target 76
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n26 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 72
    target 47
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 72
    target 49
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 72
    target 51
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 72
    target 68
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 73
    target 51
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n9 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 73
    target 69
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n9 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 73
    target 74
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n9 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 73
    target 84
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n9 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 74
    target 42
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 75
    target 29
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n52 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 76
    target 39
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 76
    target 40
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 77
    target 48
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n5 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 78
    target 33
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n42 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 79
    target 38
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 79
    target 43
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 79
    target 69
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 79
    target 83
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 80
    target 37
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n33 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 80
    target 43
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n33 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 80
    target 46
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n33 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 80
    target 49
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n33 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 81
    target 38
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n47 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 81
    target 47
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n47 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 81
    target 59
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n47 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 81
    target 67
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n47 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 82
    target 50
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 82
    target 58
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 82
    target 68
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 82
    target 83
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 83
    target 42
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n16 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 84
    target 27
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 84
    target 60
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 85
    target 55
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n27 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 85
    target 76
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n27 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 86
    target 46
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 86
    target 50
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 86
    target 59
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 86
    target 84
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
]
