graph [
  directed 1
  node [
    id 0
    label "INPUT_a[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_a[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_a[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "INPUT_a[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 4
    label "INPUT_b[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 5
    label "INPUT_b[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 6
    label "INPUT_b[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 7
    label "INPUT_b[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 8
    label "INPUT_operation[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 9
    label "INPUT_operation[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 10
    label "OUTPUT_Result[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 11
    label "OUTPUT_Result[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 12
    label "OUTPUT_Result[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 13
    label "OUTPUT_Result[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 14
    label "OUTPUT_Result[4]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 15
    label "OUTPUT_Result[5]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 16
    label "OUTPUT_Result[6]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 17
    label "OUTPUT_Result[7]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 18
    label "U27"
    nodeType "INV_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 19
    label "U28"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 20
    label "U29"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 21
    label "U30"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 22
    label "U31"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 23
    label "U32"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 24
    label "U33"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 25
    label "U34"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 26
    label "U35"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 27
    label "U36"
    nodeType "AOI22_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 28
    label "U37"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 29
    label "U38"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 30
    label "U39"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 31
    label "U40"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 32
    label "U41"
    nodeType "AOI22_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 33
    label "U42"
    nodeType "OAI2XB1_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1N) B0))')]"
  ]
  node [
    id 34
    label "U43"
    nodeType "OAI2XB1_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1N) B0))')]"
  ]
  node [
    id 35
    label "U44"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 36
    label "U45"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 37
    label "U46"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 38
    label "U47"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 39
    label "U48"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 40
    label "U49"
    nodeType "AO21B_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0N))')]"
  ]
  node [
    id 41
    label "U50"
    nodeType "OAI2XB1_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1N) B0))')]"
  ]
  node [
    id 42
    label "\subtractor_1/U7"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 43
    label "\subtractor_1/U6"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 44
    label "\subtractor_1/U5"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 45
    label "\subtractor_1/U4"
    nodeType "OAI21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 46
    label "\subtractor_1/U3"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 47
    label "\subtractor_1/U2"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 48
    label "\subtractor_1/U1"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 49
    label "\subtractor_1/intadd_0/U2"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 50
    label "\subtractor_1/intadd_0/U3"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 51
    label "\subtractor_1/intadd_0/U4"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 52
    label "\subtractor_2/U7"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 53
    label "\subtractor_2/U6"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 54
    label "\subtractor_2/U5"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 55
    label "\subtractor_2/U4"
    nodeType "OAI21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 56
    label "\subtractor_2/U3"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 57
    label "\subtractor_2/U2"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 58
    label "\subtractor_2/U1"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 59
    label "\subtractor_2/intadd_1/U2"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 60
    label "\subtractor_2/intadd_1/U3"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 61
    label "\subtractor_2/intadd_1/U4"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 62
    label "\adder_1/U7"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 63
    label "\adder_1/U6"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 64
    label "\adder_1/U5"
    nodeType "XOR3_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 65
    label "\adder_1/U4"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 66
    label "\adder_1/U3"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 67
    label "\adder_1/U2"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 68
    label "\multiplier_1/U69"
    nodeType "OAI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 69
    label "\multiplier_1/U68"
    nodeType "OR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A+B)')]"
  ]
  node [
    id 70
    label "\multiplier_1/U67"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 71
    label "\multiplier_1/U66"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 72
    label "\multiplier_1/U65"
    nodeType "AOI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 73
    label "\multiplier_1/U64"
    nodeType "OAI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 74
    label "\multiplier_1/U63"
    nodeType "ADDH_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 75
    label "\multiplier_1/U62"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 76
    label "\multiplier_1/U61"
    nodeType "ADDH_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 77
    label "\multiplier_1/U60"
    nodeType "ADDF_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 78
    label "\multiplier_1/U59"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 79
    label "\multiplier_1/U58"
    nodeType "ADDH_X1M_A9TH"
    nodeFunctions "[('CO', ''), ('S', '')]"
  ]
  node [
    id 80
    label "\multiplier_1/U57"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 81
    label "\multiplier_1/U56"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 82
    label "\multiplier_1/U55"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 83
    label "\multiplier_1/U54"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 84
    label "\multiplier_1/U53"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 85
    label "\multiplier_1/U52"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 86
    label "\multiplier_1/U51"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 87
    label "\multiplier_1/U50"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 88
    label "\multiplier_1/U49"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 89
    label "\multiplier_1/U48"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 90
    label "\multiplier_1/U47"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 91
    label "\multiplier_1/U46"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 92
    label "\multiplier_1/U45"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 93
    label "\multiplier_1/U44"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 94
    label "\multiplier_1/U43"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 95
    label "\multiplier_1/U42"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 96
    label "\multiplier_1/U41"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 97
    label "\multiplier_1/U40"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 98
    label "\multiplier_1/U39"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 99
    label "\multiplier_1/U38"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 100
    label "\multiplier_1/U37"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 101
    label "\multiplier_1/U36"
    nodeType "INV_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 102
    label "\multiplier_1/U35"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 103
    label "\multiplier_1/U34"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 104
    label "\multiplier_1/U33"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 105
    label "\multiplier_1/U32"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 106
    label "\multiplier_1/U31"
    nodeType "OAI21_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 107
    label "\multiplier_1/U30"
    nodeType "OAI21_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 108
    label "\multiplier_1/U29"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 109
    label "\multiplier_1/U28"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 110
    label "\multiplier_1/U27"
    nodeType "INV_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 111
    label "\multiplier_1/U26"
    nodeType "INV_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 112
    label "\multiplier_1/U25"
    nodeType "INV_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 113
    label "\multiplier_1/U24"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 114
    label "\multiplier_1/U23"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 115
    label "\multiplier_1/U22"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 116
    label "\multiplier_1/U21"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 117
    label "\multiplier_1/U20"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 118
    label "\multiplier_1/U19"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 119
    label "\multiplier_1/U18"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 120
    label "\multiplier_1/U17"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 121
    label "\multiplier_1/U16"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 122
    label "\multiplier_1/U15"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 123
    label "\multiplier_1/U14"
    nodeType "OAI21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 124
    label "\multiplier_1/U13"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 125
    label "\multiplier_1/U12"
    nodeType "OA21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 126
    label "\multiplier_1/U11"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 127
    label "\multiplier_1/U10"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 128
    label "\multiplier_1/U9"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 129
    label "\multiplier_1/U8"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 130
    label "\multiplier_1/U7"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 131
    label "\multiplier_1/U6"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 132
    label "\multiplier_1/U5"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 133
    label "\multiplier_1/U4"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 134
    label "\multiplier_1/U3"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 135
    label "\multiplier_1/U2"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 136
    label "\multiplier_1/U1"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  edge [
    source 0
    target 49
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 56
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 0
    target 64
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 89
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 1
    target 50
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 57
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 1
    target 62
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 110
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 2
    target 51
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[2]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 53
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 2
    target 63
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[2]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 99
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 3
    target 42
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 3
    target 54
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 55
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[3]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 3
    target 65
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 66
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 136
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 4
    target 46
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 4
    target 59
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 4
    target 64
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 4
    target 101
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 5
    target 48
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 5
    target 60
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 5
    target 62
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 5
    target 112
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 6
    target 43
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 6
    target 61
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[2]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 6
    target 63
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 6
    target 111
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 7
    target 44
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 45
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "b[3]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 7
    target 52
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[3]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 7
    target 65
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 66
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 100
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[3]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 8
    target 19
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 29
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 8
    target 31
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "operation[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 35
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "operation[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 19
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "operation[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 28
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 9
    target 30
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "operation[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 35
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 18
    target 20
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n40"
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 18
    target 21
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n40"
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 18
    target 23
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n40"
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 18
    target 27
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n40"
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 18
    target 40
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "n40"
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 19
    target 18
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n42"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 19
    target 33
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n42"
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 19
    target 34
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n42"
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 19
    target 41
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n42"
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 20
    target 39
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n39"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 21
    target 38
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n34"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 22
    target 39
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n38"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 23
    target 37
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n32"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 24
    target 38
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n33"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 25
    target 37
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n31"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 26
    target 36
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "n29"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 27
    target 36
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n30"
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 28
    target 31
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n28"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 29
    target 30
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "n27"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 30
    target 20
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n35"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 30
    target 21
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n35"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 30
    target 23
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n35"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 30
    target 27
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n35"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 30
    target 32
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "n35"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 31
    target 22
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n37"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 31
    target 24
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n37"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 31
    target 25
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n37"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 31
    target 26
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "n37"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 31
    target 32
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n37"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 32
    target 33
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n41"
    function "(!((A0 A1)+(B0 B1)))"
    innum 3
    outnum 1
  ]
  edge [
    source 32
    target 34
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n41"
    function "(!((A0 A1)+(B0 B1)))"
    innum 3
    outnum 1
  ]
  edge [
    source 32
    target 40
    inpin "_networkx_list_start"
    inpin "B0N"
    outpin "Y"
    net "n41"
    function "(!((A0 A1)+(B0 B1)))"
    innum 3
    outnum 1
  ]
  edge [
    source 32
    target 41
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n41"
    function "(!((A0 A1)+(B0 B1)))"
    innum 3
    outnum 1
  ]
  edge [
    source 33
    target 12
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[2]"
    function "(!((A0+A1N) B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 34
    target 10
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[0]"
    function "(!((A0+A1N) B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 35
    target 22
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n36"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 35
    target 24
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n36"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 35
    target 25
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n36"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 35
    target 26
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "n36"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 36
    target 17
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[7]"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 37
    target 16
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[6]"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 38
    target 15
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[5]"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 39
    target 14
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[4]"
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 40
    target 13
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[3]"
    function "(!((A0 A1)+B0N))"
    innum 1
    outnum 1
  ]
  edge [
    source 41
    target 11
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[1]"
    function "(!((A0+A1N) B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 42
    target 44
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\subtractor_1/n1 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 42
    target 45
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\subtractor_1/n1 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 43
    target 51
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_1/intadd_0/B[0] "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 44
    target 45
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\subtractor_1/intadd_0/CI "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 44
    target 51
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "Y"
    net "\subtractor_1/intadd_0/CI "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 45
    target 26
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "Result_sub1[7]"
    function "(!((A0+A1) B0))"
    innum 4
    outnum 1
  ]
  edge [
    source 46
    target 49
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_1/intadd_0/B[2] "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 47
    target 32
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_sub1[0]"
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 48
    target 50
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_1/intadd_0/B[1] "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 49
    target 47
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\subtractor_1/intadd_0/n1 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 49
    target 22
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub1[4]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 50
    target 49
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\subtractor_1/intadd_0/n2 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 50
    target 24
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub1[5]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 51
    target 50
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\subtractor_1/intadd_0/n3 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 51
    target 25
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub1[6]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 52
    target 54
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\subtractor_2/n1 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 52
    target 55
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\subtractor_2/n1 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 53
    target 61
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_2/intadd_1/B[0] "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 54
    target 55
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\subtractor_2/intadd_1/CI "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 54
    target 61
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "Y"
    net "\subtractor_2/intadd_1/CI "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 55
    target 27
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "Result_sub2[7]"
    function "(!((A0+A1) B0))"
    innum 4
    outnum 1
  ]
  edge [
    source 56
    target 59
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_2/intadd_1/B[2] "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 57
    target 60
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\subtractor_2/intadd_1/B[1] "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 58
    target 32
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "Result_sub2[0]"
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 59
    target 58
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\subtractor_2/intadd_1/n1 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 59
    target 20
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub2[4]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 60
    target 59
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\subtractor_2/intadd_1/n2 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 60
    target 21
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub2[5]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 61
    target 60
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\subtractor_2/intadd_1/n3 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 61
    target 23
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "S"
    net "Result_sub2[6]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 62
    target 64
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\adder_1/n1 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 62
    target 24
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "S"
    net "Result_add[5]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 63
    target 62
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\adder_1/n4 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 63
    target 25
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "S"
    net "Result_add[6]"
    function ""
    innum 4
    outnum 2
  ]
  edge [
    source 64
    target 22
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_add[4]"
    function "(A^B)"
    innum 4
    outnum 1
  ]
  edge [
    source 65
    target 67
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 66
    target 63
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "Y"
    net "\adder_1/n3 "
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 66
    target 67
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n3 "
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 67
    target 26
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_add[7]"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 68
    target 109
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n49 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 69
    target 122
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n40 "
    function "(A+B)"
    innum 2
    outnum 1
  ]
  edge [
    source 70
    target 104
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\multiplier_1/n36 "
    function ""
    innum 1
    outnum 2
  ]
  edge [
    source 70
    target 78
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n27 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 70
    target 133
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n27 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 71
    target 107
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n42 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 72
    target 107
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n43 "
    function "(!((A0 A1)+B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 72
    target 108
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n43 "
    function "(!((A0 A1)+B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 73
    target 72
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n44 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 73
    target 90
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n44 "
    function "(!((A0+A1) B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 74
    target 77
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\multiplier_1/n10 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 74
    target 121
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n21 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 74
    target 132
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n21 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 75
    target 73
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n55 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 75
    target 95
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n55 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 76
    target 103
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\multiplier_1/n7 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 76
    target 120
    inpin "_networkx_list_start"
    inpin "A"
    outpin "CO"
    net "\multiplier_1/n7 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 76
    target 123
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "CO"
    net "\multiplier_1/n7 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 76
    target 75
    inpin "_networkx_list_start"
    inpin "B"
    outpin "S"
    net "\multiplier_1/n22 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 76
    target 124
    inpin "_networkx_list_start"
    inpin "B"
    outpin "S"
    net "\multiplier_1/n22 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 77
    target 82
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n24 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 77
    target 98
    inpin "_networkx_list_start"
    inpin "B"
    outpin "CO"
    net "\multiplier_1/n24 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 77
    target 75
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n23 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 77
    target 124
    inpin "_networkx_list_start"
    inpin "A"
    outpin "S"
    net "\multiplier_1/n23 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 78
    target 97
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n45 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 78
    target 106
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n45 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 78
    target 128
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n45 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 79
    target 70
    inpin "_networkx_list_start"
    inpin "CI"
    outpin "CO"
    net "\multiplier_1/n33 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 79
    target 105
    inpin "_networkx_list_start"
    inpin "B"
    outpin "S"
    net "\multiplier_1/n5 "
    function ""
    innum 2
    outnum 2
  ]
  edge [
    source 79
    target 123
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "S"
    net "\multiplier_1/n5 "
    function ""
    innum 3
    outnum 2
  ]
  edge [
    source 80
    target 70
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n34 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 81
    target 70
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n35 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 82
    target 68
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n50 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 82
    target 92
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n50 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 82
    target 128
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n50 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 83
    target 74
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n16 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 84
    target 77
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n11 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 85
    target 77
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n12 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 86
    target 79
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n3 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 87
    target 79
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n4 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 88
    target 76
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n13 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 89
    target 80
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n30 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 89
    target 87
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n30 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 89
    target 118
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n30 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 89
    target 135
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n30 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 90
    target 68
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n53 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 90
    target 93
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n53 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 91
    target 127
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n62 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 92
    target 130
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n52 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 93
    target 40
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "Result_mul[3]"
    function "(A^B)"
    innum 3
    outnum 1
  ]
  edge [
    source 94
    target 21
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_mul[5]"
    function "(A^B)"
    innum 4
    outnum 1
  ]
  edge [
    source 95
    target 129
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n57 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 96
    target 20
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_mul[4]"
    function "(A^B)"
    innum 4
    outnum 1
  ]
  edge [
    source 97
    target 131
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n47 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 98
    target 68
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n51 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 98
    target 106
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n51 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 98
    target 130
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n51 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 99
    target 83
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 99
    target 84
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 99
    target 86
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 99
    target 114
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 100
    target 113
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n66 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 100
    target 114
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n66 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 100
    target 117
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n66 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 100
    target 135
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n66 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 101
    target 81
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 101
    target 85
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 101
    target 86
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 101
    target 118
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 102
    target 74
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n15 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 103
    target 105
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 104
    target 107
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n41 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 104
    target 134
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n41 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 105
    target 82
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n25 "
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 105
    target 98
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n25 "
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 106
    target 72
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n28 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 107
    target 34
    inpin "_networkx_list_start"
    inpin "A1N"
    outpin "Y"
    net "Result_mul[0]"
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 108
    target 41
    inpin "_networkx_list_start"
    inpin "A1N"
    outpin "Y"
    net "Result_mul[1]"
    function "(A^B)"
    innum 3
    outnum 1
  ]
  edge [
    source 109
    target 33
    inpin "_networkx_list_start"
    inpin "A1N"
    outpin "Y"
    net "Result_mul[2]"
    function "(!(A^B))"
    innum 3
    outnum 1
  ]
  edge [
    source 110
    target 81
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 110
    target 88
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 110
    target 113
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 110
    target 116
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 111
    target 83
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 111
    target 87
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 111
    target 88
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 111
    target 115
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 112
    target 80
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 112
    target 84
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 112
    target 102
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 112
    target 116
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 113
    target 121
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n20 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 113
    target 132
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n20 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 114
    target 69
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n38 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 114
    target 119
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n38 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 115
    target 69
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n39 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 115
    target 119
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n39 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 116
    target 103
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 116
    target 120
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 116
    target 123
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 117
    target 27
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_mul[7]"
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 118
    target 71
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 118
    target 134
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 119
    target 94
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n63 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 119
    target 122
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n63 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 119
    target 125
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n63 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 120
    target 126
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n8 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 121
    target 91
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n60 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 121
    target 125
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n60 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 122
    target 23
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "Result_mul[6]"
    function "(A B)"
    innum 4
    outnum 1
  ]
  edge [
    source 123
    target 126
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n9 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 124
    target 73
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 124
    target 129
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 125
    target 73
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 125
    target 96
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 126
    target 78
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n26 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 126
    target 133
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n26 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 127
    target 94
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n64 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 128
    target 72
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n29 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 129
    target 96
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n59 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 130
    target 93
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n54 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 131
    target 109
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n48 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 132
    target 125
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n61 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 132
    target 127
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n61 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 133
    target 106
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 133
    target 131
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 134
    target 108
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n37 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 135
    target 76
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n14 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 136
    target 85
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n65 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 136
    target 102
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n65 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 136
    target 115
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n65 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 136
    target 117
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n65 "
    function "(!A)"
    innum 2
    outnum 1
  ]
]
