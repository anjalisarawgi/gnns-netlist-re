graph [
  directed 1
  node [
    id 0
    label "INPUT_a[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_a[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_b[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "INPUT_b[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 4
    label "OUTPUT_Result[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 5
    label "OUTPUT_Result[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 6
    label "OUTPUT_Result[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 7
    label "OUTPUT_Result[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 8
    label "INPUT_operation"
    nodeFunctions "INPUT"
  ]
  node [
    id 9
    label "U5"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 10
    label "U6"
    nodeType "MX2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((S A) + (!S B)))')]"
  ]
  node [
    id 11
    label "U7"
    nodeType "AND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 12
    label "U8"
    nodeType "MX2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((S A) + (!S B)))')]"
  ]
  node [
    id 13
    label "\adder_1/U4"
    nodeType "XNOR3_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 14
    label "\adder_1/U3"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 15
    label "\adder_1/U2"
    nodeType "OA21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 16
    label "\multiplier_1/U6"
    nodeType "AND3_X1M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 17
    label "\multiplier_1/U5"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 18
    label "\multiplier_1/U4"
    nodeType "AND2_X1M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 19
    label "\multiplier_1/U3"
    nodeType "AOI22_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 20
    label "\multiplier_1/U2"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 21
    label "\multiplier_1/U1"
    nodeType "NOR2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  edge [
    source 0
    target 13
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 16
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 19
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 0
    target 20
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 14
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 15
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 18
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 19
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "a[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 2
    target 13
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 16
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 19
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "b[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 2
    target 20
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 14
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 15
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 3
    target 18
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 19
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 8
    target 9
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 10
    inpin "_networkx_list_start"
    inpin "S0"
    outpin "Y"
    net "operation"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 8
    target 11
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "operation"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 12
    inpin "_networkx_list_start"
    inpin "S0"
    outpin "Y"
    net "operation"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 9
    target 4
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[0]"
    function "(A B)"
    innum 1
    outnum 1
  ]
  edge [
    source 10
    target 6
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[2]"
    function "(!((S A) + (!S B)))"
    innum 1
    outnum 1
  ]
  edge [
    source 11
    target 5
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[1]"
    function "(A B)"
    innum 1
    outnum 1
  ]
  edge [
    source 12
    target 7
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[3]"
    function "(!((S A) + (!S B)))"
    innum 1
    outnum 1
  ]
  edge [
    source 13
    target 10
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[2]"
    function "(!(A^B))"
    innum 3
    outnum 1
  ]
  edge [
    source 14
    target 13
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 14
    target 15
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 15
    target 12
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[3]"
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 16
    target 9
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_mul[0]"
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 16
    target 21
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[0]"
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 17
    target 11
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_mul[1]"
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 18
    target 12
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 18
    target 16
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 18
    target 17
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 19
    target 21
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 20
    target 17
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 21
    target 10
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_mul[2]"
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
]
