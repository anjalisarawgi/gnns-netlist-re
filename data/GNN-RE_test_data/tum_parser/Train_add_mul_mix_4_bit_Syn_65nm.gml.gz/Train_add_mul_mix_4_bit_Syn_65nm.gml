graph [
  directed 1
  node [
    id 0
    label "INPUT_a[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_a[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_a[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "INPUT_a[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 4
    label "INPUT_b[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 5
    label "INPUT_b[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 6
    label "INPUT_b[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 7
    label "INPUT_b[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 8
    label "INPUT_c[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 9
    label "INPUT_c[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 10
    label "INPUT_c[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 11
    label "INPUT_c[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 12
    label "INPUT_d[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 13
    label "INPUT_d[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 14
    label "INPUT_d[2]"
    nodeFunctions "INPUT"
  ]
  node [
    id 15
    label "INPUT_d[3]"
    nodeFunctions "INPUT"
  ]
  node [
    id 16
    label "OUTPUT_Result[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 17
    label "OUTPUT_Result[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 18
    label "OUTPUT_Result[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 19
    label "OUTPUT_Result[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 20
    label "OUTPUT_Result[4]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 21
    label "OUTPUT_Result[5]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 22
    label "OUTPUT_Result[6]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 23
    label "OUTPUT_Result[7]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 24
    label "\adder_1/U31"
    nodeType "NOR2_X2A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 25
    label "\adder_1/U30"
    nodeType "INV_X7P5M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 26
    label "\adder_1/U29"
    nodeType "INV_X16M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 27
    label "\adder_1/U28"
    nodeType "INV_X16M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 28
    label "\adder_1/U27"
    nodeType "OAI21_X3M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 29
    label "\adder_1/U26"
    nodeType "MXIT2_X3M_A9TH"
    nodeFunctions "[('Y', '(!((S A) + (!S B)))')]"
  ]
  node [
    id 30
    label "\adder_1/U25"
    nodeType "AOI22_X8M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 31
    label "\adder_1/U24"
    nodeType "NAND2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 32
    label "\adder_1/U23"
    nodeType "INV_X4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 33
    label "\adder_1/U22"
    nodeType "NAND3_X4A_A9TH"
    nodeFunctions "[('Y', '(!((A B) C))')]"
  ]
  node [
    id 34
    label "\adder_1/U21"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 35
    label "\adder_1/U20"
    nodeType "NAND2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 36
    label "\adder_1/U19"
    nodeType "XOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 37
    label "\adder_1/U18"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 38
    label "\adder_1/U17"
    nodeType "OAI2XB1_X4M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1N) B0))')]"
  ]
  node [
    id 39
    label "\adder_1/U16"
    nodeType "INV_X4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 40
    label "\adder_1/U15"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 41
    label "\adder_1/U14"
    nodeType "NAND3_X4M_A9TH"
    nodeFunctions "[('Y', '(!((A B) C))')]"
  ]
  node [
    id 42
    label "\adder_1/U13"
    nodeType "NAND2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 43
    label "\adder_1/U12"
    nodeType "NAND3_X6M_A9TH"
    nodeFunctions "[('Y', '(!((A B) C))')]"
  ]
  node [
    id 44
    label "\adder_1/U11"
    nodeType "INV_X4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 45
    label "\adder_1/U10"
    nodeType "NAND2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 46
    label "\adder_1/U9"
    nodeType "NAND2_X6M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 47
    label "\adder_1/U8"
    nodeType "INV_X4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 48
    label "\adder_1/U7"
    nodeType "INV_X7P5M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 49
    label "\adder_1/U6"
    nodeType "NAND2_X3A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 50
    label "\adder_1/U5"
    nodeType "NOR2_X6M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 51
    label "\adder_1/U4"
    nodeType "NAND2_X6M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 52
    label "\adder_1/U3"
    nodeType "INV_X6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 53
    label "\adder_1/U2"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 54
    label "\adder_1/U1"
    nodeType "AND2_X3M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 55
    label "\adder_2/U20"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 56
    label "\adder_2/U19"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 57
    label "\adder_2/U18"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 58
    label "\adder_2/U17"
    nodeType "INV_X1P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 59
    label "\adder_2/U16"
    nodeType "XNOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 60
    label "\adder_2/U15"
    nodeType "XNOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 61
    label "\adder_2/U14"
    nodeType "OAI22_X6M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) (B0+B1)))')]"
  ]
  node [
    id 62
    label "\adder_2/U13"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 63
    label "\adder_2/U12"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 64
    label "\adder_2/U11"
    nodeType "NAND2_X4A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 65
    label "\adder_2/U10"
    nodeType "NOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 66
    label "\adder_2/U9"
    nodeType "NOR2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 67
    label "\adder_2/U8"
    nodeType "NAND2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 68
    label "\adder_2/U7"
    nodeType "NOR2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 69
    label "\adder_2/U6"
    nodeType "NAND2_X6A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 70
    label "\adder_2/U5"
    nodeType "INV_X5M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 71
    label "\adder_2/U4"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 72
    label "\adder_2/U3"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 73
    label "\adder_2/U2"
    nodeType "XOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 74
    label "\adder_2/U1"
    nodeType "INV_X4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 75
    label "\multiplier_1/U98"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 76
    label "\multiplier_1/U97"
    nodeType "OAI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 77
    label "\multiplier_1/U96"
    nodeType "AOI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 78
    label "\multiplier_1/U95"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 79
    label "\multiplier_1/U94"
    nodeType "XNOR2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 80
    label "\multiplier_1/U93"
    nodeType "NOR2_X2A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 81
    label "\multiplier_1/U92"
    nodeType "XOR2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 82
    label "\multiplier_1/U91"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 83
    label "\multiplier_1/U90"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 84
    label "\multiplier_1/U89"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 85
    label "\multiplier_1/U88"
    nodeType "NAND2_X1P4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 86
    label "\multiplier_1/U87"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 87
    label "\multiplier_1/U86"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 88
    label "\multiplier_1/U85"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 89
    label "\multiplier_1/U84"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 90
    label "\multiplier_1/U83"
    nodeType "XNOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 91
    label "\multiplier_1/U82"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 92
    label "\multiplier_1/U81"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 93
    label "\multiplier_1/U80"
    nodeType "XOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 94
    label "\multiplier_1/U79"
    nodeType "XNOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 95
    label "\multiplier_1/U78"
    nodeType "INV_X0P8M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 96
    label "\multiplier_1/U77"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 97
    label "\multiplier_1/U76"
    nodeType "NOR3_X4M_A9TH"
    nodeFunctions "[('Y', '(!((A+B)+C))')]"
  ]
  node [
    id 98
    label "\multiplier_1/U75"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 99
    label "\multiplier_1/U74"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 100
    label "\multiplier_1/U73"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 101
    label "\multiplier_1/U72"
    nodeType "NAND2_X6M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 102
    label "\multiplier_1/U71"
    nodeType "MXIT2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((S A) + (!S B)))')]"
  ]
  node [
    id 103
    label "\multiplier_1/U70"
    nodeType "XNOR2_X2M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 104
    label "\multiplier_1/U69"
    nodeType "NAND2_X6M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 105
    label "\multiplier_1/U68"
    nodeType "NAND2_X4A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 106
    label "\multiplier_1/U67"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 107
    label "\multiplier_1/U66"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 108
    label "\multiplier_1/U65"
    nodeType "AOI21_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0))')]"
  ]
  node [
    id 109
    label "\multiplier_1/U64"
    nodeType "NAND3_X3A_A9TH"
    nodeFunctions "[('Y', '(!((A B) C))')]"
  ]
  node [
    id 110
    label "\multiplier_1/U63"
    nodeType "NAND2_X1P4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 111
    label "\multiplier_1/U62"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 112
    label "\multiplier_1/U61"
    nodeType "NAND2_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 113
    label "\multiplier_1/U60"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 114
    label "\multiplier_1/U59"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 115
    label "\multiplier_1/U58"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 116
    label "\multiplier_1/U57"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 117
    label "\multiplier_1/U56"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 118
    label "\multiplier_1/U55"
    nodeType "NAND2_X1P4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 119
    label "\multiplier_1/U54"
    nodeType "OAI21_X2M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 120
    label "\multiplier_1/U53"
    nodeType "OAI21_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 121
    label "\multiplier_1/U52"
    nodeType "NAND2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 122
    label "\multiplier_1/U51"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 123
    label "\multiplier_1/U50"
    nodeType "NAND2_X6A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 124
    label "\multiplier_1/U49"
    nodeType "XOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 125
    label "\multiplier_1/U48"
    nodeType "XNOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 126
    label "\multiplier_1/U47"
    nodeType "NOR2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 127
    label "\multiplier_1/U46"
    nodeType "NOR2_X1P4A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 128
    label "\multiplier_1/U45"
    nodeType "NAND2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 129
    label "\multiplier_1/U44"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 130
    label "\multiplier_1/U43"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 131
    label "\multiplier_1/U42"
    nodeType "NAND2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 132
    label "\multiplier_1/U41"
    nodeType "AO21B_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+B0N))')]"
  ]
  node [
    id 133
    label "\multiplier_1/U40"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 134
    label "\multiplier_1/U39"
    nodeType "INV_X1P4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 135
    label "\multiplier_1/U38"
    nodeType "NAND2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 136
    label "\multiplier_1/U37"
    nodeType "NAND2_X2M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 137
    label "\multiplier_1/U36"
    nodeType "NAND2_X0P7A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 138
    label "\multiplier_1/U35"
    nodeType "NAND2_X1P4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 139
    label "\multiplier_1/U34"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 140
    label "\multiplier_1/U33"
    nodeType "INV_X0P7M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 141
    label "\multiplier_1/U32"
    nodeType "XNOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 142
    label "\multiplier_1/U31"
    nodeType "XOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 143
    label "\multiplier_1/U30"
    nodeType "NAND2_X3A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 144
    label "\multiplier_1/U29"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 145
    label "\multiplier_1/U28"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 146
    label "\multiplier_1/U27"
    nodeType "NAND2_X2A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 147
    label "\multiplier_1/U26"
    nodeType "NAND2_X3M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 148
    label "\multiplier_1/U25"
    nodeType "INV_X0P5B_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 149
    label "\multiplier_1/U24"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 150
    label "\multiplier_1/U23"
    nodeType "OAI21_X4M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 151
    label "\multiplier_1/U22"
    nodeType "AND2_X8M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 152
    label "\multiplier_1/U21"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 153
    label "\multiplier_1/U20"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 154
    label "\multiplier_1/U19"
    nodeType "BUFH_X1P7M_A9TH"
    nodeFunctions "[('Y', 'A')]"
  ]
  node [
    id 155
    label "\multiplier_1/U18"
    nodeType "INV_X4M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 156
    label "\multiplier_1/U17"
    nodeType "NAND2_X8M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 157
    label "\multiplier_1/U16"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 158
    label "\multiplier_1/U15"
    nodeType "INV_X3M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 159
    label "\multiplier_1/U14"
    nodeType "NAND2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 160
    label "\multiplier_1/U13"
    nodeType "INV_X2M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 161
    label "\multiplier_1/U12"
    nodeType "NAND2_X3A_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 162
    label "\multiplier_1/U11"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 163
    label "\multiplier_1/U10"
    nodeType "NOR2_X1A_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 164
    label "\multiplier_1/U9"
    nodeType "NOR2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 165
    label "\multiplier_1/U8"
    nodeType "OAI2XB1_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1N) B0))')]"
  ]
  node [
    id 166
    label "\multiplier_1/U7"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 167
    label "\multiplier_1/U6"
    nodeType "INV_X0P6M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 168
    label "\multiplier_1/U5"
    nodeType "NAND2_X4M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 169
    label "\multiplier_1/U4"
    nodeType "XOR2_X3M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 170
    label "\multiplier_1/U3"
    nodeType "NAND2_X2M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 171
    label "\multiplier_1/U2"
    nodeType "INV_X1M_A9TH"
    nodeFunctions "[('Y', '(!A)')]"
  ]
  node [
    id 172
    label "\multiplier_1/U1"
    nodeType "AND2_X3M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  edge [
    source 0
    target 27
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 0
    target 30
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "a[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 1
    target 37
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 49
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 50
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 25
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 2
    target 34
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 51
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 35
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 53
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 4
    target 30
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "b[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 4
    target 48
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 5
    target 47
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 5
    target 49
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 5
    target 50
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 6
    target 26
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 6
    target 34
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 6
    target 51
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 35
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 7
    target 53
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 8
    target 73
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "c[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 61
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "c[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 9
    target 62
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "c[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 9
    target 64
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "c[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 10
    target 57
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "c[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 10
    target 66
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "c[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 10
    target 69
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "c[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 11
    target 67
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "c[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 11
    target 72
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "c[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 12
    target 73
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "d[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 13
    target 61
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "d[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 13
    target 64
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "d[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 13
    target 70
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "d[1]"
    function ""
    innum 1
    outnum 1
  ]
  edge [
    source 14
    target 57
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "d[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 14
    target 66
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "d[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 14
    target 69
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "d[2]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 15
    target 67
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "d[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 15
    target 72
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "d[3]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 24
    target 92
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[3]"
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 24
    target 118
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[3]"
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 24
    target 145
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[3]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 24
    target 151
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[3]"
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 25
    target 46
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n23 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 26
    target 46
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n24 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 27
    target 30
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\adder_1/n19 "
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 28
    target 29
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n14 "
    function "(!((A0+A1) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 29
    target 41
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n13 "
    function "(!((S A) + (!S B)))"
    innum 3
    outnum 1
  ]
  edge [
    source 30
    target 29
    inpin "_networkx_list_start"
    inpin "S0"
    outpin "Y"
    net "\adder_1/n18 "
    function "(!((A0 A1)+(B0 B1)))"
    innum 3
    outnum 1
  ]
  edge [
    source 30
    target 33
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n18 "
    function "(!((A0 A1)+(B0 B1)))"
    innum 3
    outnum 1
  ]
  edge [
    source 30
    target 40
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n18 "
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 31
    target 41
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n15 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 32
    target 83
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[2]"
    function "(!A)"
    innum 1
    outnum 1
  ]
  edge [
    source 32
    target 101
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 32
    target 123
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 32
    target 149
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 32
    target 157
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 33
    target 41
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\adder_1/n12 "
    function "(!((A B) C))"
    innum 3
    outnum 1
  ]
  edge [
    source 34
    target 36
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n8 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 35
    target 36
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n7 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 35
    target 39
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n7 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 36
    target 32
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n20 "
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 37
    target 38
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\adder_1/n5 "
    function "(A^B)"
    innum 3
    outnum 1
  ]
  edge [
    source 37
    target 44
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n5 "
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 38
    target 45
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n4 "
    function "(!((A0+A1N) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 39
    target 24
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n26 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 39
    target 42
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n26 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 40
    target 31
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n16 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 41
    target 114
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[0]"
    function "(!((A B) C))"
    innum 2
    outnum 1
  ]
  edge [
    source 41
    target 158
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[0]"
    function "(!((A B) C))"
    innum 1
    outnum 1
  ]
  edge [
    source 42
    target 33
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\adder_1/n9 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 42
    target 43
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n9 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 42
    target 52
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n9 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 43
    target 45
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n2 "
    function "(!((A B) C))"
    innum 2
    outnum 1
  ]
  edge [
    source 44
    target 43
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n3 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 45
    target 104
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[1]"
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 45
    target 105
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[1]"
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 45
    target 156
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[1]"
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 45
    target 161
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add[1]"
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 46
    target 42
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n10 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 47
    target 37
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 48
    target 30
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\adder_1/n22 "
    function "(!A)"
    innum 4
    outnum 1
  ]
  edge [
    source 49
    target 28
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\adder_1/n21 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 49
    target 54
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n21 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 50
    target 28
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\adder_1/n17 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 50
    target 29
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n17 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 50
    target 40
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n17 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 51
    target 28
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\adder_1/n27 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 51
    target 38
    inpin "_networkx_list_start"
    inpin "A1N"
    outpin "Y"
    net "\adder_1/n27 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 51
    target 43
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\adder_1/n27 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 51
    target 54
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n27 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 52
    target 31
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 52
    target 38
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 53
    target 24
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_1/n25 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 54
    target 33
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_1/n11 "
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 55
    target 56
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n12 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 56
    target 101
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[1]"
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 56
    target 105
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[1]"
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 56
    target 118
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[1]"
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 56
    target 155
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[1]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 57
    target 59
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n8 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 58
    target 59
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n16 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 58
    target 65
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n16 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 59
    target 74
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n7 "
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 60
    target 149
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[0]"
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 60
    target 151
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[0]"
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 60
    target 152
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[0]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 60
    target 161
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[0]"
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 61
    target 60
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n4 "
    function "(!((A0+A1) (B0+B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 62
    target 56
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n11 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 63
    target 61
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "\adder_2/n5 "
    function "(!(A B))"
    innum 4
    outnum 1
  ]
  edge [
    source 64
    target 63
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n6 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 65
    target 148
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[3]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 65
    target 156
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add_2[3]"
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 65
    target 157
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add_2[3]"
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 66
    target 68
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n1 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 67
    target 58
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n10 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 67
    target 68
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n10 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 68
    target 55
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n14 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 68
    target 61
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\adder_2/n14 "
    function "(!(A+B))"
    innum 4
    outnum 1
  ]
  edge [
    source 69
    target 63
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n9 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 69
    target 71
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n9 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 70
    target 62
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\adder_2/n2 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 71
    target 55
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n13 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 72
    target 65
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n15 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 73
    target 60
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\adder_2/n3 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 74
    target 92
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 74
    target 104
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_add_2[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 74
    target 115
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[2]"
    function "(!A)"
    innum 1
    outnum 1
  ]
  edge [
    source 74
    target 123
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add_2[2]"
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 75
    target 102
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n89 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 76
    target 16
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[0]"
    function "(!((A0+A1) B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 77
    target 76
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n84 "
    function "(!((A0 A1)+B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 78
    target 21
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[5]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 79
    target 17
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[1]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 80
    target 150
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n61 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 81
    target 18
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[2]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 82
    target 81
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n59 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 83
    target 97
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n55 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 84
    target 170
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n45 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 85
    target 81
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n60 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 86
    target 82
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n77 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 86
    target 89
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n77 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 86
    target 100
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n77 "
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 87
    target 143
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n29 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 88
    target 20
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[4]"
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 89
    target 77
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n83 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 89
    target 80
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n83 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 90
    target 119
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!(A^B))"
    innum 3
    outnum 1
  ]
  edge [
    source 90
    target 142
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n32 "
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 91
    target 78
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n73 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 91
    target 108
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n73 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 91
    target 166
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n73 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 92
    target 108
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n72 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 92
    target 130
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n72 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 93
    target 75
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n88 "
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 93
    target 87
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n88 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 93
    target 102
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n88 "
    function "(A^B)"
    innum 3
    outnum 1
  ]
  edge [
    source 94
    target 169
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n33 "
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 95
    target 132
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n16 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 96
    target 78
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n74 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 97
    target 165
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n10 "
    function "(!((A+B)+C))"
    innum 3
    outnum 1
  ]
  edge [
    source 97
    target 169
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n10 "
    function "(!((A+B)+C))"
    innum 2
    outnum 1
  ]
  edge [
    source 98
    target 146
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n50 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 99
    target 150
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n9 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 100
    target 99
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n8 "
    function "(!A)"
    innum 1
    outnum 1
  ]
  edge [
    source 100
    target 106
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n8 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 101
    target 103
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n11 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 101
    target 126
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n11 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 102
    target 88
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n90 "
    function "(!((S A) + (!S B)))"
    innum 2
    outnum 1
  ]
  edge [
    source 103
    target 84
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n87 "
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 103
    target 102
    inpin "_networkx_list_start"
    inpin "S0"
    outpin "Y"
    net "\multiplier_1/n87 "
    function "(!(A^B))"
    innum 3
    outnum 1
  ]
  edge [
    source 103
    target 109
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\multiplier_1/n87 "
    function "(!(A^B))"
    innum 3
    outnum 1
  ]
  edge [
    source 104
    target 103
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n49 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 104
    target 126
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n49 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 105
    target 90
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n54 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 105
    target 97
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n54 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 106
    target 76
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n85 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 107
    target 88
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n26 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 108
    target 22
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[6]"
    function "(!((A0 A1)+B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 109
    target 87
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n47 "
    function "(!((A B) C))"
    innum 2
    outnum 1
  ]
  edge [
    source 110
    target 147
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n52 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 110
    target 171
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n52 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 111
    target 131
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n35 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 112
    target 137
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n79 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 112
    target 138
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n79 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 113
    target 96
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n23 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 113
    target 168
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n23 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 114
    target 135
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n66 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 114
    target 140
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n66 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 115
    target 116
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n14 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 116
    target 127
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 116
    target 141
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 116
    target 153
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n56 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 117
    target 94
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n34 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 117
    target 132
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n34 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 117
    target 165
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n34 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 118
    target 111
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n41 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 118
    target 162
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n41 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 119
    target 86
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n57 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 119
    target 172
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n57 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 120
    target 110
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n28 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 121
    target 110
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n27 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 122
    target 93
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n20 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 123
    target 124
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n39 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 123
    target 164
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n39 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 124
    target 131
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n40 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 124
    target 160
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n40 "
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 125
    target 19
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[3]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 126
    target 127
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 126
    target 141
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 126
    target 153
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 127
    target 119
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n31 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 128
    target 125
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n76 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 129
    target 159
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n36 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 130
    target 159
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n37 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 131
    target 109
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n12 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 131
    target 133
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n12 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 132
    target 112
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n64 "
    function "(!((A0 A1)+B0N))"
    innum 2
    outnum 1
  ]
  edge [
    source 132
    target 134
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n64 "
    function "(!((A0 A1)+B0N))"
    innum 1
    outnum 1
  ]
  edge [
    source 133
    target 113
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n44 "
    function "(!A)"
    innum 1
    outnum 1
  ]
  edge [
    source 134
    target 135
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n65 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 135
    target 77
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n82 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 135
    target 106
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n82 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 135
    target 136
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n82 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 135
    target 137
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n82 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 136
    target 138
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n80 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 137
    target 79
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n67 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 138
    target 77
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n81 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 139
    target 23
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result[7]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 140
    target 112
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n63 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 141
    target 142
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n18 "
    function "(!(A^B))"
    innum 2
    outnum 1
  ]
  edge [
    source 142
    target 98
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n22 "
    function "(A^B)"
    innum 1
    outnum 1
  ]
  edge [
    source 142
    target 147
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n22 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 143
    target 125
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n3 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 143
    target 144
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n3 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 144
    target 76
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n86 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 144
    target 85
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n86 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 144
    target 150
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n86 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 145
    target 139
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n70 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 146
    target 128
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 146
    target 144
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 147
    target 89
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n75 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 147
    target 154
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n75 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 148
    target 139
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n69 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 148
    target 163
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n69 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 149
    target 90
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n21 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 150
    target 79
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n68 "
    function "(!((A0+A1) B0))"
    innum 2
    outnum 1
  ]
  edge [
    source 151
    target 120
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n5 "
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 151
    target 121
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n5 "
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 151
    target 122
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n5 "
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 152
    target 97
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\multiplier_1/n62 "
    function "(!A)"
    innum 3
    outnum 1
  ]
  edge [
    source 152
    target 167
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n62 "
    function "(!A)"
    innum 1
    outnum 1
  ]
  edge [
    source 153
    target 119
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n30 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 154
    target 85
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n7 "
    function "A"
    innum 2
    outnum 1
  ]
  edge [
    source 154
    target 128
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n7 "
    function "A"
    innum 2
    outnum 1
  ]
  edge [
    source 155
    target 117
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n53 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 156
    target 124
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n38 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 156
    target 164
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n38 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 157
    target 108
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "\multiplier_1/n71 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 157
    target 129
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n71 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 158
    target 116
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 158
    target 117
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 158
    target 163
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n19 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 159
    target 91
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n43 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 159
    target 109
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n43 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 160
    target 162
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n42 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 161
    target 94
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 161
    target 95
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 161
    target 165
    inpin "_networkx_list_start"
    inpin "A1N"
    outpin "Y"
    net "\multiplier_1/n17 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 162
    target 96
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n13 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 162
    target 166
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n13 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 163
    target 93
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n48 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 163
    target 120
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\multiplier_1/n48 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 164
    target 120
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "\multiplier_1/n4 "
    function "(!(A+B))"
    innum 3
    outnum 1
  ]
  edge [
    source 164
    target 121
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n4 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 164
    target 122
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n4 "
    function "(!(A+B))"
    innum 2
    outnum 1
  ]
  edge [
    source 165
    target 132
    inpin "_networkx_list_start"
    inpin "B0N"
    outpin "Y"
    net "\multiplier_1/n15 "
    function "(!((A0+A1N) B0))"
    innum 3
    outnum 1
  ]
  edge [
    source 166
    target 168
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n24 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 167
    target 114
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n6 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 168
    target 107
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n25 "
    function "(!(A B))"
    innum 1
    outnum 1
  ]
  edge [
    source 168
    target 170
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n25 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 169
    target 86
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 169
    target 172
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n58 "
    function "(A^B)"
    innum 2
    outnum 1
  ]
  edge [
    source 170
    target 143
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n46 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 171
    target 146
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n51 "
    function "(!A)"
    innum 2
    outnum 1
  ]
  edge [
    source 172
    target 80
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n78 "
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 172
    target 82
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n78 "
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 172
    target 136
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "\multiplier_1/n78 "
    function "(A B)"
    innum 2
    outnum 1
  ]
]
