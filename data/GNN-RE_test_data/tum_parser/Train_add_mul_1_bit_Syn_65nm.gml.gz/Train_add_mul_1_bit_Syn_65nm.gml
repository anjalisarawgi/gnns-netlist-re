graph [
  directed 1
  node [
    id 0
    label "INPUT_a"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_b"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_operation"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "OUTPUT_Result"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 4
    label "U2"
    nodeType "MX2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((S A) + (!S B)))')]"
  ]
  node [
    id 5
    label "\adder_1/U1"
    nodeType "XOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(A^B)')]"
  ]
  node [
    id 6
    label "\multiplier_1/U1"
    nodeType "AND2_X1M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  edge [
    source 0
    target 5
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 0
    target 6
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 5
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 6
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 4
    inpin "_networkx_list_start"
    inpin "S0"
    outpin "Y"
    net "operation"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 4
    target 3
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result"
    function "(!((S A) + (!S B)))"
    innum 1
    outnum 1
  ]
  edge [
    source 5
    target 4
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add"
    function "(A^B)"
    innum 3
    outnum 1
  ]
  edge [
    source 6
    target 4
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "Result_mul"
    function "(A B)"
    innum 3
    outnum 1
  ]
]
