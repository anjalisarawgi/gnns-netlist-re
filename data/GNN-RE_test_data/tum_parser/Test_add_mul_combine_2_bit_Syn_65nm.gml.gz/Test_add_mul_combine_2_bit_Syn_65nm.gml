graph [
  directed 1
  node [
    id 0
    label "INPUT_a[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 1
    label "INPUT_a[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 2
    label "INPUT_b[0]"
    nodeFunctions "INPUT"
  ]
  node [
    id 3
    label "INPUT_b[1]"
    nodeFunctions "INPUT"
  ]
  node [
    id 4
    label "OUTPUT_Result_mul[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 5
    label "OUTPUT_Result_mul[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 6
    label "OUTPUT_Result_mul[2]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 7
    label "OUTPUT_Result_mul[3]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 8
    label "OUTPUT_Result_add[0]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 9
    label "OUTPUT_Result_add[1]"
    nodeFunctions "OUTPUT"
  ]
  node [
    id 10
    label "\adder_1/U3"
    nodeType "OA21_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!((A0+A1) B0))')]"
  ]
  node [
    id 11
    label "\adder_1/U2"
    nodeType "XNOR3_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A^B))')]"
  ]
  node [
    id 12
    label "\adder_1/U1"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 13
    label "\multiplier_1/U6"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 14
    label "\multiplier_1/U5"
    nodeType "AOI22_X1M_A9TH"
    nodeFunctions "[('Y', '(!((A0 A1)+(B0 B1)))')]"
  ]
  node [
    id 15
    label "\multiplier_1/U4"
    nodeType "AND3_X1M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  node [
    id 16
    label "\multiplier_1/U3"
    nodeType "NOR2_X0P5M_A9TH"
    nodeFunctions "[('Y', '(!(A+B))')]"
  ]
  node [
    id 17
    label "\multiplier_1/U2"
    nodeType "NAND2_X1M_A9TH"
    nodeFunctions "[('Y', '(!(A B))')]"
  ]
  node [
    id 18
    label "\multiplier_1/U1"
    nodeType "AND2_X1M_A9TH"
    nodeFunctions "[('Y', '(A B)')]"
  ]
  edge [
    source 0
    target 11
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 14
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 0
    target 15
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 0
    target 17
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 10
    inpin "_networkx_list_start"
    inpin "A0"
    outpin "Y"
    net "a[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 1
    target 12
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 1
    target 14
    inpin "_networkx_list_start"
    inpin "B1"
    outpin "Y"
    net "a[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 1
    target 18
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "a[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 2
    target 11
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 14
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "b[0]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 2
    target 15
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 2
    target 17
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[0]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 10
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[1]"
    function ""
    innum 3
    outnum 1
  ]
  edge [
    source 3
    target 12
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 3
    target 14
    inpin "_networkx_list_start"
    inpin "A1"
    outpin "Y"
    net "b[1]"
    function ""
    innum 4
    outnum 1
  ]
  edge [
    source 3
    target 18
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "b[1]"
    function ""
    innum 2
    outnum 1
  ]
  edge [
    source 10
    target 9
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[1]"
    function "(!((A0+A1) B0))"
    innum 1
    outnum 1
  ]
  edge [
    source 11
    target 8
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_add[0]"
    function "(!(A^B))"
    innum 1
    outnum 1
  ]
  edge [
    source 12
    target 10
    inpin "_networkx_list_start"
    inpin "B0"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 12
    target 11
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "\adder_1/n1 "
    function "(!(A B))"
    innum 3
    outnum 1
  ]
  edge [
    source 13
    target 6
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[2]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 14
    target 13
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n2 "
    function "(!((A0 A1)+(B0 B1)))"
    innum 2
    outnum 1
  ]
  edge [
    source 15
    target 4
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[0]"
    function "(A B)"
    innum 1
    outnum 1
  ]
  edge [
    source 15
    target 13
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[0]"
    function "(A B)"
    innum 2
    outnum 1
  ]
  edge [
    source 16
    target 5
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[1]"
    function "(!(A+B))"
    innum 1
    outnum 1
  ]
  edge [
    source 17
    target 16
    inpin "_networkx_list_start"
    inpin "B"
    outpin "Y"
    net "\multiplier_1/n1 "
    function "(!(A B))"
    innum 2
    outnum 1
  ]
  edge [
    source 18
    target 7
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 1
    outnum 1
  ]
  edge [
    source 18
    target 15
    inpin "_networkx_list_start"
    inpin "C"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 3
    outnum 1
  ]
  edge [
    source 18
    target 16
    inpin "_networkx_list_start"
    inpin "A"
    outpin "Y"
    net "Result_mul[3]"
    function "(A B)"
    innum 2
    outnum 1
  ]
]
